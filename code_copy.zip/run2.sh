#!/bin/bash
#生成json
cd /new_disk/ting/RL
/new_disk/ting/anaconda3/envs/RL/bin/python /new_disk/ting/RL/RISconfig.py

#生成信道
matlab -nodisplay -nosplash -nodesktop -r "run('ChannelGen/BS2RIS_2.m'); run('ChannelGen/RIS2UE_2.m'); exit;"

#运行RL
/new_disk/ting/anaconda3/envs/RL/bin/python /new_disk/ting/RL/Mycode_2/main.py