% 打开 JSON 文件并读取内容
fid = fopen('RISconfig.json', 'r');
raw = fread(fid, inf);
str = char(raw');
fclose(fid);

% 解析 JSON 文件为 MATLAB 结构体
RISconfig = jsondecode(str);

% 获取各参数
N_RISm = RISconfig.N_RISm;
N_RISn = RISconfig.N_RISn;
N_RIS = N_RISm * N_RISn;
NumSubCar = RISconfig.NumSubCar;
N_UEm = RISconfig.N_UEm;
N_UEn = RISconfig.N_UEn;
num_time_slots = RISconfig.num_time_slots;
CenterFre = RISconfig.CenterFre;
UENum = RISconfig.UENum;
N_BSm = RISconfig.N_BSm;
N_BSn = RISconfig.N_BSn;
UEcenter = RISconfig.UEcenter;
