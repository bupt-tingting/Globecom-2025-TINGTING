classdef ChannelParam
    %UNTITLED5 Summary of this class goes here
    %   Detailed explanation goes here

    properties
        CenterFre = 28e9; %中心频率
        NumSubCar =2; %子载波数,FDD的总数，TDD为一半

        N_BSm = 1; %垂直天线的数量
        N_BSn = 5; %水平天线的数量
        N_RISm = 4; %RIS垂直数量
        N_RISn = 4;
        N_RIS
        N_UEm = 4;
        N_UEn = 1;

        SnapNum = 4; %时隙数量
        UENum = 1; %用户数量

        BSlocation = [0; 2; 0]; %基站位置，三维
        RISlocation = [0.01; 0.01; 0];
        UEcenter = [1.7; 1; 0]; %以UEcenter为中心分布
        %xy平面上看是60°
        UESpeedList = 0.01:2:10;

    end

    methods

        function obj = ChannelParam()
        end

        function output = get.N_RIS(obj) %计算RIS单元数量
            output = obj.N_RISm * obj.N_RISn;
        end

    end

end
