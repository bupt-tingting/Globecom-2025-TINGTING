%生成6D的数据，将空间维度合并，极化采用单极化
close all;
clear ;
rng(1); % 使用种子1
cd /new_disk/ting/RL/ChannelGen;


clc; clear; close all;

% 打开 JSON 文件并读取内容
fid = fopen('RISconfig.json', 'r');
raw = fread(fid, inf);
str = char(raw');
fclose(fid);

% 解析 JSON 文件为 MATLAB 结构体
RISconfig = jsondecode(str);

% 获取各参数
N_RISm = RISconfig.N_RISm;
N_RISn = RISconfig.N_RISn;
N_RIS = N_RISm * N_RISn;
NumSubCar = RISconfig.NumSubCar;
N_UEm = RISconfig.N_UEm;
N_UEn = RISconfig.N_UEn;
num_time_slots = RISconfig.num_time_slots;
CenterFre = RISconfig.CenterFre;
UENum = RISconfig.UENum;
N_BSm = RISconfig.N_BSm;
N_BSn = RISconfig.N_BSn;
UEcenter = RISconfig.UEcenter;

s = qd_simulation_parameters;
s.center_frequency = CenterFre; %center frequency,24GHz,
%% Base station antenna configuration

Mg_BS = 1; % Number of nested panels in a column
Ng_BS = 1; % Number of nested panels in a row
ElcTltAgl_BS = 7; %基站下倾角，单位：度
Hspc_Tx_BS = 0.5 * s.wavelength; % Horizontal array element spacing
Vspc_Tx_BS = 0.5 * s.wavelength; % Vertical array element spacing
RISNum = 1;



BSAntArray = qd_arrayant.generate('3gpp-mmw', N_BSm, N_BSn, ...
    s.center_frequency, 1, ElcTltAgl_BS, ...
    Vspc_Tx_BS / s.wavelength, Mg_BS, Ng_BS, ...
    Vspc_Tx_BS / s.wavelength * N_BSm, Hspc_Tx_BS / s.wavelength * N_BSn);

%% UE antenna configuration

RISAntArray = qd_arrayant.generate('3gpp-mmw', N_RISm, N_RISn, ...
    s.center_frequency, 1, ElcTltAgl_BS, ...
    Vspc_Tx_BS / s.wavelength, Mg_BS, Ng_BS, ...
    Vspc_Tx_BS / s.wavelength * N_BSm, Hspc_Tx_BS / s.wavelength * N_BSn);

Speed = 0.001; %[km/h]，RIS不会动的
loop_Speed = length(Speed);
H_BS2RIS = zeros(loop_Speed, RISNum, num_time_slots, NumSubCar / 2, N_BSm, N_BSn, 1, N_RISm, N_RISn); %(速度仿真次数，用户个数，历史导频数，载波数，水平天线数，垂直天线数，极化数)
%H_BS2RIS=reshape(H_BS2RIS,[RISNum,ii,num_time_slots,NumSubCar/2,N_BSm*N_BSn*2,N_RISm*N_RISn]);最后的结果，将天线维度合并1
%1     4    48    16    36，共六维
% H_U_preBS2RIS = zeros(loop_Speed,RISNum,4,NumSubCar/2,N_BSm,N_BSn,2,N_RISm,N_RISn);
% H_D_preBS2RIS = zeros(loop_Speed,RISNum,4,NumSubCar/2,N_BSm,N_BSn,2,N_RISm,N_RISn);

for iter_Speed = 1:length(Speed)
    disp(iter_Speed)

    RISpeed = Speed(iter_Speed); %[km/h]
    TimeInterval = 0.5e-3; %Time sampling interval,[s]0.5ms采样一次
    Timelength = (num_time_slots - 1) * TimeInterval; %Sample Period Length,[s]
    UETrackLength = RISpeed / 3.6 * Timelength; %Calculate UE motion path length
    IndoorRatio = 0; % Indoor user ratio，该参数未用上

    %num_time_slots为20，但是没用上
    %     num_time_slots = 1+floor(Timelength/TimeInterval);
    %% Configure BS-UE channel parameters
    s1 = qd_simulation_parameters; %
    s1.center_frequency = CenterFre;
    s1.set_speed(RISpeed, TimeInterval);
    s1.use_random_initial_phase = true;
    s1.use_3GPP_baseline = 1;

    %BS location
    BSlocation = RISconfig.BSlocation; %基站高度为30米
    rho_min = 2;
    rho_max = 5;
    rho = rho_min + (rho_max - rho_min) * rand(1, RISNum); %随机半径，(20,50)均匀分布
    phi = 120 * rand(1, RISNum) - 60; %随机方位角，(-60°,60°)均匀分布
    %     UEcenter = [200;0;1.5];%以UEcenter为中心分布

    %计算RIS位置
    %     RISlocation = zeros(3,RISNum);
    %     d = zeros(1,RISNum);
    %     for ind_RIS = 1:RISNum
    %         rho_n = rho(ind_RIS);
    %         phi_n = phi(ind_RIS);
    %         RISlocation(:,ind_RIS) = [-rho_n*cosd(phi_n);rho_n*sind(phi_n);0]+UEcenter;
    %         d(ind_RIS) = norm(RISlocation(:,ind_RIS)-BSlocation);
    %     end
    RISlocation = RISconfig.RISlocation;

    %UE track
    UEtrack(1, RISNum) = qd_track();

    for ind_RIS = 1:RISNum
        UEtrack(1, ind_RIS) = qd_track.generate('linear', UETrackLength);
        UEtrack(1, ind_RIS).name = num2str(ind_RIS);
        UEtrack(1, ind_RIS).interpolate('distance', 1 / s1.samples_per_meter, [], [], 1);
    end

    % BS-UE
    l1 = qd_layout(s1); %Layout initialization
    l1.no_tx = 1; %Configure the number of base stations
    l1.tx_array = BSAntArray; %Configuring the antenna on the base station side
    l1.tx_position = BSlocation; %Configure the base station spatial location
    l1.no_rx = RISNum; %Configure the number of users
    l1.rx_array = RISAntArray; %Configuring the user-side antenna
    l1.rx_track = UEtrack;
    l1.rx_position = RISlocation; %Configuring user space locations
    l1.set_scenario('3GPP_38.901_UMa_LOS');
    %     l1.set_scenario('Freespace');
    %
    % %     位置可视化
    %         l1.visualize([],[],0);                                   % Plot
    %         axis equal
    %         title('Track layout');                                  % Set plot title

    % 不对哦，有问题
    %     [ map,x_coords,y_coords] = l1.power_map( '3GPP_38.901_UMa_NLOS','quick',5,0,300,-300,300,1.5,10);
    %     %power_map( h_layout, scenario, usage, sample_distance, ...
    %     % x_min, x_max, y_min, y_max, rx_height, tx_power, i_freq )
    %     %1.5:接收器高度，400：基站发射功率，30dbm,1w
    %     P = 10*log10( sum(cat(3,map{:}),3));                    % Total received power
    %     P = P(:,:,:,2);
    %     l1.visualize([],[],0);                                   % Show BS and MT positions on the map
    %     hold on
    %     imagesc( x_coords, y_coords, P);                       % Plot the received power
    %     hold off
    %     axis([0 300 -300 300])                               % Plot size
    %     caxis( max(P(:)) + [-20 0] )                            % Color range
    %     colmap = colormap;
    %     colormap( colmap*0.5 + 0.5 );                           % Adjust colors to be "lighter"
    %     set(gca,'layer','top')                                  % Show grid on top of the map
    %     title('Correct antenna orientation');                   % Set plot title

    [BS2UE_channel, BS2UE_builder] = l1.get_channels();
    % Output:
    %   h_channel
    %   A vector 'qd_channel' objects. 10*1 qd_channel对象
    %
    %   h_builder
    %   A vector of 'qd_builder' objects.
    for ii = 1:RISNum
        hBS2RIS = BS2UE_channel(ii).fr(17280e3, NumSubCar); % OFDM channel generation 上下行带宽共8.64*2 一共96个子载波
        %fr( h_channel, bandwidth, carriers, i_snapshot, use_gpu )
        %带宽是17.28Mhz，
        %FR Transforms the channel into frequency domain and returns the frequency response
        % Output:
        %   freq_response
        %   The complex-valued channel coefficients for each carrier in frequency domain. The indices of
        %   the 4-D tensor are: [ Rx-Antenna , Tx-Antenna , Carrier-Index , Snapshot ]
        %reshape之前：size(h)=1    32    96    20
        %Snapshot：信道在特定时刻的状态
        %如果BS改为水平极化，则size(h)=1    16    96    20
        hBS2RIS = reshape(hBS2RIS, N_RISm, N_RISn, 1, N_BSm, N_BSn, NumSubCar, num_time_slots); %h=reshape(h,M_UE,N_UE,2,M_BS,N_BS,NumSubCar,num_time_slots)
        hBS2RIS = permute(hBS2RIS, [7, 6, 4, 5, 3, 1, 2]); %(num_time_slots,NumSubCar,M_BS,N_BS,2,M_UE,N_UE)
        %h=permute(h,[5,4,3,2,1]);
        %重排维度顺序，结果为[20, 96, 4, 4, 2]，
        %[Snapshot,Carrier-Index,水平天线数，垂直天线数，极化数],五维

        %历史数据集
        %H_U_his:(速度仿真次数，用户个数，历史导频数，载波数，水平天线数，垂直天线数，极化数),七维
        H_BS2RIS(iter_Speed, ii, :, :, :, :, :, :, :) = hBS2RIS(:, 1:(NumSubCar / 2), :, :, :, :, :); % historical uplink CSI  前16个时间
        H_BS2RIS = reshape(H_BS2RIS, [RISNum, 1, num_time_slots, NumSubCar / 2, N_BSm * N_BSn, N_RISm * N_RISn]);
        %预测数据集
        %         H_U_preBS2RIS(iter_Speed,ii,:,:,:,:,:,:,:)=hBS2RIS(17:20,1:48,:,:,:,:,:); % future uplink CSI  预测下4个时间
        %         H_D_preBS2RIS(iter_Speed,ii,:,:,:,:,:,:,:)=hBS2RIS(17:20,49:96,:,:,:,:,:); % future downlink CSI  下行导频
    end

end
disp('BS2RIS_2.m is finished!');
disp('-----------------------------------------------------------')
matfile = sprintf('..//MyData//H_BS2RIS_%d*%dRIS_%d*%d_%d*%d_MIMO.mat', N_RISm, N_RISn, N_BSm, N_BSn, N_UEm, N_UEn);
save(matfile,"H_BS2RIS")
%matlab -nodesktop -nosplash -r "run('/new_disk/ting/RL/ChannelGen/BS2RIS_2.m')"
