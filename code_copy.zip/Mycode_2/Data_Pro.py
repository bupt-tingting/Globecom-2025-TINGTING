# 基础库
import torch
import torch.utils.data as data
import torch.nn.functional as F
from torch.distributions import Normal
import numpy as np
from numpy import random
import random

# 数据处理和分析
from sklearn.metrics import mutual_info_score
import hdf5storage
from einops import rearrange

# 环境和训练
import gym
from gym import spaces
from tqdm import tqdm

# 可视化
import matplotlib.pyplot as plt
#3d绘图
import plotly.graph_objects as go

#色彩序列
import matplotlib.colors as mcolors
from matplotlib.patches import Arc


def whitening(data):
    """0,1标准化"""
    mean_value = np.mean(data)
    std_value = np.std(data)
    normalized_data = (data - mean_value) / std_value    
    return normalized_data
def C2R(data):
    """Complex to Real: 复数转实数，新维度在倒数第三维"""
    if not np.iscomplexobj(data):
        raise ValueError("Input should be complex data")
        
    real_part = np.real(data)
    imag_part = np.imag(data)
    
    shape = list(data.shape)
    if len(shape) < 3:
        for _ in range(3 - len(shape)):
            real_part = np.expand_dims(real_part, axis=0)
            imag_part = np.expand_dims(imag_part, axis=0)
            
    real_data = np.stack([real_part, imag_part], axis=-3)
    return real_data

def R2C(data):
    """Real to Complex: 实数转复数，从倒数第三维度提取实部虚部"""
    if np.iscomplexobj(data):
        raise ValueError("Input should be real data")
        
    if data.shape[-3] != 2:
        raise ValueError("The third last dimension should be 2")
        
    real_part = data[..., 0:1, :, :]
    imag_part = data[..., 1:2, :, :]
    
    real_part = np.squeeze(real_part, axis=-3)
    imag_part = np.squeeze(imag_part, axis=-3)
    
    complex_data = real_part + 1j * imag_part
    return complex_data

def multiple_RIS(H_BS2RIS, Phi, H_RIS2UE, use_sum=False):
    """
    处理任意时间维数据的RIS计算
    
    参数:
    H_BS2RIS: numpy.ndarray - 输入的多维数组，形状为 (T,  8, 36), 其中T为时间维度
    Phi: numpy.ndarray - 形状为 (T, 36, 36) 的矩阵数组
    H_RIS2UE: numpy.ndarray - 形状为 (T,  36, 2) 的矩阵
    use_sum: bool - 是否在最后进行求和操作
    
    返回:
    numpy.ndarray - 最终结果
    """
    time_axis = 0
    T = H_BS2RIS.shape[time_axis]  # 获取时间维度大小
    
    # 初始化存储所有时间步结果的列表
    results = []
    
    # 对每个时间步进行计算
    for t in range(T):
        # 获取当前时间步的数据
        H_BS2RIS_t = H_BS2RIS[t:t+1]  # 保持形状
        Phi_t = Phi[t]
        H_RIS2UE_t = H_RIS2UE[t:t+1]
        
        # 计算当前时间步的结果
        result_t = np.matmul(H_BS2RIS_t, Phi_t)
        H_combined_t = np.matmul(result_t, H_RIS2UE_t)
        
        results.append(H_combined_t)
    
    # 沿时间维度合并所有结果
    H_combined = np.concatenate(results, axis=time_axis)
    
    if use_sum:
        H_combined = np.sum(H_combined, axis=(-2, -1), keepdims=True)
    
    return H_combined

def set_all_seeds(seed):
    # Python 内置随机数种子
    random.seed(seed)
    
    # NumPy 随机数种子
    np.random.seed(seed)
    
    # PyTorch 随机数种子
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)  # if you are using multi-GPU.

    # 保证 cuDNN 后端使用确定性算法
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
def add_noise(data, snr_db, use_mean=0):
    """为输入数据添加高斯白噪声"""
    if use_mean==1:
        signal_power = np.mean(np.abs(data)**2)
    else:
        signal_power = np.min(np.abs(data)**2)    
    snr_linear = 10**(snr_db/10)
    noise_power = signal_power / snr_linear
    
    if np.iscomplexobj(data):
        noise = np.sqrt(noise_power/2) * (np.random.normal(size=data.shape) + 
                                        1j * np.random.normal(size=data.shape))
    else:
        noise = np.sqrt(noise_power) * np.random.normal(size=data.shape)
    
    noisy_data = data + noise
    return noisy_data

def plot_channel_response(H_in):
    """绘制信道频率响应的幅度和相位热图,输入是6D，自动压缩，[0, 0, :, :, 0, 0]，分别是频率与时隙"""
    H_in = np.squeeze((H_in[0, :, :, 0, 0]))
    H_in = np.transpose(H_in)
    num_freq, num_time = H_in.shape
    print("Number of Frequencies:", num_freq, "Number of Time Slots:", num_time)

    time = np.linspace(0, num_time * 0.5 - 0.5, num_time)
    freq = np.linspace(1, num_freq, num_freq)
    
    # 创建一个图形和两个子图
    plt.figure(figsize=(12, 5))  ## 新增，设置整体图形大小

    # 幅度子图
    plt.subplot(121)  ## 修改，创建左侧子图
    magnitude = np.abs(H_in)
    plt.imshow(magnitude, aspect='auto', extent=[time[0], time[-1], freq[0], freq[-1]], origin='lower')
    plt.colorbar(label='Magnitude')
    plt.xlabel('Time (ms)')
    plt.ylabel('Index of Subcarriers')
    plt.title('Magnitude of Channel Frequency Response')
    plt.grid()

    # 相位子图
    plt.subplot(122)  ## 修改，创建右侧子图
    phase = np.angle(H_in)
    plt.imshow(phase, aspect='auto', extent=[time[0], time[-1], freq[0], freq[-1]], origin='lower', cmap='hsv')
    plt.colorbar(label='Phase')
    plt.xlabel('Time (ms)')
    plt.ylabel('Index of Subcarriers')
    plt.title('Phase of Channel Frequency Response')
    plt.clim(-np.pi, np.pi)
    plt.grid()
    
    plt.tight_layout()  ## 新增，自动调整子图间距
    plt.show()
    


def plot_channel_response_MIMO(H_in):
    """
    绘制两个时隙的 MIMO 信道响应热图，包括幅度、相位、实部和虚部。

    假设输入 H_in 的形状为 (time_slots, num_tx, num_rx)，
    其中倒数第二维为发射天线数量，最后一维为接收天线数量。
    
    为了使得热图的横轴对应接收天线、纵轴对应发射天线，直接使用原始数据（去除多余转置）。
    """
    num_timeslots = 2  # 当前只绘制两个时隙
    # 使用第一个时隙确定发射和接收天线的数目
    # H0 的形状为 (num_tx, num_rx)
    H0 = np.squeeze(H_in[0, :, :])
    num_tx, num_rx = H0.shape
    print("Number of Transmit Antennas:", num_tx, "Number of Receive Antennas:", num_rx)
    
    # 定义发射天线和接收天线的索引（整数显示）
    tx_ant = np.arange(1, num_tx + 1)
    rx_ant = np.arange(1, num_rx + 1)
    
    # 创建 2x4 的网格
    fig, axs = plt.subplots(2, 4, figsize=(20, 10))
    
    for t in range(num_timeslots):
        # 取出当前时隙的数据，不做转置，H 形状为 (num_tx, num_rx)
        H = np.squeeze(H_in[t, :, :])
    
        # 幅度子图
        magnitude = np.abs(H)
        # 注意：imshow 横轴对应数组的列（接收天线），纵轴对应数组的行（发射天线）
        im = axs[t, 0].imshow(magnitude, aspect='auto', 
                              extent=[rx_ant[0], rx_ant[-1], tx_ant[0], tx_ant[-1]],
                              origin='lower')
        fig.colorbar(im, ax=axs[t, 0], label='Magnitude')
        axs[t, 0].set_xlabel('Receive Antenna')
        axs[t, 0].set_ylabel('Transmit Antenna')
        axs[t, 0].set_title(f'Time Slot {t+1} - Magnitude')
        axs[t, 0].grid(True)
        axs[t, 0].set_xticks(rx_ant)
        axs[t, 0].set_yticks(tx_ant)
    
        # 相位子图
        phase = np.angle(H)
        im = axs[t, 1].imshow(phase, aspect='auto', 
                              extent=[rx_ant[0], rx_ant[-1], tx_ant[0], tx_ant[-1]],
                              origin='lower', cmap='hsv')
        im.set_clim(-np.pi, np.pi)
        fig.colorbar(im, ax=axs[t, 1], label='Phase')
        axs[t, 1].set_xlabel('Receive Antenna')
        axs[t, 1].set_ylabel('Transmit Antenna')
        axs[t, 1].set_title(f'Time Slot {t+1} - Phase')
        axs[t, 1].grid(True)
        axs[t, 1].set_xticks(rx_ant)
        axs[t, 1].set_yticks(tx_ant)
    
        # 实部子图
        real_part = np.real(H)
        im = axs[t, 2].imshow(real_part, aspect='auto', 
                               extent=[rx_ant[0], rx_ant[-1], tx_ant[0], tx_ant[-1]],
                               origin='lower', cmap='viridis')
        fig.colorbar(im, ax=axs[t, 2], label='Real Part')
        axs[t, 2].set_xlabel('Receive Antenna')
        axs[t, 2].set_ylabel('Transmit Antenna')
        axs[t, 2].set_title(f'Time Slot {t+1} - Real Part')
        axs[t, 2].grid(True)
        axs[t, 2].set_xticks(rx_ant)
        axs[t, 2].set_yticks(tx_ant)
    
        # 虚部子图
        imag_part = np.imag(H)
        im = axs[t, 3].imshow(imag_part, aspect='auto',
                               extent=[rx_ant[0], rx_ant[-1], tx_ant[0], tx_ant[-1]],
                               origin='lower', cmap='plasma')
        fig.colorbar(im, ax=axs[t, 3], label='Imaginary Part')
        axs[t, 3].set_xlabel('Receive Antenna')
        axs[t, 3].set_ylabel('Transmit Antenna')
        axs[t, 3].set_title(f'Time Slot {t+1} - Imaginary Part')
        axs[t, 3].grid(True)
        axs[t, 3].set_xticks(rx_ant)
        axs[t, 3].set_yticks(tx_ant)
    
    plt.tight_layout()
    plt.show()
    
    
def compute_reward_mse(H_in):
    """
    计算任意相邻时隙之间 H_in 的均方误差 (MSE) 并定义 reward

    参数:
        H_in: ndarray，形状为 (time_slots, num_tx, num_rx)
              其中假设至少有两个时隙的数据
    
    返回:
        rewards: ndarray，长度为 time_slots-1 的数组
                包含每对相邻时隙之间的reward
    """
    num_tx=H_in.shape[-2]
    num_rx=H_in.shape[-1]
    if H_in.shape[0] < 2:
        raise ValueError("H_in 必须包含至少两个时隙的数据")
    
    time_slots = H_in.shape[0]
    rewards = []
    
    # 计算每对相邻时隙之间的MSE
    for t in range(time_slots - 1):
        mse = np.mean(np.square(H_in[t] - H_in[t+1]))
        reward = np.abs(mse)
        rewards.append(reward)
    
    return np.mean(rewards)/(num_tx*num_rx) 
def calculate_mimo_power(H_in,use_db=True):
    """
    计算MIMO信道功率
    H_in: ndarray，形状为 (time_slots, num_tx, num_rx)
    total_power, avg_power: ndarray，形状为 (time_slots,)
    """
    time_slots, num_tx, num_rx = H_in.shape
    total_power = np.zeros(time_slots)
    avg_power = np.zeros(time_slots)
    
    for t in range(time_slots):
        H_t = H_in[t]
        power = np.sum(np.abs(H_t)**2)
        total_power[t] = power
        avg_power[t] = power / (num_tx * num_rx)
    if use_db:
        total_power_db = 10 * np.log10(total_power)
        avg_power_db = 10 * np.log10(avg_power)
        return total_power_db, avg_power_db
    return total_power, avg_power


def clean_complex_data(x, threshold=0.01):
    """
    清理复数数组，实部或虚部小于threshold的部分舍去
    """
    x = np.array(x)
    # 处理实部
    real_part = np.real(x)
    real_part[np.abs(real_part) < threshold] = 0
    
    # 处理虚部 
    imag_part = np.imag(x)
    imag_part[np.abs(imag_part) < threshold] = 0
    
    return real_part + 1j * imag_part

def moving_average(a, window_size):
    cumulative_sum = np.cumsum(np.insert(a, 0, 0)) 
    middle = (cumulative_sum[window_size:] - cumulative_sum[:-window_size]) / window_size
    r = np.arange(1, window_size-1, 2)
    begin = np.cumsum(a[:window_size-1])[::2] / r
    end = (np.cumsum(a[:-window_size:-1])[::2] / r)[::-1]
    return np.concatenate((begin, middle, end))
def plot_and_save_returns_raw(return_list, env_name, save_dir='../out', 
                         window_size=9, figsize=(15, 5)):
    """
    绘制并保存训练返回值图表
    
    参数:
    return_list: 返回值列表
    env_name: 环境名称
    save_dir: 保存目录
    window_size: 移动平均窗口大小
    figsize: 图形大小
    """
    import matplotlib.pyplot as plt
    import os
    
    # 创建保存目录(如果不存在)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
        
    episodes_list = list(range(len(return_list)))
    
    # 创建单个图形包含两个子图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)
    
    # 左侧原始返回值图
    ax1.plot(episodes_list, return_list, color='blue', alpha=0.6, label='Original')
    ax1.set_xlabel('Episodes')
    ax1.set_ylabel('Returns')
    ax1.set_title('Original Returns')
    ax1.grid(True, linestyle='--', alpha=0.7)
    ax1.legend()
    
    # 右侧移动平均图
    mv_return = moving_average(return_list, window_size)
    ax2.plot(episodes_list, mv_return, color='red', 
             label=f'Moving Average (window={window_size})')
    ax2.set_xlabel('Episodes')
    ax2.set_ylabel('Returns')
    ax2.set_title('Moving Average Returns')
    ax2.grid(True, linestyle='--', alpha=0.7)
    ax2.legend()
    
    # 设置整体标题
    fig.suptitle('SAC on {}'.format(env_name), fontsize=16, y=1.05)
    
    # 调整子图之间的间距
    plt.tight_layout()
    
    # 保存图片
    save_path = os.path.join(save_dir, f'{env_name}.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    return save_path

    # 使用示例
    # plot_and_save_returns(return_list, env_name)




def visualize_3d_data(data, threshold=-50, colorscale='Viridis', 
                      title='3D Visualization of CSI in a Single Time Slot', 
                      width=1000, height=800, point_size=4, opacity=0.9,
                      font_family="Arial", title_font_size=24, axis_font_size=16, 
                      tickfont_size=14, colorbar_font_size=16):
    """
    创建数据的3D交互式可视化。
    
    参数:
    data (numpy.ndarray): 三维数组，形状为(dim1, dim2, dim3)
    threshold (float): 数据过滤阈值，只显示绝对值大于此值的数据点
    colorscale (str): 颜色方案，例如'Viridis'、'Plasma'、'Inferno'等
    title (str): 图表标题
    width (int): 图表宽度
    height (int): 图表高度
    point_size (int): 点的大小
    opacity (float): 点的透明度，范围为0到1
    font_family (str): 字体名称，如"Arial"、"Times New Roman"、"Courier New"等
    title_font_size (int): 标题字号
    axis_font_size (int): 坐标轴标题字号
    tickfont_size (int): 坐标轴刻度字号
    colorbar_font_size (int): 颜色条字号
    
    返回:
    plotly.graph_objects.Figure: 可视化图表对象
    """
    # 检查输入数据
    if not isinstance(data, np.ndarray) or len(data.shape) != 3:
        raise ValueError("数据必须是三维numpy数组")
    
    # 获取数据维度
    dim1, dim2, dim3 = data.shape
    
    # 定义显示阈值，过滤数据点
    mask = np.abs(data) > threshold
    
    # 获取满足条件的点的坐标
    x, y, z = np.where(mask)
    values = data[x, y, z]
    
    # 创建交互式3D散点图
    fig = go.Figure(data=[go.Scatter3d(
        x=x,
        y=y,
        z=z,
        mode='markers',
        marker=dict(
            size=point_size,
            color=values,  # 点的颜色由值决定
            colorscale=colorscale,  # 选择颜色方案
            opacity=opacity,
            colorbar=dict(
                title=dict(  # 使用title字典而不是titlefont
                    text="Relative Channel Strength",
                    font=dict(
                        family=font_family,
                        size=colorbar_font_size
                    )
                ),
                tickfont=dict(
                    family=font_family,
                    size=tickfont_size
                )
            ),
        )
    )])
    
    # 设置布局
    fig.update_layout(
        title=dict(
            text=title,
            font=dict(
                family=font_family,
                size=title_font_size
            )
        ),
        scene=dict(
            xaxis_title=dict(
                text=f'Number of subcarriers ({dim1})',
                font=dict(
                    family=font_family,
                    size=axis_font_size
                )
            ),
            yaxis_title=dict(
                text=f'num_tx ({dim2})',
                font=dict(
                    family=font_family,
                    size=axis_font_size
                )
            ),
            zaxis_title=dict(
                text=f'num_rx ({dim3})',
                font=dict(
                    family=font_family,
                    size=axis_font_size
                )
            ),
            xaxis=dict(
                range=[0, dim1],
                tickfont=dict(
                    family=font_family,
                    size=tickfont_size
                )
            ),
            yaxis=dict(
                range=[0, dim2],
                tickfont=dict(
                    family=font_family,
                    size=tickfont_size
                )
            ),
            zaxis=dict(
                range=[0, dim3],
                tickfont=dict(
                    family=font_family,
                    size=tickfont_size
                )
            )
        ),
        width=width,
        height=height,
        font=dict(
            family=font_family  # 设置整体默认字体
        )
    )
    
    return fig

# # 使用方式：创建并显示3D可视化，指定字体和字号
# fig = visualize_3d_data(
#     input_data, 
#     threshold=0.5,
#     font_family="Times New Roman", 
#     title_font_size=24,  
#     axis_font_size=20,
#     tickfont_size=14,
#     colorbar_font_size=24
# )
# fig.show()


def plot_complex_sequence(z, title='Complex Sequence Visualization in Complex Plane', show_phase_for_every=3, 
                          cmap='viridis', figsize=(10, 10), show_labels=True, show_magnitude_circles=False):
    """
    在复平面上可视化复数序列
    
    参数:
        z: 复数序列，numpy数组或列表
        title: 图表标题
        show_phase_for_every: 每隔多少个元素显示一次相位弧，设为1表示全部显示
        cmap: 颜色映射名称
        figsize: 图像大小
        show_labels: 是否显示标签和说明
        show_magnitude_circles: 是否显示表示幅度的虚线圆
    
    返回:
        fig, ax: matplotlib的图形对象和轴对象
    """
    z = np.array(z, dtype=complex)
    n = len(z)
    
    # 创建图表
    fig = plt.figure(figsize=figsize)
    ax = plt.subplot(111)
    
    # 设置坐标轴范围，确保原点在中心
    max_abs = np.max(np.abs(z)) * 1.2
    plt.xlim(-max_abs, max_abs)
    plt.ylim(-max_abs, max_abs)
    
    # 绘制坐标轴
    plt.axhline(y=0, color='k', linestyle='-', alpha=0.3)
    plt.axvline(x=0, color='k', linestyle='-', alpha=0.3)
    plt.grid(alpha=0.3)
    plt.axis('equal')
    
    # 创建颜色映射
    colors = plt.cm.get_cmap(cmap)(np.linspace(0, 1, n))
    
    # 绘制复数点
    for i, complex_num in enumerate(z):
        # 提取实部和虚部
        real = np.real(complex_num)
        imag = np.imag(complex_num)
        
        # 计算幅度和相位
        magnitude = np.abs(complex_num)
        phase = np.angle(complex_num)
        
        # 绘制从原点到复数点的向量
        ax.plot([0, real], [0, imag], '-', color=colors[i], alpha=0.7, linewidth=1.5)
        
        # 绘制复数点
        ax.plot(real, imag, 'o', color=colors[i], markersize=8)
        
        # 标记点的序号
        if show_labels:
            ax.text(real*1.1, imag*1.1, f'{i+1}', fontsize=9, color=colors[i])
        
        # 绘制幅度标记（虚线圆）- 现在根据参数决定是否显示
        if show_magnitude_circles:
            circle = plt.Circle((0, 0), magnitude, fill=False, linestyle='--', 
                                alpha=0.2, color=colors[i])
            ax.add_patch(circle)
        
        # 绘制相位弧（角度）
        if i % show_phase_for_every == 0:  # 为避免过于拥挤，只显示部分点的相位弧
            arc = Arc((0, 0), magnitude/2, magnitude/2, 
                      theta1=0, theta2=np.degrees(phase),
                      linestyle='-', color=colors[i], linewidth=1.5, alpha=0.7)
            ax.add_patch(arc)
            
            # 计算相位弧末端的坐标
            arc_end_x = (magnitude/4) * np.cos(phase)
            arc_end_y = (magnitude/4) * np.sin(phase)
            
            # 在相位弧末端添加相位值标签
            if show_labels:
                phase_deg = np.degrees(phase) % 360
                ax.text(arc_end_x*1.2, arc_end_y*1.2, 
                        f'{phase_deg:.1f}°', fontsize=8, color=colors[i])
    
    # 添加图例和标签
    plt.title(title)
    plt.xlabel('Real')
    plt.ylabel('Imaginary')
    
    # 添加颜色条，表示序列的顺序
    sm = plt.cm.ScalarMappable(cmap=plt.cm.get_cmap(cmap), 
                               norm=plt.Normalize(1, n))
    sm.set_array([])
    cbar = plt.colorbar(sm)
    cbar.set_label('Sequence Element Index')
    
    # 添加说明
    if show_labels:
        if show_magnitude_circles:
            description = '• Colors represent order in sequence\n• Dashed circles show magnitudes\n• Arcs represent phase angles'
        else:
            description = '• Colors represent order in sequence\n• Arcs represent phase angles'
        
        plt.text(-max_abs*0.95, -max_abs*0.9, description, 
                fontsize=10, bbox=dict(facecolor='white', alpha=0.7))
    
    plt.axis('equal')
    plt.tight_layout()
    
    return fig, ax
#使用示例：
# # 示例1：螺旋序列
# n = 20
# theta = np.linspace(0, 4*np.pi, n)
# r = np.linspace(0.5, 5, n)
# z_spiral = r * np.exp(1j * theta)

#     # 绘制示例1
# fig1, ax1 = plot_complex_sequence(z_spiral, title="Spiral Complex Sequence")
# plt.show()