import random
import numpy as np
import torch
import torch.nn.functional as F
import gym
from torch.distributions import Categorical
import matplotlib.pyplot as plt
from tqdm import tqdm
import os
import time

# ---------------------------
# 1. 定义 Replay Buffer
# ---------------------------
class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.position = 0

    def push(self, state, action, reward, next_state, done):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (state, action, reward, next_state, done)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        transitions = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*transitions)
        return {
            "states": np.array(state),
            "actions": np.array(action),
            "rewards": np.array(reward),
            "next_states": np.array(next_state),
            "dones": np.array(done)
        }

    def __len__(self):
        return len(self.buffer)

# ---------------------------
# 2. 定义具有交互效应的多维离散动作环境
# ---------------------------
class InteractiveMultiDiscreteEnv(gym.Env):
    """具有强动作维度交互效应的环境"""
    def __init__(self, num_action_dims=3, num_choices=4):
        super(InteractiveMultiDiscreteEnv, self).__init__()
        self.num_action_dims = num_action_dims
        self.num_choices = num_choices
        self.observation_space = gym.spaces.Box(low=-1, high=1, shape=(num_action_dims * 2,), dtype=np.float32)
        self.action_space = gym.spaces.MultiDiscrete([num_choices] * num_action_dims)
        self.max_steps = 100
        self.current_step = 0
        self.state = None
        
        # 预计算奖励表
        self._precompute_reward_tables()
        
    def _precompute_reward_tables(self):
        """预计算常见的奖励模式，提高效率"""
        # 基本的维度对奖励
        self.pair_rewards = {}
        for i in range(self.num_choices):
            for j in range(self.num_choices):
                # 某些特定的动作组合会产生额外奖励
                # 例如：偶数+奇数组合
                self.pair_rewards[(i, j)] = 1.0 if i % 2 == 0 and j % 2 == 1 else 0.0
                
        # 预计算每个动作的奇偶性，以便快速检查
        self.parity = [i % 2 for i in range(self.num_choices)]

    def reset(self):
        self.current_step = 0
        self.state = np.random.uniform(-0.5, 0.5, size=(self.num_action_dims * 2,))
        return self.state.copy()

    def step(self, action):
        self.current_step += 1
        
        # 计算奖励
        reward = self._calculate_reward(action)
        
        # 更新状态
        self._update_state(action)
        
        done = self.current_step >= self.max_steps
        return self.state.copy(), reward, done, {}

    def _calculate_reward(self, action):
        """计算具有强交互效应的奖励"""
        reward = 0.0
        
        # 1. 基本的状态-动作匹配奖励
        for i in range(self.num_action_dims):
            state_indicator = self.state[i] + 0.5  # 转换到[0,1]范围
            optimal_action = int(state_indicator * (self.num_choices - 1) + 0.5)
            action_similarity = 1.0 - abs(action[i] - optimal_action) / (self.num_choices - 1)
            reward += 0.3 * action_similarity
        
        # 2. 动作维度对之间的交互奖励
        if self.num_action_dims >= 2:
            # 遍历所有可能的维度对
            for i in range(self.num_action_dims - 1):
                pair_key = (action[i], action[i+1])
                if pair_key in self.pair_rewards:
                    reward += self.pair_rewards[pair_key]
            
            # 特殊情况：所有动作相同时的惩罚
            if len(set(action)) == 1:
                reward -= 0.5
                
            # 特殊情况：所有动作交替奇偶性时的奖励
            alternating = True
            for i in range(self.num_action_dims - 1):
                if self.parity[action[i]] == self.parity[action[i+1]]:
                    alternating = False
                    break
            if alternating:
                reward += 0.8
        
        # 3. 三维或更高维度的交互
        if self.num_action_dims >= 3:
            # 例如：前三个动作的和符合特定条件时有奖励
            first_three_sum = sum(action[:3])
            target_sum = 3 * (self.num_choices - 1) / 2  # 目标值是动作范围的中间值
            if abs(first_three_sum - target_sum) <= 1:
                reward += 0.5
        
        return reward

    def _update_state(self, action):
        """更新状态，包含动作交互效应"""
        noise = np.random.normal(0, 0.1, size=self.state.shape)
        
        # 计算动作效应
        action_effects = np.zeros_like(self.state)
        
        # 单个动作的效应
        for i in range(self.num_action_dims):
            effect = (action[i] / (self.num_choices - 1) - 0.5) * 0.2
            action_effects[i] += effect
            
            # 动作间交互效应对状态的影响
            if i + 1 < self.num_action_dims:
                # 相邻动作的交互效应
                next_effect = (action[i+1] / (self.num_choices - 1) - 0.5) * 0.2
                # 如果两个相邻动作一奇一偶，产生更强的效应
                if self.parity[action[i]] != self.parity[action[i+1]]:
                    action_effects[i] += next_effect * 0.3
                    action_effects[i+1] += effect * 0.3
        
        # 应用动作效应和随机噪声
        self.state += action_effects + noise
        
        # 确保状态在有效范围内
        self.state = np.clip(self.state, -1.0, 1.0)
class LargeScaleInteractiveEnv(gym.Env):
    """大规模选择空间中有交互效应的环境"""
    def __init__(self, num_action_dims=3, num_choices=200):
        super(LargeScaleInteractiveEnv, self).__init__()
        self.num_action_dims = num_action_dims
        self.num_choices = num_choices
        self.observation_space = gym.spaces.Box(low=-1, high=1, shape=(num_action_dims * 3,), dtype=np.float32)
        self.action_space = gym.spaces.MultiDiscrete([num_choices] * num_action_dims)
        self.max_steps = 100
        self.current_step = 0
        self.state = None
        
        # 为提高效率，预计算一些值
        self._precompute_values()
        
    def _precompute_values(self):
        """预计算常见的模式和奖励系数"""
        # 将动作划分为区间段，减少计算复杂度
        self.segments = 10  # 将动作划分为10个区间
        self.segment_size = self.num_choices // self.segments
        
        # 区间对之间的兼容性矩阵 (10x10矩阵比num_choices x num_choices小得多)
        self.compatibility = np.zeros((self.segments, self.segments))
        for i in range(self.segments):
            for j in range(self.segments):
                # 某些区间组合会更好：互补区间的奖励更高
                self.compatibility[i, j] = 1.0 if abs(i - j) > self.segments // 2 else 0.2
                
        # 优化区间：某些特定区间内的动作会有额外奖励
        self.optimal_regions = [np.random.randint(0, self.segments) for _ in range(self.num_action_dims)]
        
    def reset(self):
        self.current_step = 0
        self.state = np.random.uniform(-0.8, 0.8, size=(self.num_action_dims * 3,))
        return self.state.copy()

    def step(self, action):
        self.current_step += 1
        
        # 计算奖励
        reward = self._calculate_reward(action)
        
        # 更新状态
        self._update_state(action)
        
        done = self.current_step >= self.max_steps
        return self.state.copy(), reward, done, {}

    def _calculate_reward(self, action):
        """计算具有复杂交互效应的奖励"""
        reward = 0.0
        
        # 1. 将动作映射到区间
        action_segments = [min(a // self.segment_size, self.segments - 1) for a in action]
        
        # 2. 状态-动作匹配奖励：基于状态的最优动作区间
        for i in range(self.num_action_dims):
            state_value = self.state[i * 3]  # 使用状态的主要部分
            # 计算这个状态下的最优区间
            optimal_segment = int((state_value + 1) / 2 * self.segments)
            optimal_segment = max(0, min(optimal_segment, self.segments - 1))
            
            # 比较动作区间与最优区间的接近程度
            segment_diff = abs(action_segments[i] - optimal_segment)
            segment_similarity = 1.0 - segment_diff / self.segments
            reward += 0.5 * segment_similarity
        
        # 3. 维度对之间的交互奖励
        if self.num_action_dims >= 2:
            for i in range(self.num_action_dims - 1):
                seg_i, seg_j = action_segments[i], action_segments[i+1]
                reward += self.compatibility[seg_i, seg_j]
            
            # 特殊奖励：所有动作都在不同区间
            if len(set(action_segments)) == len(action_segments):
                reward += 0.5
        
        # 4. 集体行为奖励：动作的整体分布与目标分布的接近程度
        action_mean = sum(action) / len(action)
        action_range = max(action) - min(action)
        
        # 奖励适度分散的动作选择 (既不全聚集也不全分散)
        target_range = self.num_choices * 0.6
        range_similarity = 1.0 - abs(action_range - target_range) / self.num_choices
        reward += 0.3 * range_similarity
        
        # 中位数奖励：整体选择在中间区域时额外奖励
        middle_bias = 1.0 - abs(action_mean - self.num_choices / 2) / (self.num_choices / 2)
        reward += 0.2 * middle_bias
        
        return reward

    def _update_state(self, action):
        """更新状态，体现复杂的动作交互效应"""
        noise = np.random.normal(0, 0.05, size=self.state.shape)
        
        # 每个动作对应状态的3个分量
        for i in range(self.num_action_dims):
            # 标准化动作到[-1,1]区间
            norm_action = action[i] / (self.num_choices - 1) * 2 - 1
            
            # 主要状态分量
            self.state[i * 3] = 0.9 * self.state[i * 3] + 0.1 * norm_action
            
            # 次要状态分量（受前后动作影响）
            if i > 0:  # 受前一个动作影响
                prev_norm_action = action[i-1] / (self.num_choices - 1) * 2 - 1
                self.state[i * 3 + 1] = 0.8 * self.state[i * 3 + 1] + 0.2 * (norm_action + prev_norm_action) / 2
            
            if i < self.num_action_dims - 1:  # 受后一个动作影响
                next_norm_action = action[i+1] / (self.num_choices - 1) * 2 - 1
                self.state[i * 3 + 2] = 0.8 * self.state[i * 3 + 2] + 0.2 * (norm_action + next_norm_action) / 2
        
        # 应用噪声并确保状态在有效范围内
        self.state += noise
        self.state = np.clip(self.state, -1.0, 1.0)

class PatternMatchingEnv(gym.Env):
    """需要发现特定动作模式的环境，模拟复杂配置优化问题"""
    def __init__(self, num_action_dims=4, num_choices=200):
        super(PatternMatchingEnv, self).__init__()
        self.num_action_dims = num_action_dims
        self.num_choices = num_choices
        self.observation_space = gym.spaces.Box(low=-1, high=1, shape=(num_action_dims + 2,), dtype=np.float32)
        self.action_space = gym.spaces.MultiDiscrete([num_choices] * num_action_dims)
        self.max_steps = 150
        self.current_step = 0
        self.state = None
        
        # 定义特定的动作模式，代表"最优配置"
        self._generate_optimal_patterns()
        
    def _generate_optimal_patterns(self):
        """生成最优动作模式和对应的奖励"""
        # 模式1：动作之间的比例关系
        # 例如：第一个动作是第二个动作的2倍，第三个动作是前两个的平均值等
        self.ratio_patterns = []
        for _ in range(3):  # 几种不同的比例模式
            pattern = []
            for i in range(self.num_action_dims):
                if i == 0:
                    # 第一个动作的基准值（随机）
                    base = np.random.randint(self.num_choices // 4, 3 * self.num_choices // 4)
                    pattern.append(base)
                else:
                    # 其他动作基于比例关系
                    ratio = np.random.choice([0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
                    val = int(pattern[0] * ratio)
                    val = max(0, min(val, self.num_choices - 1))
                    pattern.append(val)
            self.ratio_patterns.append((pattern, np.random.uniform(0.5, 1.5)))
            
        # 模式2：动作之间的差值关系
        self.diff_patterns = []
        for _ in range(2):
            pattern = []
            for i in range(self.num_action_dims):
                if i == 0:
                    # 第一个动作的基准值
                    base = np.random.randint(self.num_choices // 4, 3 * self.num_choices // 4)
                    pattern.append(base)
                else:
                    # 其他动作基于差值关系
                    diff = np.random.randint(-self.num_choices // 8, self.num_choices // 8)
                    val = pattern[i-1] + diff
                    val = max(0, min(val, self.num_choices - 1))
                    pattern.append(val)
            self.diff_patterns.append((pattern, np.random.uniform(0.5, 1.5)))
            
        # 模式3：特定区域模式
        num_regions = 5
        region_size = self.num_choices // num_regions
        self.region_patterns = []
        for _ in range(2):
            pattern = []
            regions = np.random.choice(range(num_regions), size=self.num_action_dims, replace=True)
            for i in range(self.num_action_dims):
                region = regions[i]
                min_val = region * region_size
                max_val = (region + 1) * region_size - 1
                pattern.append((min_val, max_val))
            self.region_patterns.append((pattern, np.random.uniform(0.5, 1.5)))

    def reset(self):
        self.current_step = 0
        self.state = np.random.uniform(-0.8, 0.8, size=(self.num_action_dims + 2,))
        # 更新状态，提示当前环境倾向的模式类型
        self.current_pattern_type = np.random.choice(['ratio', 'diff', 'region'])
        if self.current_pattern_type == 'ratio':
            self.state[-2] = 0.5  # 模式类型指示器
        elif self.current_pattern_type == 'diff':
            self.state[-2] = 0.0
        else:  # region
            self.state[-2] = -0.5
            
        # 随机选择一个具体模式
        if self.current_pattern_type == 'ratio':
            self.active_pattern = np.random.choice(len(self.ratio_patterns))
            self.state[-1] = self.active_pattern / len(self.ratio_patterns) * 2 - 1
        elif self.current_pattern_type == 'diff':
            self.active_pattern = np.random.choice(len(self.diff_patterns))
            self.state[-1] = self.active_pattern / len(self.diff_patterns) * 2 - 1
        else:  # region
            self.active_pattern = np.random.choice(len(self.region_patterns))
            self.state[-1] = self.active_pattern / len(self.region_patterns) * 2 - 1
            
        return self.state.copy()

    def step(self, action):
        self.current_step += 1
        
        # 计算奖励
        reward = self._calculate_reward(action)
        
        # 更新状态
        self._update_state(action)
        
        done = self.current_step >= self.max_steps
        return self.state.copy(), reward, done, {}

    def _calculate_reward(self, action):
        """计算奖励，取决于动作与当前活跃模式的匹配程度"""
        reward = 0.0
        
        # 基础奖励：基于各个维度状态和动作的匹配度
        for i in range(self.num_action_dims):
            state_factor = self.state[i] * 0.5 + 0.5  # 将[-1,1]映射到[0,1]
            optimal_raw = state_factor * (self.num_choices - 1)
            distance = abs(action[i] - optimal_raw) / (self.num_choices - 1)
            reward += 0.2 * (1 - distance)
        
        # 模式匹配奖励
        pattern_reward = 0.0
        
        if self.current_pattern_type == 'ratio':
            pattern, pattern_weight = self.ratio_patterns[self.active_pattern]
            # 计算动作比例与模式比例的匹配度
            match_score = 0.0
            for i in range(1, self.num_action_dims):
                if pattern[0] == 0:  # 避免除以零
                    continue
                expected_ratio = pattern[i] / pattern[0]
                if action[0] == 0:  # 避免除以零
                    actual_ratio = float('inf')
                else:
                    actual_ratio = action[i] / action[0]
                ratio_diff = abs(expected_ratio - actual_ratio) / max(expected_ratio, 1)
                match_score += (1 - min(ratio_diff, 1)) / (self.num_action_dims - 1)
            pattern_reward = match_score * pattern_weight

        elif self.current_pattern_type == 'diff':
            pattern, pattern_weight = self.diff_patterns[self.active_pattern]
            # 计算动作差值与模式差值的匹配度
            match_score = 0.0
            for i in range(1, self.num_action_dims):
                expected_diff = pattern[i] - pattern[i-1]
                actual_diff = action[i] - action[i-1]
                diff_match = 1.0 - min(abs(expected_diff - actual_diff) / self.num_choices, 1.0)
                match_score += diff_match / (self.num_action_dims - 1)
            pattern_reward = match_score * pattern_weight
            
        else:  # region pattern
            pattern, pattern_weight = self.region_patterns[self.active_pattern]
            # 计算动作是否落在期望区域内
            match_score = 0.0
            for i in range(self.num_action_dims):
                min_val, max_val = pattern[i]
                if min_val <= action[i] <= max_val:
                    match_score += 1.0
                else:
                    # 计算到最近区域边界的距离
                    dist = min(abs(action[i] - min_val), abs(action[i] - max_val))
                    dist_norm = dist / self.num_choices
                    match_score += max(0, 1 - 2 * dist_norm)  # 距离越小，分数越高
            match_score /= self.num_action_dims
            pattern_reward = match_score * pattern_weight
        
        # 综合奖励
        reward = 0.3 * reward + 0.7 * pattern_reward
        
        return reward

    def _update_state(self, action):
        """更新状态，反映动作的效果"""
        noise = np.random.normal(0, 0.05, size=(self.num_action_dims,))
        
        # 更新与动作维度相关的状态
        for i in range(self.num_action_dims):
            # 将动作标准化到[-1,1]
            norm_action = action[i] / (self.num_choices - 1) * 2 - 1
            
            # 状态更新公式：随机移动+微小动作偏好
            self.state[i] = 0.85 * self.state[i] + 0.15 * norm_action + noise[i]
        
        # 确保状态在有效范围内
        self.state[:self.num_action_dims] = np.clip(self.state[:self.num_action_dims], -1.0, 1.0)
        # 模式类型和具体模式索引保持不变

# ---------------------------
# 3. 高效的策略网络
# ---------------------------
class EfficientPolicyNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, num_action_dims, num_choices):
        super(EfficientPolicyNet, self).__init__()
        self.backbone = torch.nn.Sequential(
            torch.nn.Linear(state_dim, hidden_dim),
            torch.nn.ELU(),
            torch.nn.Linear(hidden_dim, hidden_dim),
            torch.nn.ELU()
        )
        
        # 为每个动作维度创建独立的输出头
        self.action_heads = torch.nn.ModuleList([
            torch.nn.Linear(hidden_dim, num_choices) for _ in range(num_action_dims)
        ])

    def forward(self, x):
        features = self.backbone(x)
        logits = [head(features).unsqueeze(1) for head in self.action_heads]
        logits = torch.cat(logits, dim=1)  # [batch, num_action_dims, num_choices]
        probs = F.softmax(logits, dim=-1)
        return probs

# ---------------------------
# 4. 结合注意力机制和交互层的Q网络
# ---------------------------
class AttentionInteractiveQNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, num_action_dims, num_choices):
        super(AttentionInteractiveQNet, self).__init__()
        self.num_action_dims = num_action_dims
        reduced_dim = hidden_dim // 2  # 减小维度以提高效率
        
        # 基础特征提取
        self.state_encoder = torch.nn.Sequential(
            torch.nn.Linear(state_dim, hidden_dim),
            torch.nn.ELU(),
            torch.nn.Linear(hidden_dim, reduced_dim),
            torch.nn.ELU()
        )
        
        # 为每个动作维度创建可训练的嵌入
        self.dim_embeddings = torch.nn.Parameter(
            torch.randn(num_action_dims, reduced_dim)
        )
        
        # 简化的自注意力机制 (轻量级键值注意力)
        self.key_proj = torch.nn.Linear(reduced_dim, reduced_dim)
        self.query_proj = torch.nn.Linear(reduced_dim, reduced_dim)
        self.value_proj = torch.nn.Linear(reduced_dim, reduced_dim)
        self.attention_scale = float(reduced_dim) ** -0.5
        
        # 交互层 - 建模维度间关系
        self.interaction_layer = torch.nn.Sequential(
            torch.nn.Linear(reduced_dim, reduced_dim),
            torch.nn.ELU(),
            torch.nn.Linear(reduced_dim, reduced_dim),
            torch.nn.ELU()
        )
        
        # 输出投影层
        self.output_proj = torch.nn.Linear(reduced_dim * 2, reduced_dim)
        
        # 输出头 - 每个维度一个
        self.output_heads = torch.nn.ModuleList([
            torch.nn.Linear(reduced_dim, num_choices) for _ in range(num_action_dims)
        ])
        
    def forward(self, x):
        batch_size = x.size(0)
        
        # 1. 提取状态特征
        state_features = self.state_encoder(x)  # [batch, reduced_dim]
        
        # 2. 准备动作维度嵌入
        dim_embeds = self.dim_embeddings.unsqueeze(0).expand(batch_size, -1, -1)  # [batch, num_dims, reduced_dim]
        
        # 3. 合并状态信息到维度嵌入
        dim_features = dim_embeds + state_features.unsqueeze(1)  # [batch, num_dims, reduced_dim]
        
        # 4. 计算注意力
        # 生成查询、键、值
        queries = self.query_proj(dim_features)  # [batch, num_dims, reduced_dim]
        keys = self.key_proj(dim_features)  # [batch, num_dims, reduced_dim]
        values = self.value_proj(dim_features)  # [batch, num_dims, reduced_dim]
        
        # 计算注意力分数
        scores = torch.bmm(queries, keys.transpose(1, 2)) * self.attention_scale  # [batch, num_dims, num_dims]
        attention_weights = F.softmax(scores, dim=-1)  # [batch, num_dims, num_dims]
        
        # 应用注意力权重
        attended_values = torch.bmm(attention_weights, values)  # [batch, num_dims, reduced_dim]
        
        # 5. 交互层处理
        interaction_features = self.interaction_layer(attended_values)  # [batch, num_dims, reduced_dim]
        
        # 6. 结合原始特征和交互特征 (残差连接)
        combined_features = torch.cat([dim_features, interaction_features], dim=-1)  # [batch, num_dims, reduced_dim*2]
        final_features = self.output_proj(combined_features)  # [batch, num_dims, reduced_dim]
        
        # 7. 生成每个维度的Q值
        q_values = []
        for i, head in enumerate(self.output_heads):
            dim_q = head(final_features[:, i]).unsqueeze(1)  # [batch, 1, num_choices]
            q_values.append(dim_q)
            
        q_values = torch.cat(q_values, dim=1)  # [batch, num_action_dims, num_choices]
        return q_values

# ---------------------------
# 5. 完整的 SAC 算法实现
# ---------------------------
class AttentionInteractiveSAC:
    def __init__(self, state_dim, hidden_dim, num_action_dims, num_choices,
                 actor_lr, critic_lr, alpha_lr, target_entropy, tau, gamma, device,
                 update_interval=1):
        self.device = device
        self.gamma = gamma
        self.tau = tau
        self.target_entropy = target_entropy
        self.num_action_dims = num_action_dims
        self.update_interval = update_interval
        self.update_counter = 0
        
        # 策略网络
        self.actor = EfficientPolicyNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        
        # 注意力交互 Q 网络
        self.critic_1 = AttentionInteractiveQNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        self.critic_2 = AttentionInteractiveQNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        self.target_critic_1 = AttentionInteractiveQNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        self.target_critic_2 = AttentionInteractiveQNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        
        # 复制初始权重到目标网络
        self.target_critic_1.load_state_dict(self.critic_1.state_dict())
        self.target_critic_2.load_state_dict(self.critic_2.state_dict())
        
        # 优化器
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_1_optimizer = torch.optim.Adam(self.critic_1.parameters(), lr=critic_lr)
        self.critic_2_optimizer = torch.optim.Adam(self.critic_2.parameters(), lr=critic_lr)
        
        # 熵系数
        self.log_alpha = torch.tensor(np.log(0.01), dtype=torch.float).to(device)
        self.log_alpha.requires_grad = True
        self.log_alpha_optimizer = torch.optim.Adam([self.log_alpha], lr=alpha_lr)
    def save(self, path):
        """保存模型参数到指定路径"""
        model_state = {
            'actor': self.actor.state_dict(),
            'critic_1': self.critic_1.state_dict(),
            'critic_2': self.critic_2.state_dict(),
            'target_critic_1': self.target_critic_1.state_dict(),
            'target_critic_2': self.target_critic_2.state_dict(),
            'log_alpha': self.log_alpha.item(),
            'actor_optimizer': self.actor_optimizer.state_dict(),
            'critic_1_optimizer': self.critic_1_optimizer.state_dict(),
            'critic_2_optimizer': self.critic_2_optimizer.state_dict(),
            'alpha_optimizer': self.log_alpha_optimizer.state_dict()
        }
        
        torch.save(model_state, path)
        print(f"Model saved to {path}")

    def load(self, path):
        """从指定路径加载模型参数"""
        if not os.path.exists(path):
            print(f"No model found at {path}")
            return False
            
        model_state = torch.load(path, map_location=self.device)
        
        # 加载网络参数
        self.actor.load_state_dict(model_state['actor'])
        self.critic_1.load_state_dict(model_state['critic_1'])
        self.critic_2.load_state_dict(model_state['critic_2'])
        self.target_critic_1.load_state_dict(model_state['target_critic_1'])
        self.target_critic_2.load_state_dict(model_state['target_critic_2'])
        
        # 加载熵参数
        self.log_alpha = torch.tensor(model_state['log_alpha'], 
                                    dtype=torch.float, 
                                    device=self.device, 
                                    requires_grad=True)
        
        # 重新创建优化器
        self.log_alpha_optimizer = torch.optim.Adam([self.log_alpha], lr=3e-4)
        
        # 加载优化器状态
        self.actor_optimizer.load_state_dict(model_state['actor_optimizer'])
        self.critic_1_optimizer.load_state_dict(model_state['critic_1_optimizer'])
        self.critic_2_optimizer.load_state_dict(model_state['critic_2_optimizer'])
        self.log_alpha_optimizer.load_state_dict(model_state['alpha_optimizer'])
        
        print(f"Model loaded from {path}")
        return True
    def take_action(self, state):
        """根据当前策略选择动作"""
        state = np.array([state])
        state = torch.from_numpy(state).float().to(self.device)
        
        with torch.no_grad():
            probs = self.actor(state)  # [1, num_action_dims, num_choices]
        
        actions = []
        for i in range(probs.size(1)):
            distribution = Categorical(probs[:, i, :])
            actions.append(distribution.sample().item())
        
        return np.array(actions)

    def calc_target(self, rewards, next_states, dones):
        """计算目标 Q 值，使用蒙特卡洛采样"""
        with torch.no_grad():
            next_probs = self.actor(next_states)  # [B, K, N]
            next_log_probs = torch.log(next_probs + 1e-8)
            entropy = -torch.sum(next_probs * next_log_probs, dim=2)  # [B, K]
            joint_entropy = torch.sum(entropy, dim=1, keepdim=True)  # [B, 1]
            
            # 使用少量采样估计联合期望 Q 值
            num_samples = max(1, min(3, self.num_action_dims - 1))  # 动态调整采样数量
            
            sampled_q_values = []
            for _ in range(num_samples):
                # 采样完整的动作组合
                actions = []
                for i in range(self.num_action_dims):
                    distrib = Categorical(next_probs[:, i, :])
                    actions.append(distrib.sample().unsqueeze(1))
                actions = torch.cat(actions, dim=1)  # [B, K]
                
                # 获取采样动作的 Q 值
                q1 = self.target_critic_1(next_states)  # [B, K, N]
                q2 = self.target_critic_2(next_states)  # [B, K, N]
                min_q = torch.min(q1, q2)
                
                # 提取这些动作的 Q 值
                indices = actions.unsqueeze(-1)  # [B, K, 1]
                selected_q = min_q.gather(2, indices).squeeze(-1)  # [B, K]
                joint_q = torch.sum(selected_q, dim=1, keepdim=True)  # [B, 1]
                sampled_q_values.append(joint_q)
            
            # 平均所有采样的 Q 值
            expected_q = torch.mean(torch.cat(sampled_q_values, dim=1), dim=1, keepdim=True)
            
            # 计算目标值
            td_target = rewards + self.gamma * (1 - dones) * (expected_q + self.log_alpha.exp() * joint_entropy)
            
            return td_target

    def soft_update(self, net, target_net):
        """软更新目标网络"""
        for param_target, param in zip(target_net.parameters(), net.parameters()):
            param_target.data.copy_(param_target.data * (1.0 - self.tau) + param.data * self.tau)

    def update(self, transition_dict):
        """更新网络参数"""
        self.update_counter += 1
        if self.update_counter % self.update_interval != 0:
            return  # 控制更新频率
            
        states = torch.tensor(transition_dict['states'], dtype=torch.float).to(self.device)
        actions = torch.tensor(transition_dict['actions'], dtype=torch.long).to(self.device)
        rewards = torch.tensor(transition_dict['rewards'], dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(transition_dict['next_states'], dtype=torch.float).to(self.device)
        dones = torch.tensor(transition_dict['dones'], dtype=torch.float).view(-1, 1).to(self.device)

        # 计算目标 Q 值
        td_target = self.calc_target(rewards, next_states, dones)

        # 更新 critic 1
        current_q1 = self.critic_1(states)
        selected_q1 = current_q1.gather(dim=2, index=actions.unsqueeze(-1)).squeeze(-1)
        q1_value = torch.sum(selected_q1, dim=1, keepdim=True)
        critic_1_loss = F.mse_loss(q1_value, td_target)

        self.critic_1_optimizer.zero_grad()
        critic_1_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic_1.parameters(), max_norm=1.0)
        self.critic_1_optimizer.step()

        # 更新 critic 2
        current_q2 = self.critic_2(states)
        selected_q2 = current_q2.gather(dim=2, index=actions.unsqueeze(-1)).squeeze(-1)
        q2_value = torch.sum(selected_q2, dim=1, keepdim=True)
        critic_2_loss = F.mse_loss(q2_value, td_target)

        self.critic_2_optimizer.zero_grad()
        critic_2_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic_2.parameters(), max_norm=1.0)
        self.critic_2_optimizer.step()

        # 更新策略网络
        probs = self.actor(states)
        log_probs = torch.log(probs + 1e-8)
        entropy = -torch.sum(probs * log_probs, dim=2)
        joint_entropy = torch.sum(entropy, dim=1, keepdim=True)

        # 计算当前策略下的 Q 值期望
        with torch.no_grad():
            q1 = self.critic_1(states)
            q2 = self.critic_2(states)
            min_q = torch.min(q1, q2)
            
        expected_q = torch.sum(probs * min_q, dim=2)
        joint_expected_q = torch.sum(expected_q, dim=1, keepdim=True)

        actor_loss = torch.mean(-self.log_alpha.exp() * joint_entropy - joint_expected_q)
        
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1.0)
        self.actor_optimizer.step()

        # 更新熵系数 alpha
        alpha_loss = torch.mean((joint_entropy - self.target_entropy).detach() * self.log_alpha.exp())
        
        self.log_alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.log_alpha_optimizer.step()

        # 软更新目标网络
        self.soft_update(self.critic_1, self.target_critic_1)
        self.soft_update(self.critic_2, self.target_critic_2)

# ---------------------------
# 6. 训练函数
# ---------------------------
def train_agent(env, agent, num_episodes, replay_buffer, minimal_size, batch_size, eval_interval=20):
    return_list = []
    eval_returns = []
    
    start_time = time.time()
    
    for i_episode in tqdm(range(num_episodes)):
        episode_return = 0
        state = env.reset()
        done = False
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            replay_buffer.push(state, action, reward, next_state, done)
            state = next_state
            episode_return += reward

            if len(replay_buffer) > minimal_size:
                transition = replay_buffer.sample(batch_size)
                agent.update(transition)
                
        return_list.append(episode_return)
        
        # 定期记录和评估
        if (i_episode + 1) % 10 == 0:
            avg_return = np.mean(return_list[-10:])
            elapsed_time = time.time() - start_time
            print(f"Episode: {i_episode+1}, Avg Return: {avg_return:.2f}, Time: {elapsed_time:.2f}s")
        
        # 定期评估
        if (i_episode + 1) % eval_interval == 0:
            mean_return, _ = evaluate_agent(env, agent, num_episodes=5)
            eval_returns.append((i_episode + 1, mean_return))
            
    return return_list, eval_returns

# ---------------------------
# 7. 评估函数
# ---------------------------
def evaluate_agent(env, agent, num_episodes=10):
    returns = []
    
    for _ in range(num_episodes):
        episode_return = 0
        state = env.reset()
        done = False
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            episode_return += reward
            state = next_state
            
        returns.append(episode_return)
        
    mean_return = np.mean(returns)
    std_return = np.std(returns)
    
    print(f"Evaluation over {num_episodes} episodes: Mean Return = {mean_return:.2f}, Std = {std_return:.2f}")
    
    return mean_return, std_return

# ---------------------------
# 8. 绘图函数
# ---------------------------
def plot_results(return_list, eval_returns, title, save_dir='./results', window_size=10, figsize=(12, 8)):
    """绘制训练回报曲线和评估结果"""
    os.makedirs(save_dir, exist_ok=True)
    
    # 计算滑动平均
    if window_size > 1:
        smoothed_returns = []
        for i in range(len(return_list)):
            start_idx = max(0, i - window_size + 1)
            smoothed_returns.append(np.mean(return_list[start_idx:i+1]))
    else:
        smoothed_returns = return_list
    
    plt.figure(figsize=figsize)
    
    # 主图: 训练回报
    plt.subplot(2, 1, 1)
    plt.plot(return_list, alpha=0.3, label='Training Returns')
    plt.plot(smoothed_returns, label=f'Smoothed Returns (window={window_size})')
    plt.xlabel('Episode')
    plt.ylabel('Return')
    plt.title(f'{title} - Training Progress')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 第二个子图: 评估回报
    if eval_returns:
        plt.subplot(2, 1, 2)
        episodes, returns = zip(*eval_returns)
        plt.plot(episodes, returns, 'o-', label='Evaluation Returns')
        plt.xlabel('Episode')
        plt.ylabel('Evaluation Return')
        plt.title('Periodic Evaluation Performance')
        plt.legend()
        plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    # 保存图片
    save_path = os.path.join(save_dir, f"{title.replace(' ', '_')}.png")
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"Plot saved to {save_path}")
    
    plt.show()

# ---------------------------
# 9. 测试网络学习到的交互效应
# ---------------------------
def test_action_interactions(env, agent, num_tests=5):
    """测试智能体是否学习到了动作维度之间的交互效应"""
    print("\n=== Testing Action Interactions ===")
    
    # 在固定状态下，用不同动作组合分析奖励
    state = env.reset()
    
    # 测试几种特定的动作组合
    if env.num_action_dims >= 2 and env.num_choices >= 2:
        # 测试已知有交互效应的组合
        print("\nTesting specific action combinations:")
        
        # 1. 偶数+奇数组合 (应该有较高奖励)
        even_odd_actions = np.zeros(env.num_action_dims, dtype=int)
        for i in range(env.num_action_dims):
            even_odd_actions[i] = (i % 2) * 1  # 0, 1, 0, 1, ...
            
        # 2. 全相同的动作 (应该有较低奖励)
        same_actions = np.zeros(env.num_action_dims, dtype=int)
        
        # 测试并比较这些组合
        test_actions = [even_odd_actions, same_actions]
        labels = ["Even-Odd Pattern", "All Same Actions"]
        
        for action, label in zip(test_actions, labels):
            _, reward, _, _ = env.step(action)
            print(f"{label}: {action} -> Reward: {reward:.2f}")
            
            # 重置环境
            state = env.reset()
    
    # 询问agent在多个状态下的动作选择
    print("\nTesting agent's action preferences:")
    for _ in range(num_tests):
        state = env.reset()
        action = agent.take_action(state)
        _, reward, _, _ = env.step(action)
        
        # 检查所选动作是否符合预期的交互模式
        has_alternating_pattern = True
        if env.num_action_dims >= 2:
            for i in range(env.num_action_dims - 1):
                if action[i] % 2 == action[i+1] % 2:  # 相邻动作奇偶性相同
                    has_alternating_pattern = False
                    break
        
        print(f"State: {state[:env.num_action_dims]}, Action: {action}, Reward: {reward:.2f}")
        if has_alternating_pattern:
            print("  -> Agent chose alternating even-odd pattern (good!)")
        
    return True

# ---------------------------
# 10. 主函数
# ---------------------------
def main():
    import json
    import os
    from datetime import datetime
    
    os.chdir("/new_disk/ting/RL/Mycode_2")
    # 创建特定的输出文件夹
    output_dir = os.path.join("../results", "Attention_Interactive_SAC")
    os.makedirs(output_dir, exist_ok=True)
    
    # 创建带时间戳的子文件夹
    timestamp = datetime.now().strftime("%m%d_%H%M%S")
    run_dir = os.path.join(output_dir, f"run_{timestamp}")
    os.makedirs(run_dir, exist_ok=True)
    
    # 配置参数
    params = {
        "actor_lr": 1e-4,
        "critic_lr": 1e-4,
        "alpha_lr": 1e-4,
        "num_episodes": 100,
        "hidden_dim": 64,
        "gamma": 0.98,
        "tau": 0.005,
        "buffer_size": 10000,
        "minimal_size": 500,
        "batch_size": 64,
        "update_interval": 1,
        "eval_interval": 20,
        "num_action_dims": 3,
        "num_choices": 30,
        "env_name": "LargeScaleInteractiveEnv",
        "device": "cuda" if torch.cuda.is_available() else "cpu"
    }
    
    # 将参数保存为JSON文件
    params_file = os.path.join(run_dir, "parameters.json")
    with open(params_file, "w") as f:
        json.dump(params, f, indent=4)
    
    print(f"Parameters saved to {params_file}")
    print(f"Using device: {params['device']}")
    
    # 目标熵与动作维度相关
    target_entropy = -params["num_action_dims"]
    
    # 初始化环境
    if params["env_name"] == "InteractiveMultiDiscreteEnv":
        env = InteractiveMultiDiscreteEnv(params["num_action_dims"], params["num_choices"])
    elif params["env_name"] == "LargeScaleInteractiveEnv":
        env = LargeScaleInteractiveEnv(params["num_action_dims"], params["num_choices"])
    elif params["env_name"] == "PatternMatchingEnv":
        env = PatternMatchingEnv(params["num_action_dims"], params["num_choices"])
    else:
        raise ValueError(f"Unknown environment: {params['env_name']}")
    
    print(f"Environment: {params['env_name']}, Action Dims: {params['num_action_dims']}, Choices: {params['num_choices']}")
    
    state_dim = env.observation_space.shape[0]
    
    # 初始化 replay buffer 和 agent
    replay_buffer = ReplayBuffer(params["buffer_size"])
    agent = AttentionInteractiveSAC(
        state_dim, params["hidden_dim"], params["num_action_dims"], params["num_choices"],
        params["actor_lr"], params["critic_lr"], params["alpha_lr"], target_entropy, 
        params["tau"], params["gamma"], torch.device(params["device"]),
        update_interval=params["update_interval"]
    )
    
    # 训练开始时间
    start_time = time.time()
    
    # 训练
    print("\nStarting training...")
    return_list, eval_returns = train_agent(
        env, agent, params["num_episodes"], replay_buffer, 
        params["minimal_size"], params["batch_size"], params["eval_interval"]
    )
    
    # 记录训练时间
    training_time = time.time() - start_time
    
    # 保存模型
    model_path = os.path.join(run_dir, "agent_model.pt")
    agent.save(model_path)
    print(f"Model saved to {model_path}")
    
    # 最终评估
    print("\nFinal evaluation...")
    num_eval_episodes = 10
    mean_return, std_return = evaluate_agent(env, agent, num_episodes=num_eval_episodes)
    
    # 测试动作交互效应
    interaction_test_results = []
    
    # 记录动作交互测试
    test_state = env.reset()
    
    # 测试已知有交互效应的组合
    if env.num_action_dims >= 2 and env.num_choices >= 2:
        # 偶数+奇数组合 (应该有较高奖励)
        even_odd_actions = np.zeros(env.num_action_dims, dtype=int)
        for i in range(env.num_action_dims):
            even_odd_actions[i] = (i % 2) * 1  # 0, 1, 0, 1, ...
            
        # 全相同的动作 (应该有较低奖励)
        same_actions = np.zeros(env.num_action_dims, dtype=int)
        
        # 记录测试结果
        env.reset()
        _, even_odd_reward, _, _ = env.step(even_odd_actions)
        interaction_test_results.append(f"Even-Odd Pattern: {even_odd_actions} -> Reward: {even_odd_reward:.2f}")
        
        env.reset()
        _, same_action_reward, _, _ = env.step(same_actions)
        interaction_test_results.append(f"All Same Actions: {same_actions} -> Reward: {same_action_reward:.2f}")
    
    # 保存评估结果到txt文件
    results_file = os.path.join(run_dir, "evaluation_results.txt")
    with open(results_file, "w") as f:
        f.write("=== Evaluation Results ===\n\n")
        f.write(f"Mean Return: {mean_return:.4f}\n")
        f.write(f"Standard Deviation: {std_return:.4f}\n")
        f.write(f"Number of Evaluation Episodes: {num_eval_episodes}\n")
        f.write(f"Training Time: {training_time:.2f} seconds\n")
        f.write(f"Average Return (last 10 episodes): {np.mean(return_list[-10:]):.4f}\n")
        
        # 记录最终评估指标
        if eval_returns:
            f.write("\n=== Periodic Evaluation Performance ===\n")
            for episode, eval_return in eval_returns:
                f.write(f"Episode {episode}: {eval_return:.4f}\n")
        
        # 添加训练参数摘要
        f.write("\n=== Training Parameters ===\n")
        f.write(f"Environment: {params['env_name']}\n")
        f.write(f"Action Dimensions: {params['num_action_dims']}\n")
        f.write(f"Choices per Dimension: {params['num_choices']}\n")
        f.write(f"Episodes: {params['num_episodes']}\n")
        f.write(f"Learning Rates - Actor: {params['actor_lr']}, Critic: {params['critic_lr']}, Alpha: {params['alpha_lr']}\n")
        f.write(f"Hidden Dimensions: {params['hidden_dim']}\n")
        
        # 记录动作交互测试结果
        f.write("\n=== Action Interaction Tests ===\n")
        for result in interaction_test_results:
            f.write(f"{result}\n")
    
    print(f"Evaluation results saved to {results_file}")
    
    # 绘制结果
    plot_results(
        return_list, 
        eval_returns,
        f"Attention SAC Return {mean_return:.2f}",
        save_dir=run_dir,  # 保存到子文件夹
        window_size=10
    )

    return agent


# 直接运行
if __name__ == "__main__":
    main()