import random
import numpy as np
import torch
import torch.nn.functional as F
import gym
from torch.distributions import Categorical
import matplotlib.pyplot as plt
from tqdm import tqdm
import os
import time
import math
from torch.optim.lr_scheduler import StepLR

# ---------------------------
# 1. 定义 Replay Buffer
# ---------------------------
class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.position = 0

    def push(self, state, action, reward, next_state, done):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (state, action, reward, next_state, done)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        transitions = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*transitions)
        return {
            "states": np.array(state),
            "actions": np.array(action),
            "rewards": np.array(reward),
            "next_states": np.array(next_state),
            "dones": np.array(done)
        }

    def __len__(self):
        return len(self.buffer)

# ---------------------------
# 2. CNN策略网络
# ---------------------------
class CNNPolicyNet(torch.nn.Module):
    def __init__(self, hidden_dim, num_action_dims, num_choices):
        super(CNNPolicyNet, self).__init__()
        
        # CNN层用于处理2D观测
        self.conv1 = torch.nn.Conv2d(2, 16, kernel_size=3, padding=1)
        self.conv2 = torch.nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.conv3 = torch.nn.Conv2d(32, 32, kernel_size=3, padding=1)
        self.pool = torch.nn.MaxPool2d(kernel_size=2, stride=2)
        
        # 自适应池化层处理可变大小的输入
        self.adaptive_pool = torch.nn.AdaptiveAvgPool2d((4, 4))
        
        # 全连接层
        self.fc1 = torch.nn.Linear(32 * 4 * 4, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        
        # 每个动作维度一个动作头
        self.action_heads = torch.nn.ModuleList([
            torch.nn.Linear(hidden_dim, num_choices) for _ in range(num_action_dims)
        ])

    def forward(self, x):
        # x输入形状为: [batch, 2, num_time_slots*num_tx, num_rx]
        
        # CNN特征提取
        x = F.relu(self.conv1(x))
        x = self.pool(x)
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        x = self.adaptive_pool(x)
        
        # 扁平化处理
        x = x.view(x.size(0), -1)
        
        # 共享特征提取
        x = F.relu(self.fc1(x))
        features = F.relu(self.fc2(x))
        
        # 每个动作维度的策略输出
        logits = [head(features).unsqueeze(1) for head in self.action_heads]
        logits = torch.cat(logits, dim=1)  # [batch, num_action_dims, num_choices]
        
        # 转换为概率分布
        probs = F.softmax(logits, dim=-1)
        
        return probs
    
class EnhancedCNNPolicyNet(torch.nn.Module):
    def __init__(self, hidden_dim, num_action_dims, num_choices):
        super(EnhancedCNNPolicyNet, self).__init__()
        
        # 增加初始特征通道数
        self.conv1 = torch.nn.Conv2d(2, 32, kernel_size=3, padding=1)
        self.bn1 = torch.nn.BatchNorm2d(32)
        
        # 增加深度和通道数
        self.conv2 = torch.nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.bn2 = torch.nn.BatchNorm2d(64)
        
        self.conv3 = torch.nn.Conv2d(64, 128, kernel_size=3, padding=1)
        self.bn3 = torch.nn.BatchNorm2d(128)
        
        self.conv4 = torch.nn.Conv2d(128, 128, kernel_size=3, padding=1)
        self.bn4 = torch.nn.BatchNorm2d(128)
        
        # 最大池化用于下采样
        self.pool = torch.nn.MaxPool2d(kernel_size=2, stride=2)
        
        # 自适应池化以适应不同大小的输入
        self.adaptive_pool = torch.nn.AdaptiveAvgPool2d((6, 6))
        
        # 增加全连接层的维度
        fc_input_dim = 128 * 6 * 6
        self.fc1 = torch.nn.Linear(fc_input_dim, hidden_dim*2)
        self.dropout1 = torch.nn.Dropout(0.3)
        
        self.fc2 = torch.nn.Linear(hidden_dim*2, hidden_dim)
        self.dropout2 = torch.nn.Dropout(0.3)
        
        # 输出层 - 每个动作维度一个头
        self.action_heads = torch.nn.ModuleList([
            torch.nn.Linear(hidden_dim, num_choices) for _ in range(num_action_dims)
        ])
        
        # 初始化权重
        self.apply(self._init_weights)
        
    def _init_weights(self, module):
        if isinstance(module, torch.nn.Conv2d) or isinstance(module, torch.nn.Linear):
            torch.nn.init.kaiming_normal_(module.weight, nonlinearity='relu')
            if module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, torch.nn.BatchNorm2d):
            module.weight.data.fill_(1)
            module.bias.data.zero_()
            
    def forward(self, x):
        # CNN特征提取 - 使用ReLU和BN
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.pool(x)
        
        x = F.relu(self.bn2(self.conv2(x)))
        x = self.pool(x)
        
        x = F.relu(self.bn3(self.conv3(x)))
        x = F.relu(self.bn4(self.conv4(x)))
        
        x = self.adaptive_pool(x)
        
        # 扁平化
        x = x.view(x.size(0), -1)
        
        # 全连接层，使用dropout
        x = F.relu(self.fc1(x))
        x = self.dropout1(x)
        
        features = F.relu(self.fc2(x))
        features = self.dropout2(features)
        
        # 多头输出
        logits = [head(features).unsqueeze(1) for head in self.action_heads]
        logits = torch.cat(logits, dim=1)
        
        # 转换为概率
        probs = F.softmax(logits, dim=-1)
        
        return probs

# ---------------------------
# 3. CNN值网络
# ---------------------------
class CNNQNet(torch.nn.Module):
    def __init__(self, hidden_dim, num_action_dims, num_choices):
        super(CNNQNet, self).__init__()
        
        # CNN层
        self.conv1 = torch.nn.Conv2d(2, 16, kernel_size=3, padding=1)
        self.conv2 = torch.nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.conv3 = torch.nn.Conv2d(32, 32, kernel_size=3, padding=1)
        self.pool = torch.nn.MaxPool2d(kernel_size=2, stride=2)
        
        # 自适应池化层
        self.adaptive_pool = torch.nn.AdaptiveAvgPool2d((4, 4))
        
        # 全连接层
        self.fc1 = torch.nn.Linear(32 * 4 * 4, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        
        # 每个动作维度的Q值头
        self.q_heads = torch.nn.ModuleList([
            torch.nn.Linear(hidden_dim, num_choices) for _ in range(num_action_dims)
        ])

    def forward(self, x):
        # x输入形状为: [batch, 2, num_time_slots*num_tx, num_rx]
        
        # CNN特征提取
        x = F.relu(self.conv1(x))
        x = self.pool(x)
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        x = self.adaptive_pool(x)
        
        # 扁平化处理
        x = x.view(x.size(0), -1)
        
        # 共享特征提取
        x = F.relu(self.fc1(x))
        features = F.relu(self.fc2(x))
        
        # 每个动作维度的Q值输出
        q_values = []
        for head in self.q_heads:
            q = head(features).unsqueeze(1)  # [batch, 1, num_choices]
            q_values.append(q)
        
        q_values = torch.cat(q_values, dim=1)  # [batch, num_action_dims, num_choices]
        
        return q_values
class EnhancedCNNQNet(torch.nn.Module):
    def __init__(self, hidden_dim, num_action_dims, num_choices):
        super(EnhancedCNNQNet, self).__init__()
        
        # 与策略网络相同的架构增强
        self.conv1 = torch.nn.Conv2d(2, 32, kernel_size=3, padding=1)
        self.bn1 = torch.nn.BatchNorm2d(32)
        
        self.conv2 = torch.nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.bn2 = torch.nn.BatchNorm2d(64)
        
        self.conv3 = torch.nn.Conv2d(64, 128, kernel_size=3, padding=1)
        self.bn3 = torch.nn.BatchNorm2d(128)
        
        self.conv4 = torch.nn.Conv2d(128, 128, kernel_size=3, padding=1)
        self.bn4 = torch.nn.BatchNorm2d(128)
        
        self.pool = torch.nn.MaxPool2d(kernel_size=2, stride=2)
        self.adaptive_pool = torch.nn.AdaptiveAvgPool2d((6, 6))
        
        # 更大的全连接层
        fc_input_dim = 128 * 6 * 6
        self.fc1 = torch.nn.Linear(fc_input_dim, hidden_dim*2)
        self.dropout1 = torch.nn.Dropout(0.3)
        
        self.fc2 = torch.nn.Linear(hidden_dim*2, hidden_dim)
        self.dropout2 = torch.nn.Dropout(0.3)
        
        # Q值头保持不变
        self.q_heads = torch.nn.ModuleList([
            torch.nn.Linear(hidden_dim, num_choices) for _ in range(num_action_dims)
        ])
        
        # 初始化权重
        self.apply(self._init_weights)
        
    def _init_weights(self, module):
        if isinstance(module, torch.nn.Conv2d) or isinstance(module, torch.nn.Linear):
            torch.nn.init.kaiming_normal_(module.weight, nonlinearity='relu')
            if module.bias is not None:
                module.bias.data.zero_()
    
    def forward(self, x):
        # 特征提取
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.pool(x)
        
        x = F.relu(self.bn2(self.conv2(x)))
        x = self.pool(x)
        
        x = F.relu(self.bn3(self.conv3(x)))
        x = F.relu(self.bn4(self.conv4(x)))
        
        x = self.adaptive_pool(x)
        
        # 扁平化
        x = x.view(x.size(0), -1)
        
        # 全连接层
        x = F.relu(self.fc1(x))
        x = self.dropout1(x)
        
        features = F.relu(self.fc2(x))
        features = self.dropout2(features)
        
        # Q值输出
        q_values = []
        for head in self.q_heads:
            q = head(features).unsqueeze(1)
            q_values.append(q)
        
        q_values = torch.cat(q_values, dim=1)
        
        return q_values
# ---------------------------
# 4. SAC for CNN
# ---------------------------
class CNNSAC:
    def __init__(self, hidden_dim, num_action_dims, num_choices,
                 actor_lr, critic_lr, alpha_lr, target_entropy, tau, gamma, device,
                 update_interval=1):
        self.device = device
        self.gamma = gamma
        self.tau = tau
        self.target_entropy = target_entropy
        self.num_action_dims = num_action_dims
        self.update_interval = update_interval
        self.update_counter = 0
        
        # 创建策略网络
        self.actor = EnhancedCNNPolicyNet(hidden_dim, num_action_dims, num_choices).to(device)
        
        # 创建Q网络
        self.critic_1 = EnhancedCNNQNet(hidden_dim, num_action_dims, num_choices).to(device)
        self.critic_2 = EnhancedCNNQNet(hidden_dim, num_action_dims, num_choices).to(device)
        
        # 创建目标Q网络
        self.target_critic_1 = EnhancedCNNQNet(hidden_dim, num_action_dims, num_choices).to(device)
        self.target_critic_2 = EnhancedCNNQNet(hidden_dim, num_action_dims, num_choices).to(device)
        
        # 复制参数到目标网络
        self.target_critic_1.load_state_dict(self.critic_1.state_dict())
        self.target_critic_2.load_state_dict(self.critic_2.state_dict())
        
        # 创建优化器
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_1_optimizer = torch.optim.Adam(self.critic_1.parameters(), lr=critic_lr)
        self.critic_2_optimizer = torch.optim.Adam(self.critic_2.parameters(), lr=critic_lr)
        
            # 在这里添加学习率调度器
        self.actor_scheduler = StepLR(self.actor_optimizer, step_size=1000, gamma=0.9)
        self.critic_1_scheduler = StepLR(self.critic_1_optimizer, step_size=1000, gamma=0.9)
        self.critic_2_scheduler = StepLR(self.critic_2_optimizer, step_size=1000, gamma=0.9)
        
        # 熵系数
        self.log_alpha = torch.tensor(np.log(0.01), dtype=torch.float).to(device)
        self.log_alpha.requires_grad = True
        self.log_alpha_optimizer = torch.optim.Adam([self.log_alpha], lr=alpha_lr)

    def take_action(self, state):
        """根据当前策略选择动作"""
        state = np.array([state])
        state_tensor = torch.from_numpy(state).float().to(self.device)
        
        # 确保状态有正确的维度
        if len(state_tensor.shape) == 3:  # [1, 2, N*M]
            state_tensor = state_tensor.unsqueeze(0)  # [1, 2, N*M] -> [1, 1, 2, N*M]
        
        with torch.no_grad():
            probs = self.actor(state_tensor)  # [1, num_action_dims, num_choices]
        
        actions = []
        for i in range(probs.size(1)):
            distribution = Categorical(probs[:, i, :])
            actions.append(distribution.sample().item())
        
        return np.array(actions)

    def calc_target(self, rewards, next_states, dones):
        """计算目标Q值，使用蒙特卡洛采样"""
        with torch.no_grad():
            next_probs = self.actor(next_states)  # [B, K, N]
            next_log_probs = torch.log(next_probs + 1e-8)
            entropy = -torch.sum(next_probs * next_log_probs, dim=2)  # [B, K]
            joint_entropy = torch.sum(entropy, dim=1, keepdim=True)  # [B, 1]
            
            # 使用采样估计联合期望Q值
            num_samples = max(1, min(3, self.num_action_dims - 1))  # 动态调整采样数量
            
            sampled_q_values = []
            for _ in range(num_samples):
                # 采样完整的动作组合
                actions = []
                for i in range(self.num_action_dims):
                    distrib = Categorical(next_probs[:, i, :])
                    actions.append(distrib.sample().unsqueeze(1))
                actions = torch.cat(actions, dim=1)  # [B, K]
                
                # 获取采样动作的Q值
                q1 = self.target_critic_1(next_states)  # [B, K, N]
                q2 = self.target_critic_2(next_states)  # [B, K, N]
                min_q = torch.min(q1, q2)
                
                # 提取这些动作的Q值
                indices = actions.unsqueeze(-1)  # [B, K, 1]
                selected_q = min_q.gather(2, indices).squeeze(-1)  # [B, K]
                joint_q = torch.sum(selected_q, dim=1, keepdim=True)  # [B, 1]
                sampled_q_values.append(joint_q)
            
            # 平均所有采样的Q值
            expected_q = torch.mean(torch.cat(sampled_q_values, dim=1), dim=1, keepdim=True)
            
            # 计算目标值
            td_target = rewards + self.gamma * (1 - dones) * (expected_q + self.log_alpha.exp() * joint_entropy)
            
            return td_target

    def soft_update(self, net, target_net):
        """软更新目标网络"""
        for param_target, param in zip(target_net.parameters(), net.parameters()):
            param_target.data.copy_(param_target.data * (1.0 - self.tau) + param.data * self.tau)

    def update(self, transition_dict):
        """更新网络参数"""
        self.update_counter += 1
        if self.update_counter % self.update_interval != 0:
            return  # 控制更新频率
            
        states = torch.tensor(transition_dict['states'], dtype=torch.float).to(self.device)
        actions = torch.tensor(transition_dict['actions'], dtype=torch.long).to(self.device)
        rewards = torch.tensor(transition_dict['rewards'], dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(transition_dict['next_states'], dtype=torch.float).to(self.device)
        dones = torch.tensor(transition_dict['dones'], dtype=torch.float).view(-1, 1).to(self.device)

        # 计算目标Q值
        td_target = self.calc_target(rewards, next_states, dones)

        # 更新critic 1
        current_q1 = self.critic_1(states)
        selected_q1 = current_q1.gather(dim=2, index=actions.unsqueeze(-1)).squeeze(-1)
        q1_value = torch.sum(selected_q1, dim=1, keepdim=True)
        critic_1_loss = F.mse_loss(q1_value, td_target)

        self.critic_1_optimizer.zero_grad()
        critic_1_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic_1.parameters(), max_norm=10.0)
        self.critic_1_optimizer.step()

        # 更新critic 2
        current_q2 = self.critic_2(states)
        selected_q2 = current_q2.gather(dim=2, index=actions.unsqueeze(-1)).squeeze(-1)
        q2_value = torch.sum(selected_q2, dim=1, keepdim=True)
        critic_2_loss = F.mse_loss(q2_value, td_target)

        self.critic_2_optimizer.zero_grad()
        critic_2_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic_2.parameters(), max_norm=10.0)
        self.critic_2_optimizer.step()

        # 更新策略网络
        probs = self.actor(states)
        log_probs = torch.log(probs + 1e-8)
        entropy = -torch.sum(probs * log_probs, dim=2)
        joint_entropy = torch.sum(entropy, dim=1, keepdim=True)

        # 计算当前策略下的Q值期望
        with torch.no_grad():
            q1 = self.critic_1(states)
            q2 = self.critic_2(states)
            min_q = torch.min(q1, q2)
            
        expected_q = torch.sum(probs * min_q, dim=2)
        joint_expected_q = torch.sum(expected_q, dim=1, keepdim=True)

        actor_loss = torch.mean(-self.log_alpha.exp() * joint_entropy - joint_expected_q)
        
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=10.0)
        self.actor_optimizer.step()

        # 更新熵系数alpha
        alpha_loss = torch.mean((joint_entropy - self.target_entropy).detach() * self.log_alpha.exp())
        
        self.log_alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.log_alpha_optimizer.step()

        # 软更新目标网络
        self.soft_update(self.critic_1, self.target_critic_1)
        self.soft_update(self.critic_2, self.target_critic_2)
        
                # 更新学习率调度器 #*
        if self.update_counter % 1000 == 0: #*
            self.actor_scheduler.step() #*
            self.critic_1_scheduler.step() #*
            self.critic_2_scheduler.step() #*
            print(f"更新学习率 - 当前步数: {self.update_counter}, " #*
                  f"Actor学习率: {self.actor_optimizer.param_groups[0]['lr']:.6f}, " #*
                  f"Critic学习率: {self.critic_1_optimizer.param_groups[0]['lr']:.6f}") #*
        
    def save(self, path):
        """保存模型"""
        torch.save({
            'actor': self.actor.state_dict(),
            'critic_1': self.critic_1.state_dict(),
            'critic_2': self.critic_2.state_dict(),
            'target_critic_1': self.target_critic_1.state_dict(),
            'target_critic_2': self.target_critic_2.state_dict(),
            'log_alpha': self.log_alpha,
        }, path)
        
    def load(self, path):
        """加载模型"""
        checkpoint = torch.load(path)
        self.actor.load_state_dict(checkpoint['actor'])
        self.critic_1.load_state_dict(checkpoint['critic_1'])
        self.critic_2.load_state_dict(checkpoint['critic_2'])
        self.target_critic_1.load_state_dict(checkpoint['target_critic_1'])
        self.target_critic_2.load_state_dict(checkpoint['target_critic_2'])
        self.log_alpha = checkpoint['log_alpha']

# ---------------------------
# 5. 训练函数
# ---------------------------
def train_agent(env, agent, num_episodes, replay_buffer, minimal_size, batch_size, eval_interval=20):
    return_list = []
    eval_returns = []
    
    start_time = time.time()
    
    for i_episode in tqdm(range(num_episodes)):
        episode_return = 0
        state = env.reset()
        done = False
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            replay_buffer.push(state, action, reward, next_state, done)
            state = next_state
            episode_return += reward

            if len(replay_buffer) > minimal_size:
                transition = replay_buffer.sample(batch_size)
                agent.update(transition)
                
        return_list.append(episode_return)
        
        # 定期记录和评估
        if (i_episode + 1) % 50 == 0:
            avg_return = np.mean(return_list[-10:])
            elapsed_time = time.time() - start_time
            print(f"Episode: {i_episode+1}, Avg Return: {avg_return:.2f}, Time: {elapsed_time:.2f}s")
        
        # 定期评估
        if (i_episode + 1) % eval_interval == 0:
            mean_return, _ = evaluate_agent(env, agent, num_episodes=5)
            eval_returns.append((i_episode + 1, mean_return))
            
    return return_list, eval_returns

# ---------------------------
# 6. 评估函数
# ---------------------------
def evaluate_agent(env, agent, num_episodes=10):
    returns = []
    
    for _ in range(num_episodes):
        episode_return = 0
        state = env.reset()
        done = False
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            episode_return += reward
            state = next_state
            
        returns.append(episode_return)
        
    mean_return = np.mean(returns)
    std_return = np.std(returns)
    
    print(f"Evaluation over {num_episodes} episodes: Mean Return = {mean_return:.2f}, Std = {std_return:.2f}")
    
    return mean_return, std_return

# ---------------------------
# 7. 可视化和结果分析
# ---------------------------
def plot_results(return_list, eval_returns, title, save_dir='./results', window_size=10, figsize=(12, 8)):
    """绘制训练回报曲线和评估结果"""
    os.makedirs(save_dir, exist_ok=True)
    
    # 计算滑动平均
    if window_size > 1:
        smoothed_returns = []
        for i in range(len(return_list)):
            start_idx = max(0, i - window_size + 1)
            smoothed_returns.append(np.mean(return_list[start_idx:i+1]))
    else:
        smoothed_returns = return_list
    
    plt.figure(figsize=figsize)
    
    # 主图: 训练回报
    plt.subplot(2, 1, 1)
    plt.plot(return_list, alpha=0.3, label='Training Returns')
    plt.plot(smoothed_returns, label=f'Smoothed Returns (window={window_size})')
    plt.xlabel('Episode')
    plt.ylabel('Return')
    plt.title(f'{title} - Training Progress')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 第二个子图: 评估回报
    if eval_returns:
        plt.subplot(2, 1, 2)
        episodes, returns = zip(*eval_returns)
        plt.plot(episodes, returns, 'o-', label='Evaluation Returns')
        plt.xlabel('Episode')
        plt.ylabel('Evaluation Return')
        plt.title('Periodic Evaluation Performance')
        plt.legend()
        plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    # 保存图片
    save_path = os.path.join(save_dir, f"{title.replace(' ', '_')}.png")
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"Plot saved to {save_path}")
    
    plt.show()

# ---------------------------
# 8. 分析卷积特征
# ---------------------------
def analyze_cnn_features(agent, env, num_samples=3):
    """分析CNN网络中的特征激活情况"""
    print("\n=== 分析CNN特征激活 ===")
    
    # 用于提取CNN特征的辅助函数
    def get_feature_maps(state, layer):
        state_tensor = torch.tensor([state], dtype=torch.float).to(agent.device)
        
        # 确保输入维度正确
        if len(state_tensor.shape) == 3:
            state_tensor = state_tensor.unsqueeze(0)
            
        # 使用钩子提取指定层的特征图
        features = []
        def hook_fn(module, input, output):
            features.append(output.detach().cpu().numpy())
            
        handle = layer.register_forward_hook(hook_fn)
        with torch.no_grad():
            _ = agent.actor(state_tensor)
        handle.remove()
        
        return features[0]
    
    # 分析多个样本
    for i in range(num_samples):
        state = env.reset()
        action = agent.take_action(state)
        next_state, reward, done, _ = env.step(action)
        
        # 获取第一卷积层特征
        feature_maps_conv1 = get_feature_maps(state, agent.actor.conv1)
        
        print(f"\n样本 {i+1}:")
        print(f"状态形状: {state.shape}")
        print(f"动作: {action}, 奖励: {reward:.2f}")
        print(f"第一卷积层特征图形状: {feature_maps_conv1.shape}")
        print(f"特征图均值: {np.mean(feature_maps_conv1):.4f}, 标准差: {np.std(feature_maps_conv1):.4f}")
        print(f"特征图最大值: {np.max(feature_maps_conv1):.4f}, 最小值: {np.min(feature_maps_conv1):.4f}")
        
        # 可以根据需要扩展以可视化特征图
            
    return True

