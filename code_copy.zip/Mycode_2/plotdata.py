import os
import matplotlib.pyplot as plt
from scipy import interpolate
from matplotlib.lines import Line2D
import numpy as np
import matplotlib as mpl

def plot_and_save_multiple_returns(returns_dict, title, save=True, save_dir='./results', 
                                  window_size=5, figsize=(9, 8), custom_colors=None):
    """绘制多条训练回报曲线并保存，支持指定每对曲线的颜色
    
    Args:
        returns_dict: 字典，键为曲线标签，值为回报列表
        title: 图表标题
        save: 是否保存图表
        save_dir: 保存目录
        window_size: 滑动平均窗口大小
        figsize: 图表尺寸
        custom_colors: 字典，键为曲线标签，值为均值曲线颜色代码，可选
    """
    # 创建保存目录
    os.makedirs(save_dir, exist_ok=True)
    
    # 默认颜色列表
    default_colors = ['#47CACC', '#CD83D4', '#FFBE88', '#FF7B89', '#81BECE', 
                     '#a6dbfb', '#FFA570', '#F0D0E7', "#fd82b1", '#00a7c7']
    
    # 创建浅色版本函数
    def lighten_color(hex_color):
        import colorsys
        # 将十六进制转换为RGB
        h = hex_color.lstrip('#')
        rgb = tuple(int(h[i:i+2], 16) / 255.0 for i in (0, 2, 4))
        
        # 转换为HSV
        hsv = colorsys.rgb_to_hsv(*rgb)
        
        # 降低饱和度并增加亮度（使颜色更浅）
        s = max(hsv[1] * 1, 0.0)  # 保持饱和度
        v = min(hsv[2] * 1.2, 1.0)  # 增加亮度
        
        # 转回RGB
        lighter_rgb = colorsys.hsv_to_rgb(hsv[0], s, v)
        
        # 转回十六进制
        lighter_hex = '#{:02x}{:02x}{:02x}'.format(
            int(lighter_rgb[0] * 255), 
            int(lighter_rgb[1] * 255),
            int(lighter_rgb[2] * 255)
        )
        return lighter_hex
    
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.size'] = 20
    
    # 绘图
    plt.figure(figsize=figsize)
    
    # 循环处理每条曲线
    for i, (label, return_list) in enumerate(returns_dict.items()):
        # 确定均值曲线的颜色
        if custom_colors and label in custom_colors:
            main_color = custom_colors[label]  # 使用自定义颜色
        else:
            color_idx = i % len(default_colors)
            main_color = default_colors[color_idx]  # 使用默认颜色
        
        # 为原始曲线创建浅色版本
        light_color = lighten_color(main_color)
        
        # 计算滑动平均
        if window_size > 1:
            smoothed_returns = []
            for j in range(len(return_list)):
                start_idx = max(0, j - window_size + 1)
                smoothed_returns.append(np.mean(return_list[start_idx:j+1]))
        else:
            smoothed_returns = return_list
        
        # 绘制原始回报（使用浅色版本，低不透明度）
        plt.plot(return_list, alpha=0.3, 
                color=light_color, linewidth=2)
                
        # 绘制平滑回报（使用原始颜色，完全不透明）
        plt.plot(smoothed_returns, 
                label=f'{label} ', 
                color=main_color, linewidth=2)
    
    plt.xlabel('Episodes', fontsize=20)
    plt.ylabel('Rewards', fontsize=20)
    if title != None:
        plt.title(title, fontsize=20)
    plt.legend(fontsize=18)
    plt.xticks(fontsize=18)
    plt.yticks(fontsize=18)
    plt.grid(True, alpha=0.3)
    
    # 控制边框线宽
    ax = plt.gca()
    for spine in ax.spines.values():
        spine.set_linewidth(0.5)
    
    # 保存图片
    if save:
        save_path = os.path.join(save_dir, f"{title.replace(' ', '_')}.png")
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    # 显示图片
    plt.show()


def plot_and_save_multiple_returns_1(returns_dict, title, save=True, save_dir='./results', 
                                  window_size=5, figsize=(9, 8), custom_colors=None):
    """绘制多条训练回报曲线并保存，支持指定每对曲线的颜色，支持内置数学文本
    
    Args:
        returns_dict: 字典，键为曲线标签，值为回报列表
        title: 图表标题
        save: 是否保存图表
        save_dir: 保存目录
        window_size: 滑动平均窗口大小
        figsize: 图表尺寸
        custom_colors: 字典，键为曲线标签，值为均值曲线颜色代码，可选
    """
    # 创建保存目录
    os.makedirs(save_dir, exist_ok=True)
    
    # 默认颜色列表
    default_colors = ['#47CACC', '#CD83D4', '#FFBE88', '#FF7B89', '#81BECE', 
                     '#a6dbfb', '#FFA570', '#F0D0E7', "#fd82b1", '#00a7c7']
    
    # 创建浅色版本函数
    def lighten_color(hex_color):
        import colorsys
        # 将十六进制转换为RGB
        h = hex_color.lstrip('#')
        rgb = tuple(int(h[i:i+2], 16) / 255.0 for i in (0, 2, 4))
        
        # 转换为HSV
        hsv = colorsys.rgb_to_hsv(*rgb)
        
        # 降低饱和度并增加亮度（使颜色更浅）
        s = max(hsv[1] * 1, 0.0)  # 保持饱和度
        v = min(hsv[2] * 1.2, 1.0)  # 增加亮度
        
        # 转回RGB
        lighter_rgb = colorsys.hsv_to_rgb(hsv[0], s, v)
        
        # 转回十六进制
        lighter_hex = '#{:02x}{:02x}{:02x}'.format(
            int(lighter_rgb[0] * 255), 
            int(lighter_rgb[1] * 255),
            int(lighter_rgb[2] * 255)
        )
        return lighter_hex
    
    # 设置字体和数学文本渲染，使用内置渲染器而非LaTeX
    plt.rcParams.update({
        'font.family': 'serif',
        'font.size': 20,
        'text.usetex': False,  # 不使用LaTeX
        'mathtext.default': 'regular',  # 使用常规字体渲染数学文本
        'mathtext.fontset': 'stix',     # 使用STIX字体集
    })
    
    # 绘图
    plt.figure(figsize=figsize)
    
    # 循环处理每条曲线
    for i, (label, return_list) in enumerate(returns_dict.items()):
        # 确定均值曲线的颜色
        if custom_colors and label in custom_colors:
            main_color = custom_colors[label]  # 使用自定义颜色
        else:
            color_idx = i % len(default_colors)
            main_color = default_colors[color_idx]  # 使用默认颜色
        
        # 为原始曲线创建浅色版本
        light_color = lighten_color(main_color)
        
        # 计算滑动平均
        if window_size > 1:
            smoothed_returns = []
            for j in range(len(return_list)):
                start_idx = max(0, j - window_size + 1)
                smoothed_returns.append(np.mean(return_list[start_idx:j+1]))
        else:
            smoothed_returns = return_list
        
        # 绘制原始回报（使用浅色版本，低不透明度）
        plt.plot(return_list, alpha=0.3, 
                color=light_color, linewidth=2)
                
        # 绘制平滑回报（使用原始颜色，完全不透明）
        # 注意：对于Matplotlib内置的数学文本，标签应已经包含$符号
        plt.plot(smoothed_returns, 
                label=f'{label}', 
                color=main_color, linewidth=2)
    
    plt.xlabel('Episodes', fontsize=20)
    plt.ylabel('Rewards', fontsize=20)
    if title != None:
        plt.title(title, fontsize=20)
    plt.legend(fontsize=18)
    plt.xticks(fontsize=18)
    plt.yticks(fontsize=18)
    plt.grid(True, alpha=0.3)
    
    # 控制边框线宽
    ax = plt.gca()
    for spine in ax.spines.values():
        spine.set_linewidth(0.5)
    
    # 保存图片
    if save:
        save_path = os.path.join(save_dir, f"{title.replace(' ', '_')}.png")
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    # 显示图片
    plt.show()


   
def interpolate_and_amplify(data, target_length, amplify_factor=1.2, method='cubic'):
    """
    对数据进行插值并应用渐进放大效果
    
    参数：
    data: 原始数据数组
    target_length: 目标长度
    amplify_factor: 结尾处的放大倍数，例如1.2表示放大到原来的1.2倍
    method: 插值方法，可选'linear', 'cubic', 'quadratic', 'nearest'等
    
    返回：
    插值并放大后的数据数组
    """
    # 创建原始数据的x轴位置
    x_original = np.arange(len(data))
    
    # 创建新数据的x轴位置
    x_new = np.linspace(0, len(data) - 1, target_length)
    
    # 创建插值函数
    f = interpolate.interp1d(x_original, data, kind=method, bounds_error=False)
    
    # 应用插值
    interpolated_data = f(x_new)
    
    # 创建放大因子数组 - 从1.0渐变到amplify_factor
    amplify_array = np.linspace(1.0, amplify_factor, target_length)
    
    # 应用渐进放大
    amplified_data = interpolated_data * amplify_array
    
    return amplified_data

def plot_multi_line_with_markers(x_data, y_data_dict, xlabel, ylabel, 
                                line_styles=None, colors=None, markers=None,
                                figsize=(9, 8), save=False, save_path=None,
                                legend_loc='best', x_ticks=None, y_lim=None,
                                linewidth=2, markersize=8, grid=True):
    """
    绘制多条带有不同线型和标记的折线图
    
    参数:
    x_data: 横坐标数据 (所有线共用)
    y_data_dict: 字典，键为线的标签，值为纵坐标数据
    xlabel: 横坐标轴标签
    ylabel: 纵坐标轴标签
    line_styles: 字典，键为线的标签，值为线型 (如 '-', '--', ':', '-.')
    colors: 字典，键为线的标签，值为颜色代码或名称
    markers: 字典，键为线的标签，值为标记样式 (如 'o', 's', '^')
    figsize: 图表尺寸，默认(10, 6)
    save: 是否保存图表，默认False
    save_path: 保存路径，如果save=True，则必须提供
    legend_loc: 图例位置，默认'best'
    x_ticks: 自定义x轴刻度，可选
    y_lim: y轴范围[ymin, ymax]，可选
    linewidth: 线宽，默认2
    markersize: 标记大小，默认8
    grid: 是否显示网格，默认True
    
    返回:
    fig, ax: 图形对象和坐标轴对象
    """
    # 默认样式设置
    default_line_styles = {
        1: '-', 2: '--', 3: '-.', 4: ':', 5: '-',
        6: '--', 7: '-.', 8: ':', 9: '-', 10: '--'
    }
    
    default_colors = {
        1: "#47CACC", 2: "#CD83D4", 3: "#FF7B89", 4: "#FFBE88", 5: "#81BECE",
        6: "#a6dbfb", 7: "#FFA570", 8: "#F0D0E7", 9: "#fd82b1", 10: "#00a7c7"
    }
    
    default_markers = {
        1: 'o', 2: '+', 3: 'x', 4: 's', 5: 'D',
        6: '^', 7: 'v', 8: '<', 9: '>', 10: 'p'
    }
    
    # 设置字体和文本属性
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.size'] = 20
    plt.rcParams['mathtext.default'] = 'regular'
    
    # 创建图表
    fig, ax = plt.subplots(figsize=figsize)
    
    # 绘制每条线
    for i, (label, y_data) in enumerate(y_data_dict.items(), 1):
        # 确定线型、颜色和标记
        line_style = line_styles.get(label, default_line_styles[i]) if line_styles else default_line_styles[i]
        color = colors.get(label, default_colors[i]) if colors else default_colors[i]
        marker = markers.get(label, default_markers[i]) if markers else default_markers[i]
        
        # 绘制线
        ax.plot(x_data, y_data, 
                linestyle=line_style, 
                color=color,
                marker=marker, 
                markersize=markersize, 
                linewidth=linewidth,
                label=label)
    
    # 设置坐标轴标签
    ax.set_xlabel(xlabel, fontsize=20)
    ax.set_ylabel(ylabel, fontsize=20)
    plt.legend(fontsize=18)
    plt.xticks(fontsize=18)
    plt.yticks(fontsize=18)
    # 设置x轴刻度
    if x_ticks:
        ax.set_xticks(x_ticks)
    
    # 设置y轴范围
    if y_lim:
        ax.set_ylim(y_lim)
    
    # 添加图例
    ax.legend(loc=legend_loc, fontsize=18)
    
    # 添加网格
    if grid:
        ax.grid(True, alpha=0.3, linestyle='--')
    
    # 调整边距，使图表更紧凑
    plt.tight_layout()
    
    # 保存图表
    if save and save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"图表已保存至 {save_path}")
    
    return fig, ax








