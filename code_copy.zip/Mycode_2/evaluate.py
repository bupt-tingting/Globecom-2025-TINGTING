import random
import gym
from gym import spaces
import numpy as np
import torch
import torch.nn.functional as F
from torch.distributions import Normal
import json
import sys
import os
from datetime import datetime
import time
import math
import argparse
import hdf5storage  #* 确保导入hdf5storage用于加载mat文件

from RISenv import *
from SAC_Eff import *  # 可能需要根据加载的模型类型调整导入的模块

def evaluate_agent(env, agent, num_episodes=10, max_episode_steps=1):
    """对训练好的智能体进行评估"""
    returns = []
    all_actions = []
    all_RIScodes = []
    best_return = -float('inf')
    best_RIScode = None
    best_episode_idx = -1
    
    print(f"\n使用预训练模型评估 {num_episodes} 个回合...")
    for i in range(num_episodes):
        episode_return = 0
        state = env.reset()
        done = False
        episode_actions = []
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            episode_return += reward
            state = next_state
            episode_actions.append(action.tolist() if isinstance(action, np.ndarray) else action)
        
        episode_return = episode_return / max_episode_steps    
        returns.append(episode_return)
        all_actions.append(episode_actions)
        
        # 保存当前回合的RIScode
        current_RIScode = env.RIScode
        all_RIScodes.append(current_RIScode)
        
        # 更新最佳RIScode
        if episode_return > best_return:
            best_return = episode_return
            best_RIScode = current_RIScode.copy() if isinstance(current_RIScode, np.ndarray) else current_RIScode
            best_episode_idx = i
            
        print(f"评估回合 {i+1}: 回报 = {episode_return:.4f}")
        
    mean_return = np.mean(returns)
    std_return = np.std(returns)
    
    print(f"\n评估结果:")
    print(f"平均回报: {mean_return:.4f}")
    print(f"回报标准差: {std_return:.4f}")
    print(f"最小回报: {np.min(returns):.4f}")
    print(f"最大回报: {np.max(returns):.4f}")
    
    return mean_return, std_return, returns, all_actions, all_RIScodes, best_RIScode, best_episode_idx


def save_evaluation_results_to_txt(filepath, mean_return, std_return, all_returns, all_actions, all_RIScodes, best_RIScode, best_episode_idx):
    """将所有评估结果保存到一个txt文件中，RIScode以3D矩阵格式展示"""
    def format_RIScode_3D(RIScode):
        """将2D RIScode转换为3D并格式化为可读字符串"""
        # 获取RIScode的形状
        num_time_slots, num_RIS = RIScode.shape
        
        # 尝试找到最接近的平方根作为网格尺寸
        sqrt_num_RIS = int(np.sqrt(num_RIS))
        if sqrt_num_RIS ** 2 == num_RIS:
            num_RISm = num_RISn = sqrt_num_RIS
        else:
            # 找到最接近的因子
            for i in range(int(np.sqrt(num_RIS)), 0, -1):
                if num_RIS % i == 0:
                    num_RISm = i
                    num_RISn = num_RIS // i
                    break
        
        # 重塑为3D
        RIScode_3D = RIScode.reshape(num_time_slots, num_RISm, num_RISn)
        
        # 生成每个时间槽的字符串表示
        slot_strings = []
        for t in range(num_time_slots):
            lines = []
            lines.append(f"slot {t}:")
            for row in RIScode_3D[t]:
                lines.append(" ".join(str(x) for x in row))
            slot_strings.append("\n".join(lines))
        
        # 计算每个时间槽字符串的最大行数
        max_lines = max(s.count('\n') + 1 for s in slot_strings)
        
        # 将每个时间槽的字符串按行拆分
        slot_lines = [s.split('\n') for s in slot_strings]
        
        # 用空白行填充使所有时间槽有相同的行数
        for lines in slot_lines:
            while len(lines) < max_lines:
                lines.append("")
        
        # 计算每列的最大宽度
        col_widths = [max(len(line) for line in col_lines) for col_lines in slot_lines]
        
        # 逐行组合所有时间槽
        result_lines = []
        for i in range(max_lines):
            line_parts = []
            for slot_idx, lines in enumerate(slot_lines):
                # 右对齐到该列的最大宽度
                line_parts.append(lines[i].ljust(col_widths[slot_idx]))
            result_lines.append("    ".join(line_parts))
        
        return "\n".join(result_lines)
    
    with open(filepath, 'w') as f:
        # 评估摘要部分
        f.write("===========================================================\n")
        f.write("                   EVALUATION RESULTS SUMMARY      \n")
        f.write("===========================================================\n\n")
        
        f.write(f"Number of Episodes: {len(all_returns)}\n")
        f.write(f"Mean Return: {mean_return:.6f}\n")
        f.write(f"Standard Deviation: {std_return:.6f}\n")
        f.write(f"Min Return: {min(all_returns):.6f}\n")
        f.write(f"Max Return: {max(all_returns):.6f}\n")
        f.write(f"Best Episode: {best_episode_idx + 1}\n\n")
        
        # 最佳回合的RIScode部分
        f.write("===========================================================\n")
        f.write("                    BEST EPISODE RISCODE           \n")
        f.write("===========================================================\n\n")
        
        f.write(f"Episode {best_episode_idx + 1} Return: {all_returns[best_episode_idx]:.6f}\n\n")
        f.write("RIS Configuration Matrix:\n")
        
        # 使用3D格式显示最佳RIScode
        best_RIScode_np = np.array(best_RIScode)
        f.write(format_RIScode_3D(best_RIScode_np) + "\n\n")
        
        # 最佳回合的动作序列
        f.write("Action Sequence:\n")
        for i, action in enumerate(all_actions[best_episode_idx]):
            f.write(f"Step {i+1}: {action}\n")
        f.write("\n")
        
        # 所有回合的结果
        f.write("===========================================================\n")
        f.write("                       ALL EPISODES RESULTS           \n")
        f.write("===========================================================\n\n")
        
        for episode_idx in range(len(all_returns)):
            f.write(f"Episode {episode_idx + 1} Return: {all_returns[episode_idx]:.6f}\n")
            f.write("RIS Configuration Matrix:\n")
            
            # 使用3D格式显示每个回合的RIScode
            episode_RIScode_np = np.array(all_RIScodes[episode_idx])
            f.write(format_RIScode_3D(episode_RIScode_np) + "\n\n")


def main():
    """使用预训练模型进行RIS配置预测"""
    start_time = time.time()
    begin_time = datetime.now().strftime("%d day %H hour %M minus %S second")

    # 添加命令行参数
    parser = argparse.ArgumentParser(description='使用预训练模型预测RIS配置')
    parser.add_argument('--model_dir', type=str, required=True, help='包含模型和配置的文件夹路径')
    parser.add_argument('--eval_episodes', type=int, default=10, help='评估的回合数')
    args = parser.parse_args()
    
    # 设置工作目录
    os.chdir('/new_disk/ting/RL/Mycode_2')
    
    # 加载模型保存的配置参数
    model_dir = args.model_dir
    config_path = os.path.join(model_dir, 'config.json')
    model_path = os.path.join(model_dir, 'sac_model.pt')
    
    print(f"正在从 {config_path} 加载配置...")
    with open(config_path, 'r') as f:
        saved_config = json.load(f)
    
    # 从保存的配置中提取参数
    SNR = saved_config.get("SNR", 10)
    num_time_slots = saved_config.get("num_time_slots", 2)
    bits = saved_config.get("bits", 1)
    seed = saved_config.get("seed", 1)
    
    num_RISm = saved_config.get("num_RISm", 8)
    num_RISn = saved_config.get("num_RISn", 8)
    num_RIS = saved_config.get("num_RIS", num_RISm * num_RISn)
    
    num_BSm = saved_config.get("num_BSm", 2)
    num_BSn = saved_config.get("num_BSn", 2)
    num_UEm = saved_config.get("num_UEm", 2)
    num_UEn = saved_config.get("num_UEn", 2)
    num_tx = saved_config.get("num_tx", num_BSm * num_BSn)
    num_rx = saved_config.get("num_rx", num_UEm * num_UEn)
    
    use_cnn = saved_config.get("use_cnn", False)
    max_episode_steps = saved_config.get("max_episode_steps", num_time_slots * num_RIS * bits * 4)
    reward_window = saved_config.get("reward_window", 1)
    
    # 获取算法类型
    SAC_name = saved_config.get("SAC_name", "SAC_Eff")
    
    # 模型参数
    hidden_dim = saved_config.get("hidden_dim", 256)
    gamma = saved_config.get("gamma", 0.98)
    tau = saved_config.get("tau", 0.001)
    actor_lr = saved_config.get("actor_lr", 1e-5)
    critic_lr = saved_config.get("critic_lr", 1e-5)
    alpha_lr = saved_config.get("alpha_lr", 1e-4)
    
    print("从配置文件加载的参数:")
    print(f"SAC算法: {SAC_name}")
    print(f"RIS尺寸: {num_RISm}x{num_RISn} = {num_RIS}")
    print(f"发射天线: {num_tx}, 接收天线: {num_rx}")
    print(f"时间槽数: {num_time_slots}, 量化位数: {bits}")
    print(f"使用CNN: {use_cnn}")
    
    # 根据需要动态导入相应的SAC模块
    if SAC_name == 'SAC_CNN' and 'SAC_CNN' not in sys.modules:
        try:
            from SAC_CNN import CNNSAC
            print("成功导入 SAC_CNN 模块")
        except ImportError:
            print("警告: 无法导入 SAC_CNN 模块, 将使用默认的 SAC_Eff")
            SAC_name = 'SAC_Eff'
    
    elif SAC_name == 'SAC_Transformer' and 'SAC_Transformer' not in sys.modules and 'SAC_Trans' not in sys.modules:
        try:
            from SAC_Transformer import TransformerSAC
            print("成功导入 SAC_Transformer 模块")
        except ImportError:
            try:
                from SAC_Trans import TransformerSAC
                print("成功导入 SAC_Trans 模块")
            except ImportError:
                print("警告: 无法导入 SAC_Transformer/SAC_Trans 模块, 将使用默认的 SAC_Eff")
                SAC_name = 'SAC_Eff'
    
    elif SAC_name == 'SAC_Attention' and 'SAC_Attention' not in sys.modules and 'SAC_Att' not in sys.modules:
        try:
            from SAC_Attention import AttentionInteractiveSAC
            print("成功导入 SAC_Attention 模块")
        except ImportError:
            try:
                from SAC_Att import AttentionInteractiveSAC
                print("成功导入 SAC_Att 模块")
            except ImportError:
                print("警告: 无法导入 SAC_Attention/SAC_Att 模块, 将使用默认的 SAC_Eff")
                SAC_name = 'SAC_Eff'
    
    # 设置随机种子
    set_all_seeds(seed)
    
    # 设置设备
    device = torch.device("cuda:1") if torch.cuda.is_available() else torch.device("cpu")
    print(f"使用设备: {device}")
    
    # 加载信道数据
    print("正在加载信道数据...")
    file_path_BS2RIS = f'../MyData/H_BS2RIS_{num_RISm}*{num_RISn}RIS_{num_BSm}*{num_BSn}_{num_UEm}*{num_UEn}_MIMO.mat'
    file_path_RIS2UE = f'../MyData/H_RIS2UE_{num_RISm}*{num_RISn}RIS_{num_BSm}*{num_BSn}_{num_UEm}*{num_UEn}_MIMO.mat'
    
    H_BS2RIS = hdf5storage.loadmat(file_path_BS2RIS)['H_BS2RIS']
    H_RIS2UE = hdf5storage.loadmat(file_path_RIS2UE)['H_RIS2UE']
    
    H_BS2RIS = whitening(add_noise(H_BS2RIS, SNR))
    H_RIS2UE = whitening(add_noise(H_RIS2UE, SNR))
    
    H_BS2RIS_train = H_BS2RIS[0, 0, 0:num_time_slots, 0, :, :]
    H_RIS2UE_train = H_RIS2UE[0, 0, 0:num_time_slots, 0, :, :]
    print(f'信道数据形状: H_BS2RIS_train={H_BS2RIS_train.shape}, H_RIS2UE_train={H_RIS2UE_train.shape}')
    
    # 创建环境
    env = RISEnv(
        H_BS2RIS_train=H_BS2RIS_train,
        H_RIS2UE_train=H_RIS2UE_train,
        num_time_slots=num_time_slots,
        num_RIS=num_RIS,
        bits=bits,
        max_episode_steps=max_episode_steps,
        use_cnn=use_cnn,
        reward_window=reward_window
    )
    
    # 设置智能体参数
    if use_cnn:
        state_dim = None
    else:
        state_dim = env.obs_dim
    num_action_dims = num_time_slots
    num_choices = num_RIS + 1  # 多一个，表示不步进
    target_entropy = np.log(num_choices)
    
    # 创建相应类型的智能体
    print(f"创建 {SAC_name} 类型的智能体...")
    if SAC_name == 'SAC_CNN':
        agent = CNNSAC(
            hidden_dim,
            num_action_dims,
            num_choices,
            actor_lr,
            critic_lr,
            alpha_lr,
            target_entropy,
            tau,
            gamma,
            device
        )
    elif SAC_name == 'SAC_Transformer':
        agent = TransformerSAC(
            state_dim,
            hidden_dim,
            num_action_dims,
            num_choices,
            actor_lr,
            critic_lr,
            alpha_lr,
            target_entropy,
            tau,
            gamma,
            device
        )
    elif SAC_name == 'SAC_Attention':
        agent = AttentionInteractiveSAC(
            state_dim,
            hidden_dim,
            num_action_dims,
            num_choices,
            actor_lr,
            critic_lr,
            alpha_lr,
            target_entropy,
            tau,
            gamma,
            device
        )
    else:  # SAC_Eff或其他默认情况
        agent = EfficientSAC_MultiDiscrete(
            state_dim,
            hidden_dim,
            num_action_dims,
            num_choices,
            actor_lr,
            critic_lr,
            alpha_lr,
            target_entropy,
            tau,
            gamma,
            device
        )
    
    # 加载预训练模型
    print(f"正在加载预训练模型: {model_path}")
    agent.load(model_path)
    print("模型加载成功")
    
    # 进行评估
    print("\n=========== 模型评估 ===========")
    mean_return, std_return, all_returns, all_actions, all_RIScodes, best_RIScode, best_episode_idx = evaluate_agent(
        env, agent, num_episodes=args.eval_episodes, max_episode_steps=max_episode_steps
    )
    
    # 创建结果保存目录
    current_time = datetime.now().strftime("%d_%H%M%S")
    result_subfolder = f"../predict_results/prediction_{num_RIS}RIS_{num_tx}t_{num_rx}r_{bits}b_{current_time}"
    os.makedirs(result_subfolder, exist_ok=True)
    
    # 保存评估结果
    evaluation_results_path = f"{result_subfolder}/prediction_results.txt"
    save_evaluation_results_to_txt(
        evaluation_results_path,
        mean_return,
        std_return,
        all_returns,
        all_actions,
        all_RIScodes,
        best_RIScode,
        best_episode_idx
    )
    
    # 保存配置信息
    config_info = {
        "message": "使用预训练模型进行预测",
        "begin_time": begin_time,
        "SAC_name": SAC_name,
        "original_model_path": model_path,
        "SNR": SNR,
        "num_time_slots": num_time_slots,
        "bits": bits,
        "seed": seed,
        "num_RISm": num_RISm,
        "num_RISn": num_RISn,
        "num_RIS": num_RIS,
        "num_BSm": num_BSm,
        "num_BSn": num_BSn,
        "num_tx": num_tx,
        "num_UEm": num_UEm,
        "num_UEn": num_UEn,
        "num_rx": num_rx,
        "evaluation_episodes": args.eval_episodes,
        "max_episode_steps": max_episode_steps,
        "use_cnn": use_cnn,
        "reward_window": reward_window,
        "prediction_time_seconds": time.time() - start_time
    }
    
    with open(f"{result_subfolder}/prediction_config.json", "w") as f:
        json.dump(config_info, f, indent=4, ensure_ascii=False)
    
    # 报告预测时间
    end_time = time.time()
    elapsed_time = end_time - start_time
    minutes = int(elapsed_time // 60)
    seconds = int(elapsed_time % 60)
    print(f"预测完成! 运行时间: {minutes}分 {seconds}秒")
    print(f"预测结果已保存到: {evaluation_results_path}")
    
    evaluation_RIS_path=f'{result_subfolder}/best_RIScode.npy'
    np.save(evaluation_RIS_path,np.array(best_RIScode))
    
    H_combined_pre=env._compute_H_combined(best_RIScode)
    evaluation_H_combined_path=f'{result_subfolder}/H_combined_pre.npy'
    np.save(evaluation_H_combined_path,np.array(H_combined_pre))
    
    
    return best_RIScode


if __name__ == '__main__':
    main()
    
    
#python /new_disk/ting/RL/Mycode_2/evaluate.py --model_dir /new_disk/ting/RL/results/25RIS_16t_16r_1b_11_2313good_lr41 --eval_episodes 10