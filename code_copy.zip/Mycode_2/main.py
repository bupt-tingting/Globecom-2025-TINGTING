import random
import gym
from gym import spaces
import numpy as np
from tqdm import tqdm
import torch
import torch.nn.functional as F
from torch.distributions import Normal
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, TensorDataset
import json
import sys
import os
from datetime import datetime
import time
import math

from RISenv import *
from SAC_Eff import *  #!SAC_name 记得改

#from SAC_CNN import CNNSAC

def evaluate_agent(env, agent, num_episodes=10,max_episode_steps=1):
    """
    对训练好的智能体进行评估
    
    Args:
        env: 评估环境
        agent: 训练好的智能体
        num_episodes: 评估的回合数
    
    Returns:
        mean_return: 平均回报
        std_return: 回报的标准差
        all_returns: 所有回合的回报
        all_actions: 所有回合的动作
        best_RIScode: 得到最高回报的RIS编码
    """
    returns = []
    all_actions = []
    all_RIScodes = []  # 记录所有回合的RIScode
    best_return = -float('inf')
    best_RIScode = None
    best_episode_idx = -1
    
    print(f"\nEvaluating agent over {num_episodes} episodes...")
    for i in range(num_episodes):
        episode_return = 0
        state = env.reset()
        done = False
        episode_actions = []
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            episode_return += reward
            state = next_state
            episode_actions.append(action.tolist() if isinstance(action, np.ndarray) else action)  # 记录动作
        episode_return=episode_return/max_episode_steps    
        returns.append(episode_return)
        all_actions.append(episode_actions)
        
        # 保存当前回合的RIScode
        current_RIScode = env.RIScode
        all_RIScodes.append(current_RIScode)
        
        # 更新最佳RIScode
        if episode_return > best_return:
            best_return = episode_return
            best_RIScode = current_RIScode.copy() if isinstance(current_RIScode, np.ndarray) else current_RIScode
            best_episode_idx = i
            
        print(f"Evaluation Episode {i+1}: Return = {episode_return:.4f}")
        
    mean_return = np.mean(returns)
    std_return = np.std(returns)
    
    print(f"\nEvaluation Results:")
    print(f"Mean Return: {mean_return:.4f}")
    print(f"Std Return: {std_return:.4f}")
    print(f"Min Return: {np.min(returns):.4f}")
    print(f"Max Return: {np.max(returns):.4f}")
    
    return mean_return, std_return, returns, all_actions, all_RIScodes, best_RIScode, best_episode_idx



def save_evaluation_results_to_txt(filepath, mean_return, std_return, all_returns, all_actions, all_RIScodes, best_RIScode, best_episode_idx):
    """
    将所有评估结果保存到一个txt文件中，RIScode以3D矩阵格式展示
    
    Args:
        filepath: 保存路径
        mean_return: 平均回报
        std_return: 回报标准差
        all_returns: 所有回合的回报
        all_actions: 所有回合的动作
        all_RIScodes: 所有回合的RIScode
        best_RIScode: 最佳RIScode
        best_episode_idx: 最佳回合索引
    """
    import numpy as np
    
    def format_RIScode_3D(RIScode):
        """将2D RIScode转换为3D并格式化为可读字符串"""
        # 获取RIScode的形状
        num_time_slots, num_RIS = RIScode.shape
        
        # 尝试找到最接近的平方根作为网格尺寸
        sqrt_num_RIS = int(np.sqrt(num_RIS))
        if sqrt_num_RIS ** 2 == num_RIS:
            num_RISm = num_RISn = sqrt_num_RIS
        else:
            # 找到最接近的因子
            for i in range(int(np.sqrt(num_RIS)), 0, -1):
                if num_RIS % i == 0:
                    num_RISm = i
                    num_RISn = num_RIS // i
                    break
        
        # 重塑为3D
        RIScode_3D = RIScode.reshape(num_time_slots, num_RISm, num_RISn)
        
        # 生成每个时间槽的字符串表示
        slot_strings = []
        for t in range(num_time_slots):
            lines = []
            lines.append(f"slot {t}:")
            for row in RIScode_3D[t]:
                lines.append(" ".join(str(x) for x in row))
            slot_strings.append("\n".join(lines))
        
        # 计算每个时间槽字符串的最大行数
        max_lines = max(s.count('\n') + 1 for s in slot_strings)
        
        # 将每个时间槽的字符串按行拆分
        slot_lines = [s.split('\n') for s in slot_strings]
        
        # 用空白行填充使所有时间槽有相同的行数
        for lines in slot_lines:
            while len(lines) < max_lines:
                lines.append("")
        
        # 计算每列的最大宽度
        col_widths = [max(len(line) for line in col_lines) for col_lines in slot_lines]
        
        # 逐行组合所有时间槽
        result_lines = []
        for i in range(max_lines):
            line_parts = []
            for slot_idx, lines in enumerate(slot_lines):
                # 右对齐到该列的最大宽度
                line_parts.append(lines[i].ljust(col_widths[slot_idx]))
            result_lines.append("    ".join(line_parts))
        
        return "\n".join(result_lines)
    
    with open(filepath, 'w') as f:
        # 评估摘要部分
        f.write("===========================================================\n")
        f.write("                   EVALUATION RESULTS SUMMARY      \n")
        f.write("===========================================================\n\n")
        
        f.write(f"Number of Episodes: {len(all_returns)}\n")
        f.write(f"Mean Return: {mean_return:.6f}\n")
        f.write(f"Standard Deviation: {std_return:.6f}\n")
        f.write(f"Min Return: {min(all_returns):.6f}\n")
        f.write(f"Max Return: {max(all_returns):.6f}\n")
        f.write(f"Best Episode: {best_episode_idx + 1}\n\n")
        
        # 最佳回合的RIScode部分
        f.write("===========================================================\n")
        f.write("                    BEST EPISODE RISCODE           \n")
        f.write("===========================================================\n\n")
        
        f.write(f"Episode {best_episode_idx + 1} Return: {all_returns[best_episode_idx]:.6f}\n\n")
        f.write("RIS Configuration Matrix:\n")
        
        # 使用3D格式显示最佳RIScode
        best_RIScode_np = np.array(best_RIScode)
        f.write(format_RIScode_3D(best_RIScode_np) + "\n\n")
        
        # 最佳回合的动作序列
        f.write("Action Sequence:\n")
        for i, action in enumerate(all_actions[best_episode_idx]):
            f.write(f"Step {i+1}: {action}\n")
        f.write("\n")
        
        # 所有回合的结果
        f.write("===========================================================\n")
        f.write("                       ALL EPISODES RESULTS           \n")
        f.write("===========================================================\n\n")
        
        for episode_idx in range(len(all_returns)):
            f.write(f"Episode {episode_idx + 1} Return: {all_returns[episode_idx]:.6f}\n")
            f.write("RIS Configuration Matrix:\n")
            
            # 使用3D格式显示每个回合的RIScode
            episode_RIScode_np = np.array(all_RIScodes[episode_idx])
            f.write(format_RIScode_3D(episode_RIScode_np) + "\n\n")
def main():
    """
    Main function to run the RIS environment training with SAC algorithm.
    Handles configuration loading, environment setup, agent creation, and training.
    """
    start_time = time.time()
    begin_time=datetime.now().strftime("%d day %H hour %M minus %S second")

        # 获取当前脚本文件名，用于确定使用的算法类型
    def detect_imported_sac():
        """检测已导入的SAC模块"""
        if 'SAC_CNN' in sys.modules:
            return 'SAC_CNN'
        elif 'SAC_Eff' in sys.modules:
            return 'SAC_Eff'
        elif 'SAC_Transformer' in sys.modules or 'SAC_Trans' in sys.modules:
            return 'SAC_Transformer'
        elif 'SAC_Attention' in sys.modules or 'SAC_Att' in sys.modules:
            return 'SAC_Attention'
        else:
            return 'SAC_Eff'  # 默认值

    # 调用此函数确定SAC名称
    SAC_name = detect_imported_sac()    
    
    # Load configuration
    os.chdir('/new_disk/ting/RL/Mycode_2')  # 修改工作路径
    with open("..//ChannelGen//RISconfig.json", "r") as f:
        RISconfig = json.load(f)
    
    # Extract configuration parameters
    SNR = RISconfig["snr"]
    num_time_slots = RISconfig["num_time_slots"]   # 时隙数量
    bits = RISconfig["bits"]                        # 量化位数
    seed = RISconfig["seed"]
    
    num_RISm = RISconfig["N_RISm"]
    num_RISn = RISconfig["N_RISn"]
    num_RIS = num_RISm * num_RISn
    
    num_BSm = RISconfig["N_BSm"]
    num_BSn = RISconfig["N_BSn"]
    num_UEm = RISconfig["N_UEm"]
    num_UEn = RISconfig["N_UEn"]
    num_tx = num_BSm * num_BSn
    num_rx = num_UEm * num_UEn
    use_cnn = RISconfig["use_cnn"]
    power_weight=RISconfig["power_weight"]
    if use_cnn:#SAC_name
        SAC_name = 'SAC_CNN'
        
    # Load and preprocess channel data
    file_path_BS2RIS = f'../MyData/H_BS2RIS_{num_RISm}*{num_RISn}RIS_{num_BSm}*{num_BSn}_{num_UEm}*{num_UEn}_MIMO.mat'
    file_path_RIS2UE = f'../MyData/H_RIS2UE_{num_RISm}*{num_RISn}RIS_{num_BSm}*{num_BSn}_{num_UEm}*{num_UEn}_MIMO.mat'
    
    H_BS2RIS = hdf5storage.loadmat(file_path_BS2RIS)['H_BS2RIS']
    H_RIS2UE = hdf5storage.loadmat(file_path_RIS2UE)['H_RIS2UE']
    
    H_BS2RIS = whitening(add_noise(H_BS2RIS, SNR))
    H_RIS2UE = whitening(add_noise(H_RIS2UE, SNR))
    
    #print('H_BS2RIS.shape,H_RIS2UE.shape:', H_BS2RIS.shape, H_RIS2UE.shape)
    
    message="tau=0.001 " #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    print("="*20,"begin time:",begin_time,"="*20,"\nmessage:\t",message)
    
    print(f"================================{SAC_name}==============================")  #*

    print('num_tx:',num_tx,'\tnum_rx:',num_rx,'\tnum_RIS:',num_RIS,'\tbits:',bits,'\tnum_time_slots:',num_time_slots)
    # Set training hyperparameters
    actor_lr = 1e-5  #!
    critic_lr = 1e-5 #!
    alpha_lr = 1e-4 #!
    num_episodes = 1000#!
    hidden_dim =256#!
    gamma = 0.98
    tau = 0.001  # 软更新参数
    buffer_size = 100000
    minimal_size = 1000  # 最小缓冲区大小
    batch_size = 128 #!
     
    # Set random seeds for reproducibility
    set_all_seeds(seed)
    
    # Set up device and prepare training data
    max_episode_steps = num_time_slots * num_RIS*bits*4  #! env每一次可以采取的动作数量
    #max_episode_steps=100
    reward_window=1 #!
    device = torch.device("cuda:1") if torch.cuda.is_available() else torch.device("cpu")
    
    H_BS2RIS_train = H_BS2RIS[0, 0, 0:num_time_slots, 0, :, :]  # 6D的，保留时间的以及空间的维度,上下行2个时隙，发射天线数*接收天线数
    H_RIS2UE_train = H_RIS2UE[0, 0, 0:num_time_slots, 0, :, :]
    print('H_BS2RIS_train.shape,H_RIS2UE_train.shape:', H_BS2RIS_train.shape, H_RIS2UE_train.shape)
    
    
        
    # Create environment
    env = RISEnv(
        H_BS2RIS_train=H_BS2RIS_train,
        H_RIS2UE_train=H_RIS2UE_train,
        num_time_slots=num_time_slots,
        num_RIS=num_RIS,
        bits=bits,
        # power_weight=power_weight,
        max_episode_steps=max_episode_steps,
        use_cnn=use_cnn,
        reward_window=reward_window
    )
    
    # Set up agent parameters
        # 设置智能体state_dim
    if use_cnn:#state_dim
        # 当使用CNN时，不需要state_dim参数
        state_dim = None
    else:
        # 当使用扁平化观测时，需要获取obs_dim
        state_dim = env.obs_dim
    num_action_dims = num_time_slots
    num_choices = num_RIS + 1  # 多一个，表示不步进
    target_entropy =  np.log(num_choices)
    
    # Create replay buffer and agent
    replay_buffer = ReplayBuffer(buffer_size)
    
    # 基于use_cnn参数选择对应的SAC实现
    # Create replay buffer and agent
    # 根据算法类型动态创建对应的 ReplayBuffer 和智能体  #*
    if SAC_name == 'SAC_CNN':  #*

        agent = CNNSAC(  #*
            hidden_dim,   #*
            num_action_dims,   #*
            num_choices,  #*
            actor_lr,   #*
            critic_lr,   #*
            alpha_lr,   #*
            target_entropy,   #*
            tau,   #*
            gamma,   #*
            device  #*
        )  #*
    elif SAC_name == 'SAC_Eff':  #*
        agent = EfficientSAC_MultiDiscrete(  #*
            state_dim,   #*
            hidden_dim,   #*
            num_action_dims,   #*
            num_choices,  #*
            actor_lr,   #*
            critic_lr,   #*
            alpha_lr,   #*
            target_entropy,   #*
            tau,   #*
            gamma,   #*
            device  #*
        )  #*
    elif SAC_name == 'SAC_Transformer':  #*
        # 动态导入 TransformerSAC  #*
        agent = TransformerSAC(  #*
            state_dim,   #*
            hidden_dim,   #*
            num_action_dims,   #*
            num_choices,  #*
            actor_lr,   #*
            critic_lr,   #*
            alpha_lr,   #*
            target_entropy,   #*
            tau,   #*
            gamma,   #*
            device  #*
        )  #*
    elif SAC_name == 'SAC_Attention':  #*
        # 动态导入 AttentionInteractiveSAC  #*
        agent = AttentionInteractiveSAC(  #*
            state_dim,   #*
            hidden_dim,   #*
            num_action_dims,   #*
            num_choices,  #*
            actor_lr,   #*
            critic_lr,   #*
            alpha_lr,   #*
            target_entropy,   #*
            tau,   #*
            gamma,   #*
            device  #*
        )  #*
    else:  #*
        # 默认情况，使用标准的ReplayBuffer和EfficientSAC_MultiDiscrete  #*
        agent = EfficientSAC_MultiDiscrete(  #*
            state_dim,   #*
            hidden_dim,   #*
            num_action_dims,   #*
            num_choices,  #*
            actor_lr,   #*
            critic_lr,   #*
            alpha_lr,   #*
            target_entropy,   #*
            tau,   #*
            gamma,   #*
            device  #*
        )  #*
    
    # Train agent'
    if SAC_name=='SAC_Eff':
        return_list= train_agent(env, agent, num_episodes, replay_buffer, minimal_size, batch_size,max_episode_steps)
    else:
        return_list,_= train_agent(env, agent, num_episodes, replay_buffer, minimal_size, batch_size,max_episode_steps)
        
    # 添加评估部分
    print("\n=========== Final Evaluation ===========")
    mean_return, std_return, all_returns, all_actions, all_RIScodes, best_RIScode, best_episode_idx = evaluate_agent(env, agent, num_episodes=5,max_episode_steps=max_episode_steps)
    
    # Create unique subfolder for saving results
    current_time = datetime.now().strftime("%d_%H%M%S") 
    result_subfolder = f"../results/{num_RIS}RIS_{num_tx}t_{num_rx}r_{bits}b_{current_time}" 
    os.makedirs(result_subfolder, exist_ok=True) 
    
    # 保存所有评估结果到一个txt文件
    evaluation_results_path = f"{result_subfolder}/evaluation_results.txt"
    save_evaluation_results_to_txt(
        evaluation_results_path, 
        mean_return, 
        std_return, 
        all_returns, 
        all_actions, 
        all_RIScodes, 
        best_RIScode, 
        best_episode_idx
    )
    
    # Save model parameters
    model_save_path = f"{result_subfolder}/sac_model.pt" 
    if hasattr(agent, 'save'):  #* 检查agent是否有save方法
        try:
            agent.save(model_save_path)
            print(f"模型已保存到 {model_save_path}")
        except Exception as e:
            print(f"模型保存失败: {str(e)}")
    
    # Save return list
    return_list_path = f"{result_subfolder}/return_list.npy" 
    np.save(return_list_path, np.array(return_list)) 
    
    # Save configuration information
    config_info = {
        "message":message, 
        "begin_time":begin_time,
        "SAC_name": SAC_name,
        "SNR": SNR, 
        "num_time_slots": num_time_slots, 
        "bits": bits, 
        "seed": seed, 
        "num_RISm": num_RISm,
        "num_RISn": num_RISn,
        "num_RIS": num_RIS, 
        "num_BSm": num_BSm,
        "num_BSn": num_BSn,
        "num_tx": num_tx,
        "num_UEm": num_UEm,
        "num_UEn": num_UEn,
        "num_rx": num_rx, 
        "actor_lr": actor_lr, 
        "critic_lr": critic_lr, 
        "alpha_lr": alpha_lr, 
        "num_episodes": num_episodes, 
        "hidden_dim": hidden_dim, 
        "gamma": gamma, 
        "tau": tau, 
        "buffer_size": buffer_size, 
        "minimal_size": minimal_size, 
        "batch_size": batch_size, 
        "max_episode_steps": max_episode_steps, 
        "use_cnn": use_cnn, 
        "reward_window": reward_window,
        "power_weight": power_weight, 
        "training_time_seconds": time.time() - start_time 
    }
    
    with open(f"{result_subfolder}/config.json", "w") as f: 
        json.dump(config_info, f, indent=4, ensure_ascii=False) 
    
    # Save training plot
    fig_name = f"{num_RIS}RIS_{num_tx}t_{num_rx}r_{bits}b" 
    plot_and_save_returns(return_list=return_list, title=fig_name, save_dir=result_subfolder, window_size=10, figsize=(10,8)) 
    
    # Report training time
    end_time = time.time()
    elapsed_time = end_time - start_time
    minutes = int(elapsed_time // 60)
    seconds = int(elapsed_time % 60)
    print(f"{fig_name} done! 运行时间: {minutes}分 {seconds}秒")
    print(f"结果已保存到: {result_subfolder}/evaluation_results.txt")

    
    return return_list


if __name__ == '__main__':
    main()