import torch
import torch.nn as nn
import random
import gym
from gym import spaces
import numpy as np
from tqdm import tqdm
import torch.nn.functional as F
from torch.distributions import Normal
import matplotlib.pyplot as plt
import sys
import os
from RIS_Pro import *
from Data_Pro import *
from reward import *

class RISEnv(gym.Env):
    def __init__(self,
                 H_BS2RIS_train,
                 H_RIS2UE_train,
                 num_time_slots,
                 num_RIS,
                 bits=1,
                 snr_db=25,
                 max_episode_steps=10,
                 power_weight=0.25,
                 device='cuda:1' if torch.cuda.is_available() else 'cpu',
                 use_cnn=False,
                 reward_window=5,
                 num_choices=None  # 增加动作选择数量参数
                 ):
        super(RISEnv, self).__init__()
        
        # 基本参数初始化
        self.H_BS2RIS_train = H_BS2RIS_train
        self.H_RIS2UE_train = H_RIS2UE_train
        self.bits = bits
        self.snr_db = snr_db
        self.max_episode_steps = max_episode_steps
        self.num_time_slots = num_time_slots
        self.num_RIS = num_RIS
        self.device = device
        self.num_tx=H_BS2RIS_train.shape[-2]
        self.num_rx=H_RIS2UE_train.shape[-1]
        
        self.num_UEm=int(np.sqrt(self.num_rx))
        self.num_UEn=int(np.sqrt(self.num_rx))
        # 奖励窗口设置
        self.reward_window = reward_window  # 新增多步平均奖励窗口
        self.reward_history = []  # 存储历史奖励
        
                # 动作空间设置
        self.num_choices = num_RIS + 1 if num_choices is None else num_choices  # 默认增加"不步进"选项
        self.use_drop = (self.num_choices == num_RIS + 1)  # 根据选择数量确定是否使用drop
        
        # 定义动作空间
        self.action_space=spaces.MultiDiscrete([self.num_RIS+1] * self.num_time_slots)
        
        # 设置观测空间
        self.use_cnn = use_cnn
        if use_cnn:
            # CNN观测空间：(2, num_time_slots*num_tx, num_rx)
            self.observation_space = spaces.Box(
                low=-np.inf,
                high=np.inf,
                shape=(2, self.num_time_slots*self.num_tx, self.num_rx),
                dtype=np.float32
            )
        else:
            # 扁平化观测空间
            self.obs_dim = self.num_time_slots*2*self.num_rx
            self.observation_space = spaces.Box(
                low=-np.inf,
                high=np.inf,
                shape=(self.obs_dim,),
                dtype=np.float32
            )
        
        # 环境内部状态
        self.current_step = 0
        self.RIScode = None
        self.state = None
        self.power_weight = power_weight


    def reset(self):
        self.current_step = 0
        self.reward_history = []  # 清空奖励历史
        self.RIScode = generate_RIScode(self.num_RIS, self.num_time_slots, self.bits, resetRIS=1)
        self.state = self._compute_state(self.RIScode)
        return self.state
    
    def step(self, action_list):
        """
        执行一步环境交互，使用平均奖励
        
        参数:
        action_list: 长度为num_time_slots的列表，每个元素范围为[0, num_choices-1]
                    表示每个时隙选择的RIS单元进行相位步进
        
        返回:
        state: 新的状态
        reward: 奖励值（使用窗口平均）
        done: 是否结束
        info: 附加信息
        """
        #action(list): 长度为 num_time_slots 的列表，[0,2,1] 表示每个动作维度选出的下标，
        self.current_step += 1

        action_matrix = self._action_to_one_hot(action_list, self.num_time_slots, self.num_RIS, self.use_drop)  # 传入use_drop参数

        
        # 更新RIScode,计算reward
        self.RIScode = update_RIScode(self.RIScode, action_matrix, self.bits, 
                                    self.num_time_slots, self.num_RIS)
        H_combined_train=self._compute_H_combined(self.RIScode)
        #仅计算接收天线
        H_Re=receiver_merging(H_combined_train,method='MRC')
        H_Re3D=H_Re2D3D(H_Re)
        
        

        
        
        total_power, avg_power=calculate_mimo_power(H_combined_train,use_db=True)
        
        #print(f"total_power:{total_power}, avg_power:{avg_power}")
        #security_reward=0
        security_reward=100*compute_reward_mse(H_combined_train)
        #print(f"security_reward:{security_reward}")
        power_reward=0.5*np.mean(avg_power)

        #power_reward=0
        current_reward=security_reward+power_reward
        #print(f"current_reward:{current_reward}")
        
        #将当前奖励添加到历史记录
        self.reward_history.append(current_reward)
        
        # 计算平均奖励（使用窗口）
        if len(self.reward_history) > self.reward_window:
            window_rewards = self.reward_history[-self.reward_window:]
        else:
            window_rewards = self.reward_history
        
        avg_reward = np.mean(window_rewards)  # 使用窗口平均奖励
        
        # 计算新状态
        self.state = self._compute_state(self.RIScode)
        
        # 判断是否结束
        #done = (self.current_step >= self.max_episode_steps) or \
        #       (np.all(self.RIScode == 0))
        done=  (self.current_step >= self.max_episode_steps)  
        
        info = {
            'current_step': self.current_step,
            'RIScode': self.RIScode.copy(),
            'current_reward': current_reward,  # 保存当前步的原始奖励
            'reward_history': self.reward_history.copy(),  # 保存完整奖励历史
            'window_size': len(window_rewards),  # 实际使用的窗口大小
            'avg_power': np.mean(avg_power),  # 添加平均功率信息
            'security_reward': security_reward 
        }
        
        return self.state, avg_reward, done, info
        
    def _compute_H_combined(self, code):
        """计算组合信道矩阵"""
        Phi = map_RIScode_to_Phi(code, self.bits)
        H_combined_train = multiple_RIS(self.H_BS2RIS_train, Phi, self.H_RIS2UE_train)
        return H_combined_train
    
    def _compute_state(self, code):
        """计算状态"""
        H_combined_train=self._compute_H_combined(code)
        
        #Hc_train=H_combined_train
        Hc_train=H_Re2D3D(receiver_merging(H_combined_train,method='MRC'))

        if self.use_cnn:
            # 将复数数据转换为两通道（实部和虚部）的实数数据  
            # 得到 shape: (2, num_time_slots, num_tx, num_rx)
            Hc_train_real = C2R(Hc_train)
            image = Hc_train_real.reshape(2, self.num_time_slots*self.num_tx, self.num_rx)
            state = image    
            
        else:
            real_part = np.real(Hc_train).flatten()
            imag_part = np.imag(Hc_train).flatten()
            state = np.concatenate([real_part, imag_part], axis=0)
        return state.astype(np.float32)
    
    def _action_to_one_hot(self,action_list, num_time_slots, num_RIS,use_drop=True):
        """
        将 action 列表转换为独热编码矩阵

        参数:
            action_list (list): 长度为 num_time_slots 的列表，每个元素为一个整数，
                                表示第 i 个时隙对应的 RIS 单元动作（取值范围 0 ~ num_RIS-1）
                                 use_drop时，表示第 i 个时隙对应的 RIS 单元动作（取值范围 0 ~ num_RIS）共num_RIS+1 个动作
            use_drop：RIS 单元最后一个动作是否丢弃（取值范围 0 ~ num_RIS），共有 num_RIS+1 个动作，其中最后一个动作为不操作，即不更新 RIScode        
            num_time_slots (int): 时隙个数
            num_RIS (int): RIS 单元个数，对应独热编码的列数

        返回:
            one_hot_matrix (np.ndarray): 形状为 (num_time_slots, num_RIS) 的独热编码矩阵
        """
        if use_drop:
        # 初始化全为0的矩阵,数据类型建议使用整数
            one_hot_matrix = np.zeros((num_time_slots, num_RIS+1), dtype=int)            
            # 遍历每个时隙，设置对应位置为 1
            for idx, action in enumerate(action_list):
                if idx < num_time_slots and 0 <= action < num_RIS+1:
                    one_hot_matrix[idx, action] = 1
                else:
                    raise ValueError("action_list 中的元素或者长度不符合要求")            
            return one_hot_matrix[:,:-1]
        else:
            one_hot_matrix = np.zeros((num_time_slots, num_RIS), dtype=int)
            for idx, action in enumerate(action_list):
                if idx < num_time_slots and 0 <= action < num_RIS:
                    one_hot_matrix[idx, action] = 1
                else:
                        raise ValueError("action_list 中的元素或者长度不符合要求")
            return one_hot_matrix
    
            
class RISParams:
    """RIS环境的参数管理类"""
    def __init__(self):
        self.num_ris =25           # RIS单元数量
        self.num_time_slots = 2    # 时隙数量
        self.bits = 1              # 量化位数
        self.snr = 25              # 信噪比(dB)
        self.seed = 42             # 随机种子
        self.max_episode_steps = 10  # 每个Episode的最大步数
        self.power_weight = 0.1     # 功率奖励权重   



    
if __name__ == '__main__':    
    import hdf5storage
    
    os.chdir('/new_disk/ting/RL/Mycode_2')#修改工作路径


    file_path_BS2RIS='../MyData/H_BS2RIS_5*5RIS_4*4_4*4_MIMO.mat'
    file_path_RIS2UE='../MyData/H_RIS2UE_5*5RIS_4*4_4*4_MIMO.mat'
    H_BS2RIS=hdf5storage.loadmat(file_path_BS2RIS)['H_BS2RIS']
    H_RIS2UE=hdf5storage.loadmat(file_path_RIS2UE)['H_RIS2UE']
    print(H_BS2RIS.shape,H_RIS2UE.shape)
    #H_RIS2UE = np.expand_dims(hdf5storage.loadmat(file_path_RIS2UE)['H_RIS2UE'], axis=-1)

    RISParams=RISParams()
    SNR=RISParams.snr
    num_RIS=RISParams.num_ris
    num_time_slots = RISParams.num_time_slots   # 时隙数量
    bits = RISParams.bits             # 量化位数
    seed = RISParams.seed
    max_episode_steps=5
    set_all_seeds(seed)
    # 数据预处理
    H_BS2RIS = whitening(add_noise(H_BS2RIS, SNR))
    H_RIS2UE = whitening(add_noise(H_RIS2UE, SNR))
    print(H_BS2RIS.shape,H_RIS2UE.shape)
    H_BS2RIS_train=H_BS2RIS[0,0,0:2,0,:,:]#6D->3D，保留时间的以及空间的维度,上下行2个时隙，发射天线数*接收天线数
    H_RIS2UE_train=H_RIS2UE[0,0,0:2,0,:,:]
    print(H_BS2RIS_train.shape,H_RIS2UE_train.shape)
    # 创建环境
    env = RISEnv(
                    H_BS2RIS_train=H_BS2RIS_train,
                    H_RIS2UE_train=H_RIS2UE_train,
                    num_time_slots=num_time_slots,
                    num_RIS=num_RIS,
                    bits=bits,  
                    max_episode_steps=max_episode_steps,
                    use_cnn=False, 
                )

    # 测试环境
    state = env.reset()
    reward_total=0
    return_list=[]
    num_steps=10000
    for _ in range(num_steps):
        
        #action = generate_RIScode(num_RIS, num_time_slots, bits, seed=None, resetRIS=0,full_radom=0,zeros_ratio=0.8)
        #action_list=np.zeros(num_time_slots,dtype=int)
        action_list=[random.randint(0, num_RIS) for _ in range(num_time_slots)]
        
        next_state, reward, done, info = env.step(action_list)        
        # print(visualize_3D_RIScode(RIScode2D3D(info["RIScode"])))
        # print('avg_power:',info["avg_power"])
        # print('security_reward:',info["security_reward"])
        # print("Action:", action_list)
        # print("Reward:", f"{reward:.3f}","-----Done:", done)
        # print('----------------------------------------')
        reward_total=reward_total+reward
        return_list=return_list+[reward]
    reward_mean=reward_total/num_steps
    print("Reward_mean:", f"{reward_mean:.3f}")
    #print("Return:", return_list)
    np.save("../results2/return_list.npy",np.array(return_list))

        
        
