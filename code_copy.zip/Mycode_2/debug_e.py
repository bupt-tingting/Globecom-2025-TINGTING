# debug_script.py
import os
import sys
os.chdir('/new_disk/ting/RL/Mycode_2')
# 设置固定的参数
sys.argv = ['evaluate.py', '--model_dir', '/new_disk/ting/RL/results/100RIS_16t_16r_1b_15_111022_eps1000', '--eval_episodes', '10']

# 导入原始脚本的main函数
from evaluate import main

# 运行main函数
main()