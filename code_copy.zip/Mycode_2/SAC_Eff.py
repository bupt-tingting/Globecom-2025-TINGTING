'''高效实现多头SAC'''
import random
import numpy as np
import torch
import torch.nn.functional as F
import gym
from torch.distributions import Categorical
import matplotlib.pyplot as plt
from tqdm import tqdm
import os
from RIS_Pro import *

# ---------------------------
# 1. 定义优化的 Replay Buffer
# ---------------------------
class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.position = 0

    def push(self, state, action, reward, next_state, done):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (state, action, reward, next_state, done)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        transitions = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*transitions)
        return {
            "states": np.array(state),
            "actions": np.array(action),
            "rewards": np.array(reward),
            "next_states": np.array(next_state),
            "dones": np.array(done)
        }

    def __len__(self):
        return len(self.buffer)

# ---------------------------
# 2. 定义考虑动作交互的高效环境
# ---------------------------
class InteractiveMultiDiscreteEnv(gym.Env):
    """具有动作维度交互效应但计算效率更高的环境"""
    def __init__(self, num_action_dims=3, num_choices=4):
        super(InteractiveMultiDiscreteEnv, self).__init__()
        self.num_action_dims = num_action_dims
        self.num_choices = num_choices
        self.observation_space = gym.spaces.Box(low=-1, high=1, shape=(num_action_dims * 2,), dtype=np.float32)
        self.action_space = gym.spaces.MultiDiscrete([num_choices] * num_action_dims)
        self.max_steps = 100
        self.current_step = 0
        self.state = None
        
        # 预计算特定动作组合的奖励修正
        self.action_pairs_cache = {}
        for i in range(num_choices):
            for j in range(num_choices):
                key = (i, j)
                # 例如：第一维是偶数，第二维是奇数时有特殊奖励
                self.action_pairs_cache[key] = 1.0 if i % 2 == 0 and j % 2 == 1 else 0.0

    def reset(self):
        self.current_step = 0
        self.state = np.random.uniform(-0.5, 0.5, size=(self.num_action_dims * 2,))
        return self.state.copy()

    def step(self, action):
        self.current_step += 1
        reward = self._calculate_reward(action)
        self._update_state(action)
        done = self.current_step >= self.max_steps
        return self.state.copy(), reward, done, {}

    def _calculate_reward(self, action):
        """计算考虑动作交互的奖励，但更高效"""
        reward = 0.0
        
        # 1. 状态-动作匹配度：每个动作维度独立的奖励
        for i in range(self.num_action_dims):
            state_indicator = self.state[i] + 0.5  # 转换到[0,1]范围
            optimal_action = int(state_indicator * (self.num_choices - 1) + 0.5)
            action_similarity = 1.0 - abs(action[i] - optimal_action) / (self.num_choices - 1)
            reward += 0.5 * action_similarity
        
        # 2. 动作维度间的交互效应（使用查表加速）
        if self.num_action_dims >= 2:
            # 查表获取前两个动作的交互奖励
            pair_key = (action[0], action[1])
            if pair_key in self.action_pairs_cache:
                reward += self.action_pairs_cache[pair_key]
            
            # 所有动作相同的情况（惩罚）
            if len(set(action)) == 1:
                reward -= 0.5
        
        # 3. 简化的非线性奖励关系
        action_sum = np.sum(action)
        threshold = self.num_action_dims * (self.num_choices - 1) / 2
        if abs(action_sum - threshold) < self.num_action_dims:
            reward += 0.5 * (1.0 - abs(action_sum - threshold) / self.num_action_dims)
        
        return reward

    def _update_state(self, action):
        """动作影响下一状态，优化计算"""
        noise = np.random.normal(0, 0.1, size=self.state.shape)
        
        # 高效状态更新
        action_effects = np.zeros_like(self.state)
        for i in range(self.num_action_dims):
            effect = (action[i] / (self.num_choices - 1) - 0.5) * 0.2
            action_effects[i] += effect
            
            # 简化的交互：只影响相邻维度
            if i + 1 < self.num_action_dims:
                action_effects[i + 1] += effect * 0.3
        
        self.state += action_effects + noise
        self.state = np.clip(self.state, -1.0, 1.0)

# ---------------------------
# 3. 高效的策略网络
# ---------------------------
class EfficientPolicyNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, num_action_dims, num_choices):
        super(EfficientPolicyNet, self).__init__()
        self.backbone = torch.nn.Sequential(
            torch.nn.Linear(state_dim, hidden_dim),
            torch.nn.ELU(),
            torch.nn.Linear(hidden_dim, hidden_dim),
            torch.nn.ELU()
        )
        
        # 使用单层输出头，减少参数
        self.action_heads = torch.nn.ModuleList([
            torch.nn.Linear(hidden_dim, num_choices) for _ in range(num_action_dims)
        ])

    def forward(self, x):
        features = self.backbone(x)
        logits = [head(features).unsqueeze(1) for head in self.action_heads]
        logits = torch.cat(logits, dim=1)  # [batch, num_action_dims, num_choices]
        probs = F.softmax(logits, dim=-1)
        return probs

# ---------------------------
# 4. 优化的 Q 网络，考虑动作交互
# ---------------------------
class EfficientQNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, num_action_dims, num_choices):
        super(EfficientQNet, self).__init__()
        self.num_action_dims = num_action_dims
        
        # 基础特征提取
        self.backbone = torch.nn.Sequential(
            torch.nn.Linear(state_dim, hidden_dim),
            torch.nn.ELU(),
            torch.nn.Linear(hidden_dim, hidden_dim),
            torch.nn.ELU()
        )
        
        # 维度间交互层
        self.interaction_layer = torch.nn.Sequential(
            torch.nn.Linear(hidden_dim, hidden_dim),
            torch.nn.ELU()
        )
        
        # 每个动作维度的输出头
        self.output_heads = torch.nn.ModuleList([
            torch.nn.Linear(hidden_dim, num_choices) for _ in range(num_action_dims)
        ])
        
    def forward(self, x):
        # 提取共享特征
        shared_features = self.backbone(x)
        
        # 应用交互层
        interaction_features = self.interaction_layer(shared_features)
        # 残差连接，保留原始特征信息
        enhanced_features = shared_features + interaction_features
        
        # 计算每个维度的Q值
        q_values = []
        for head in self.output_heads:
            q = head(enhanced_features).unsqueeze(1)  # [batch, 1, num_choices]
            q_values.append(q)
            
        q_values = torch.cat(q_values, dim=1)  # [batch, num_action_dims, num_choices]
        return q_values

# ---------------------------
# 5. 高效的 SAC 算法实现
# ---------------------------
class EfficientSAC_MultiDiscrete:
    def __init__(self, state_dim, hidden_dim, num_action_dims, num_choices,
                 actor_lr, critic_lr, alpha_lr, target_entropy, tau, gamma, device,
                 update_interval=1,training_info=False):
        self.device = device
        self.gamma = gamma
        self.tau = tau
        self.target_entropy = target_entropy
        self.num_choices = num_choices  #TODO 保存选择数量
        self.num_action_dims = num_action_dims
        self.update_interval = update_interval
        self.update_counter = 0
        self.training_info = training_info  #TODO
        
        # 保存学习率参数，便于加载模型后重新初始化优化器
        self.actor_lr = actor_lr #*
        self.critic_lr = critic_lr #*
        self.alpha_lr = alpha_lr #*
        
        # 策略网络
        self.actor = EfficientPolicyNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        
        # Q网络
        self.critic_1 = EfficientQNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        self.critic_2 = EfficientQNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        self.target_critic_1 = EfficientQNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        self.target_critic_2 = EfficientQNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        
        # 拷贝初始权重
        self.target_critic_1.load_state_dict(self.critic_1.state_dict())
        self.target_critic_2.load_state_dict(self.critic_2.state_dict())
        
        # 优化器
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_1_optimizer = torch.optim.Adam(self.critic_1.parameters(), lr=critic_lr)
        self.critic_2_optimizer = torch.optim.Adam(self.critic_2.parameters(), lr=critic_lr)
        
        # 自动调节的熵参数
        self.log_alpha = torch.tensor(np.log(0.01), dtype=torch.float).to(device)
        self.log_alpha.requires_grad = True
        self.log_alpha_optimizer = torch.optim.Adam([self.log_alpha], lr=alpha_lr)


    def save(self, path): #*
        """保存模型参数到指定路径""" #*
        torch.save({ #*
            'actor_state_dict': self.actor.state_dict(), #*
            'critic_1_state_dict': self.critic_1.state_dict(), #*
            'critic_2_state_dict': self.critic_2.state_dict(), #*
            'target_critic_1_state_dict': self.target_critic_1.state_dict(), #*
            'target_critic_2_state_dict': self.target_critic_2.state_dict(), #*
            'log_alpha': self.log_alpha.detach().cpu().numpy(), #*
            'actor_optimizer_state_dict': self.actor_optimizer.state_dict(), #*
            'critic_1_optimizer_state_dict': self.critic_1_optimizer.state_dict(), #*
            'critic_2_optimizer_state_dict': self.critic_2_optimizer.state_dict(), #*
            'log_alpha_optimizer_state_dict': self.log_alpha_optimizer.state_dict() #*
        }, path) #*
        #print(f"模型已保存到 {path}") #*

    def load(self, path, device=None): #*
        """从指定路径加载模型参数""" #*
        if device is None: #*
            device = self.device #*
            
        checkpoint = torch.load(path, map_location=device) #*
        
        self.actor.load_state_dict(checkpoint['actor_state_dict']) #*
        self.critic_1.load_state_dict(checkpoint['critic_1_state_dict']) #*
        self.critic_2.load_state_dict(checkpoint['critic_2_state_dict']) #*
        self.target_critic_1.load_state_dict(checkpoint['target_critic_1_state_dict']) #*
        self.target_critic_2.load_state_dict(checkpoint['target_critic_2_state_dict']) #*
        
        # 加载log_alpha #*
        log_alpha_np = checkpoint['log_alpha']  #*
        self.log_alpha = torch.tensor(log_alpha_np, device=device, requires_grad=True) #*
        
        # 加载优化器状态 #*
        self.actor_optimizer.load_state_dict(checkpoint['actor_optimizer_state_dict']) #*
        self.critic_1_optimizer.load_state_dict(checkpoint['critic_1_optimizer_state_dict']) #*
        self.critic_2_optimizer.load_state_dict(checkpoint['critic_2_optimizer_state_dict']) #*
        self.log_alpha_optimizer.load_state_dict(checkpoint['log_alpha_optimizer_state_dict']) #*
        print(f"模型已从 {path} 加载") #*
        
        
    def take_action(self, state):
        """根据策略选择动作"""
        state = np.array([state])
        state = torch.from_numpy(state).float().to(self.device)
        
        with torch.no_grad():
            probs = self.actor(state)  # [1, num_action_dims, num_choices]
        
        actions = []
        for i in range(probs.size(1)):
            distribution = Categorical(probs[:, i, :])
            actions.append(distribution.sample().item())
        
        return np.array(actions)

    def calc_target_efficiently(self, rewards, next_states, dones):
        """高效计算目标Q值"""
        with torch.no_grad():
            next_probs = self.actor(next_states)  # [B, K, N]
            next_log_probs = torch.log(next_probs + 1e-8)
            entropy = -torch.sum(next_probs * next_log_probs, dim=2)  # [B, K]
            joint_entropy = torch.sum(entropy, dim=1, keepdim=True)  # [B, 1]
            
                
            # 计算动作空间大小
            action_space_size = self.num_action_dims * self.num_choices  #TODO
            
            # 自适应采样数量：根据动作空间大小动态调整，但考虑计算效率限制
            # 基本采样数量
            base_samples = 2  #TODO
            
            # 随着动作空间增大而增加采样数，使用对数缩放以平衡计算效率
            # 对数缩放确保即使动作空间非常大，采样数也不会无限增长
            additional_samples = int(np.log2(action_space_size))  #TODO
            
            # 设置合理上限以避免计算过于昂贵
            num_samples = min(base_samples + additional_samples, 16)  #TODO
            
            # 确保至少有最小采样数
            num_samples = max(num_samples, 2)  #TODO
                
            if self.training_info and (self.update_counter % 100 == 0):  #TODO
                print(f"Action space size: {action_space_size}, Using {num_samples} samples")  #TODO
            
            if num_samples > 0:
                sampled_q_values = []
                for _ in range(num_samples):
                    # 采样完整动作组合
                    actions = []
                    for i in range(self.num_action_dims):
                        distrib = Categorical(next_probs[:, i, :])
                        actions.append(distrib.sample().unsqueeze(1))
                    actions = torch.cat(actions, dim=1)  # [B, K]
                    
                    # 获取采样动作的Q值
                    q1 = self.target_critic_1(next_states)  # [B, K, N]
                    q2 = self.target_critic_2(next_states)  # [B, K, N]
                    min_q = torch.min(q1, q2)
                    
                    # 提取这些动作的Q值
                    indices = actions.unsqueeze(-1)  # [B, K, 1]
                    selected_q = min_q.gather(2, indices).squeeze(-1)  # [B, K]
                    joint_q = torch.sum(selected_q, dim=1, keepdim=True)  # [B, 1]
                    sampled_q_values.append(joint_q)
                
                expected_q = torch.mean(torch.cat(sampled_q_values, dim=1), dim=1, keepdim=True)
            else:
                # 回退到最简单方法：使用最高概率动作
                actions = torch.argmax(next_probs, dim=2)  # [B, K]
                q1 = self.target_critic_1(next_states)
                q2 = self.target_critic_2(next_states)
                min_q = torch.min(q1, q2)
                
                indices = actions.unsqueeze(-1)
                selected_q = min_q.gather(2, indices).squeeze(-1)
                expected_q = torch.sum(selected_q, dim=1, keepdim=True)
            
            # 计算目标值
            td_target = rewards + self.gamma * (1 - dones) * (expected_q + self.log_alpha.exp() * joint_entropy)
            
            return td_target

    def soft_update(self, net, target_net):
        """软更新目标网络"""
        for param_target, param in zip(target_net.parameters(), net.parameters()):
            param_target.data.copy_(param_target.data * (1.0 - self.tau) + param.data * self.tau)

    def update(self, transition_dict):
        """更新网络参数"""
        self.update_counter += 1
        if self.update_counter % self.update_interval != 0:
            return  # 跳过部分更新步骤
            
        states = torch.tensor(transition_dict['states'], dtype=torch.float).to(self.device)
        actions = torch.tensor(transition_dict['actions'], dtype=torch.long).to(self.device)
        rewards = torch.tensor(transition_dict['rewards'], dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(transition_dict['next_states'], dtype=torch.float).to(self.device)
        dones = torch.tensor(transition_dict['dones'], dtype=torch.float).view(-1, 1).to(self.device)

        # 高效计算目标Q值
        td_target = self.calc_target_efficiently(rewards, next_states, dones)

        # 更新 critic 1
        current_q1 = self.critic_1(states)
        selected_q1 = current_q1.gather(dim=2, index=actions.unsqueeze(-1)).squeeze(-1)
        q1_value = torch.sum(selected_q1, dim=1, keepdim=True)
        critic_1_loss = F.mse_loss(q1_value, td_target)

        self.critic_1_optimizer.zero_grad()
        critic_1_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic_1.parameters(), max_norm=1.0)
        self.critic_1_optimizer.step()

        # 更新 critic 2
        current_q2 = self.critic_2(states)
        selected_q2 = current_q2.gather(dim=2, index=actions.unsqueeze(-1)).squeeze(-1)
        q2_value = torch.sum(selected_q2, dim=1, keepdim=True)
        critic_2_loss = F.mse_loss(q2_value, td_target)

        self.critic_2_optimizer.zero_grad()
        critic_2_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic_2.parameters(), max_norm=1.0)
        self.critic_2_optimizer.step()

        # 更新策略网络
        probs = self.actor(states)
        log_probs = torch.log(probs + 1e-8)
        entropy = -torch.sum(probs * log_probs, dim=2)
        joint_entropy = torch.sum(entropy, dim=1, keepdim=True)

        # 计算当前策略下的Q值期望
        with torch.no_grad():
            q1 = self.critic_1(states)
            q2 = self.critic_2(states)
            min_q = torch.min(q1, q2)
            
        expected_q = torch.sum(probs * min_q, dim=2)
        joint_expected_q = torch.sum(expected_q, dim=1, keepdim=True)

        actor_loss = torch.mean(-self.log_alpha.exp() * joint_entropy - joint_expected_q)
        
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1.0)
        self.actor_optimizer.step()

        # 更新熵系数 alpha
        alpha_loss = torch.mean((joint_entropy - self.target_entropy).detach() * self.log_alpha.exp())
        
        self.log_alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.log_alpha_optimizer.step()

        # 软更新目标网络
        self.soft_update(self.critic_1, self.target_critic_1)
        self.soft_update(self.critic_2, self.target_critic_2)

# ---------------------------
# 6. 训练函数
# ---------------------------
def train_agent(env, agent, num_episodes, replay_buffer, minimal_size, batch_size,max_episode_steps=1):
    return_list = []
    
    for i_episode in tqdm(range(num_episodes)):
        episode_return = 0
        state = env.reset()
        done = False
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            replay_buffer.push(state, action, reward, next_state, done)
            state = next_state
            episode_return += reward

            if len(replay_buffer) > minimal_size:
                transition = replay_buffer.sample(batch_size)
                agent.update(transition)
                
        return_list.append(episode_return/max_episode_steps)
        
        if (i_episode + 1) % 20 == 0:
            avg_return = np.mean(return_list[-10:])
            print(f"Episode: {i_episode+1}, Avg Return: {avg_return:.2f}")
            
    return return_list

# ---------------------------
# 7. 评估函数
# ---------------------------
def evaluate_agent(env, agent, num_episodes=10):
    returns = []
    
    for _ in range(num_episodes):
        episode_return = 0
        state = env.reset()
        done = False
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            episode_return += reward
            state = next_state
            
        returns.append(episode_return)
        
    mean_return = np.mean(returns)
    std_return = np.std(returns)
    
    print(f"Evaluation over {num_episodes} episodes: Mean Return = {mean_return:.2f}, Std = {std_return:.2f}")
    
    return mean_return, std_return

# ---------------------------
# 8. 绘图函数，从RIS_Pro中引入吧
# ---------------------------
'''
def plot_and_save_returns(return_list, title,save=True, save_dir='./results', window_size=5, figsize=(10, 6)):
    """绘制训练回报曲线并保存"""
    # 创建保存目录
    os.makedirs(save_dir, exist_ok=True)
    
    # 计算滑动平均
    if window_size > 1:
        smoothed_returns = []
        for i in range(len(return_list)):
            start_idx = max(0, i - window_size + 1)
            smoothed_returns.append(np.mean(return_list[start_idx:i+1]))
    else:
        smoothed_returns = return_list
    
    plt.rcParams['font.family'] = 'serif' #*
    plt.rcParams['font.size'] = 12 #* 设置默认字体大小
    
    # 绘图
    plt.figure(figsize=figsize)
    # 设置线条颜色和粗细
    plt.plot(return_list, alpha=0.3, label='Raw Returns', 
             color='#1f77b4', linewidth=1.0) #* 设置原始回报线为蓝色，线宽1.0
    plt.plot(smoothed_returns, label=f'Smoothed Returns (window={window_size})', 
             color='#ff7f0e', linewidth=1.5) #* 设置平滑回报线为橙色，线宽2.5
    
    plt.xlabel('Episode', fontsize=14) #* 设置x轴标签字体大小
    plt.ylabel('Return', fontsize=14) #* 设置y轴标签字体大小
    plt.title(title, fontsize=16) #* 设置标题字体大小
    plt.legend(fontsize=12) #* 设置图例字体大小
    plt.xticks(fontsize=12) #* 设置x轴刻度字体大小
    plt.yticks(fontsize=12) #* 设置y轴刻度字体大小
    plt.grid(True, alpha=0.3)
    
    # 控制边框线宽
    ax = plt.gca()
    for spine in ax.spines.values():
        spine.set_linewidth(0.5) #* 设置坐标轴边框线宽
    
    # 保存图片
    if save:
        save_path = os.path.join(save_dir, f"{title.replace(' ', '_')}.png")
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    # 显示图片
    plt.show()
'''
# ---------------------------
# 9. 主函数
# ---------------------------
def main():
    import json
    import os
    import time
    from datetime import datetime
    os.chdir("/new_disk/ting/RL/Mycode_2")
    # 创建特定的输出文件夹
    output_dir = os.path.join("../results", "Eff_MultiDiscrete_SAC")
    os.makedirs(output_dir, exist_ok=True)
    
    # 创建带时间戳的子文件夹，避免覆盖之前的结果
    timestamp = datetime.now().strftime("%m%d_%H%M")
    run_dir = os.path.join(output_dir, f"run_{timestamp}")
    os.makedirs(run_dir, exist_ok=True)
    
    # 配置参数
    params = {
        "actor_lr": 5e-5,
        "critic_lr": 5e-5,
        "alpha_lr": 5e-5,
        "num_episodes": 100,
        "hidden_dim": 64,
        "gamma": 0.98,
        "tau": 0.005,
        "buffer_size": 10000,
        "minimal_size": 500,
        "batch_size": 64,
        "update_interval": 2,
        "num_action_dims": 2,
        "num_choices": 10,
        "device": "cuda" if torch.cuda.is_available() else "cpu"
    }
    
    # 将参数字典保存为JSON文件
    params_file = os.path.join(run_dir, "parameters.json")
    with open(params_file, "w") as f:
        json.dump(params, f, indent=4)
    
    print(f"Parameters saved to {params_file}")
    print(f"Using device: {params['device']}")
    
    # 目标熵与动作维度相关
    target_entropy = -params["num_action_dims"]
    
    # 初始化环境
    env = InteractiveMultiDiscreteEnv(params["num_action_dims"], params["num_choices"])
    state_dim = env.observation_space.shape[0]
    
    # 初始化 replay buffer 和 agent
    replay_buffer = ReplayBuffer(params["buffer_size"])
    agent = EfficientSAC_MultiDiscrete(
        state_dim, params["hidden_dim"], params["num_action_dims"], params["num_choices"],
        params["actor_lr"], params["critic_lr"], params["alpha_lr"], target_entropy, 
        params["tau"], params["gamma"], torch.device(params["device"]),
        update_interval=params["update_interval"]
    )
    
    # 训练计时
    start_time = time.time()
    print("Starting training...")
    return_list = train_agent(
        env, agent, params["num_episodes"], replay_buffer, 
        params["minimal_size"], params["batch_size"]
    )
    training_time = time.time() - start_time
    
    # 评估
    print("Evaluating agent...")
    num_eval_episodes = 20  # 评估更多次以获得更可靠的结果
    mean_return, std_return = evaluate_agent(env, agent, num_episodes=num_eval_episodes)
    
    # 保存模型
    model_path = os.path.join(run_dir, "agent_model.pt")
    agent.save(model_path)
    print(f"Model saved to {model_path}")
    
    # 保存评估结果到txt文件
    results = {
        "mean_return": mean_return,
        "std_return": std_return,
        "num_eval_episodes": num_eval_episodes,
        "training_time_seconds": training_time,
        "final_10_episode_avg_return": np.mean(return_list[-10:])
    }
    
    results_file = os.path.join(run_dir, "evaluation_results.txt")
    with open(results_file, "w") as f:
        f.write("Evaluation Results:\n")
        f.write(f"Mean Return: {mean_return:.4f}\n")
        f.write(f"Standard Deviation: {std_return:.4f}\n")
        f.write(f"Number of Evaluation Episodes: {num_eval_episodes}\n")
        f.write(f"Training Time: {training_time:.2f} seconds\n")
        f.write(f"Average Return (last 10 episodes): {np.mean(return_list[-10:]):.4f}\n")
        
        # 添加训练参数摘要
        f.write("\nTraining Parameters:\n")
        f.write(f"Action Dimensions: {params['num_action_dims']}\n")
        f.write(f"Choices per Dimension: {params['num_choices']}\n")
        f.write(f"Episodes: {params['num_episodes']}\n")
        f.write(f"Learning Rates - Actor: {params['actor_lr']}, Critic: {params['critic_lr']}, Alpha: {params['alpha_lr']}\n")
    
    print(f"Evaluation results saved to {results_file}")
    
    # 绘制结果
    plot_and_save_returns(
        return_list, 
        f"Eff MultiDiscrete SAC Return {mean_return:.2f}",
        save=True,
        save_dir=run_dir, 
        window_size=10
    )
    

    return agent

# 直接运行# 直接运行
if __name__ == "__main__":
    main()