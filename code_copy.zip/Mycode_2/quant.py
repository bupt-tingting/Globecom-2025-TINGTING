import numpy as np
import matplotlib.pyplot as plt

def adaptive_2bit_quantization(H_combined_pre):
    """
    对信道估计结果H_combined_pre进行2bit自适应量化，分为四个区间
    
    参数:
        H_combined_pre: 信道估计结果，形状为(2, 16, 16)，其中2代表不同时隙
        
    返回:
        quantized_H: 量化后的信道矩阵，形状与输入相同，值为{0,1,2,3}
    """
    num_time_slots, rows, cols = H_combined_pre.shape
    quantized_H = np.zeros_like(H_combined_pre, dtype=np.int8)
    
    # 为每个时隙单独计算阈值并量化
    for t in range(num_time_slots):
        # 获取当前时隙的数据
        current_slot_data = H_combined_pre[t]
        
        # 计算四分位点作为阈值
        q1 = np.percentile(current_slot_data, 25)
        q2 = np.percentile(current_slot_data, 50)
        q3 = np.percentile(current_slot_data, 75)
        
        # 分别量化四个区间
        quantized_H[t][current_slot_data <= q1] = 0
        quantized_H[t][(current_slot_data > q1) & (current_slot_data <= q2)] = 1
        quantized_H[t][(current_slot_data > q2) & (current_slot_data <= q3)] = 2
        quantized_H[t][current_slot_data > q3] = 3
        
        # 打印当前时隙的量化统计信息
        print(f"\n时隙 {t+1} 量化统计:")
        print(f"阈值: Q1={q1:.4f}, Q2={q2:.4f}, Q3={q3:.4f}")
        print(f"区间0 (≤{q1:.4f}): {np.sum(quantized_H[t] == 0)}个元素")
        print(f"区间1 ({q1:.4f}~{q2:.4f}): {np.sum(quantized_H[t] == 1)}个元素")
        print(f"区间2 ({q2:.4f}~{q3:.4f}): {np.sum(quantized_H[t] == 2)}个元素")
        print(f"区间3 (>{q3:.4f}): {np.sum(quantized_H[t] == 3)}个元素")
        
        # 可视化当前时隙的量化结果
        visualize_quantization(current_slot_data, quantized_H[t], t+1, [q1, q2, q3])
        
    return quantized_H

def visualize_quantization(original_data, quantized_data, time_slot, thresholds):
    """
    可视化原始数据和量化后的结果
    
    参数:
        original_data: 原始数据
        quantized_data: 量化后的数据
        time_slot: 时隙编号
        thresholds: 量化阈值列表
    """
    plt.figure(figsize=(15, 6))
    
    # 原始数据分布
    plt.subplot(1, 3, 1)
    plt.hist(original_data.flatten(), bins=30, color='skyblue', edgecolor='black')
    plt.title(f'时隙 {time_slot} 原始数据分布')
    for i, threshold in enumerate(thresholds):
        plt.axvline(threshold, color='r', linestyle='--', label=f'Q{i+1}={threshold:.2f}')
    plt.legend()
    
    # 量化后数据分布
    plt.subplot(1, 3, 2)
    plt.hist(quantized_data.flatten(), bins=4, range=(-0.5, 3.5), color='lightgreen', edgecolor='black')
    plt.xticks([0, 1, 2, 3])
    plt.title(f'时隙 {time_slot} 量化后数据分布')
    
    # 热力图展示量化矩阵
    plt.subplot(1, 3, 3)
    plt.imshow(quantized_data, cmap='viridis', interpolation='nearest')
    plt.colorbar(ticks=[0, 1, 2, 3])
    plt.title(f'时隙 {time_slot} 量化后矩阵可视化')
    
    plt.tight_layout()
    plt.show()

# 示例用法
def test_adaptive_2bit_quantization():
    # 创建模拟数据
    np.random.seed(42)  # 设置随机种子以便结果可复现
    H_combined_pre = np.random.randn(2, 16, 16)  # 随机生成(2, 16, 16)形状的数据
    
    # 为第一个时隙添加偏置，使两个时隙的分布不同
    H_combined_pre[0] += 1.0
    
    print("原始信道估计数据统计:")
    for t in range(H_combined_pre.shape[0]):
        print(f"时隙 {t+1}: 最小值={H_combined_pre[t].min():.4f}, "
              f"最大值={H_combined_pre[t].max():.4f}, "
              f"平均值={H_combined_pre[t].mean():.4f}")
    
    # 应用2bit自适应量化
    print("\n开始2bit自适应量化...")
    quantized_H = adaptive_2bit_quantization(H_combined_pre)
    
    # 显示整体量化结果
    print("\n整体量化结果:")
    for t in range(quantized_H.shape[0]):
        counts = np.bincount(quantized_H[t].flatten(), minlength=4)
        print(f"时隙 {t+1}: 0的数量={counts[0]}, 1的数量={counts[1]}, "
              f"2的数量={counts[2]}, 3的数量={counts[3]}")
    
    # 展示量化后的比特表示
    print("\n量化后的2bit表示:")
    for t in range(quantized_H.shape[0]):
        print(f"\n时隙 {t+1}:")
        bit_repr = np.zeros((quantized_H.shape[1], quantized_H.shape[2]*2), dtype=np.int8)
        for i in range(quantized_H.shape[1]):
            for j in range(quantized_H.shape[2]):
                # 将0,1,2,3转换为00,01,10,11
                bit_repr[i, j*2] = (quantized_H[t, i, j] >> 1) & 1
                bit_repr[i, j*2+1] = quantized_H[t, i, j] & 1
        
        # 打印比特表示（以紧凑的方式）
        for row in bit_repr:
            print(''.join(map(str, row)))
    
    return quantized_H

# 执行测试
if __name__ == "__main__":
    quantized_result = test_adaptive_2bit_quantization()