import torch
import torch.nn as nn
import random
import gym
from gym import spaces
import numpy as np
from tqdm import tqdm
import torch.nn.functional as F
from torch.distributions import Normal
import matplotlib.pyplot as plt
import sys
import os
from RIS_Pro import *
from Data_Pro import *

class RISEnv(gym.Env):
    def __init__(self,
                 H_BS2RIS_train,
                 H_RIS2UE_train,
                 num_time_slots,
                 num_RIS,
                 bits=1,
                 snr_db=25,
                 max_episode_steps=10,
                 power_weight=0.1,
                 complexity_weight=0.3,
                 device='cuda:1' if torch.cuda.is_available() else 'cpu',
                 use_cnn=False,
                 reward_window=5
                 ):
        super(RISEnv, self).__init__()
        
        # 基本参数初始化
        self.H_BS2RIS_train = H_BS2RIS_train
        self.H_RIS2UE_train = H_RIS2UE_train
        self.bits = bits
        self.snr_db = snr_db
        self.max_episode_steps = max_episode_steps
        self.num_time_slots = num_time_slots
        self.num_RIS = num_RIS
        self.device = device
        self.num_tx = H_BS2RIS_train.shape[-2]
        self.num_rx = H_RIS2UE_train.shape[-1]
        
        # 奖励窗口设置
        self.reward_window = reward_window
        self.reward_history = []
        
        # 定义动作空间 - 直接使用完整的RIScode作为动作
        # 每个元素的取值范围是[0, 2^bits - 1]
        self.action_space = spaces.MultiDiscrete([2**bits] * (num_time_slots * num_RIS))
        
        # 设置观测空间
        self.use_cnn = use_cnn
        if use_cnn:
            # CNN观测空间：(2, num_time_slots*num_tx, num_rx)
            self.observation_space = spaces.Box(
                low=-np.inf,
                high=np.inf,
                shape=(2, self.num_time_slots*self.num_tx, self.num_rx),
                dtype=np.float32
            )
        else:
            # 扁平化观测空间
            self.obs_dim = self.num_time_slots*2*self.num_tx*self.num_rx
            self.observation_space = spaces.Box(
                low=-np.inf,
                high=np.inf,
                shape=(self.obs_dim,),
                dtype=np.float32
            )
        
        # 环境内部状态
        self.current_step = 0
        self.RIScode = None
        self.state = None
        self.power_weight = power_weight
        self.complexity_weight = complexity_weight

    def reset(self):
        self.current_step = 0
        self.reward_history = []  # 清空奖励历史
        self.RIScode = generate_RIScode(self.num_RIS, self.num_time_slots, self.bits, resetRIS=1)
        self.state = self._compute_state(self.RIScode)
        return self.state
    
    def step(self, action):
        """
        执行一步环境交互，使用完整的RIScode作为动作
        
        参数:
        action: 长度为(num_time_slots * num_RIS)的一维数组，表示完整的RIScode
               每个元素的取值范围是[0, 2^bits - 1]
        
        返回:
        state: 新的状态
        reward: 奖励值（使用窗口平均）
        done: 是否结束
        info: 附加信息
        """
        self.current_step += 1
        
        # 将一维动作转换为二维RIScode矩阵
        self.RIScode = self._action_to_riscode(action)
        
        # 计算组合信道并确定奖励
        H_combined_train = self._compute_H_combined(self.RIScode)
        
        reward_entropy = self._compute_conditional_entropy(H_combined_train)
        print('entropy:', reward_entropy)
        # 计算MSE奖励
        reward_mse = compute_reward_mse(H_combined_train)
        
        # 计算功率奖励
        total_power, avg_power = calculate_mimo_power(H_combined_train, use_db=False)
        
        # 计算RIScode复杂度奖励
        complexity_reward = self._compute_RIScode_reward(self.RIScode)
        
        # 组合奖励
        current_reward = (reward_mse + self.power_weight*np.mean(avg_power) + 
                     self.complexity_weight*complexity_reward)/10
        
        # 将当前奖励添加到历史记录
        self.reward_history.append(current_reward)
        
        # 计算平均奖励（使用窗口）
        if len(self.reward_history) > self.reward_window:
            window_rewards = self.reward_history[-self.reward_window:]
        else:
            window_rewards = self.reward_history
        
        avg_reward = np.mean(window_rewards)
        
        # 计算新状态
        self.state = self._compute_state(self.RIScode)
        
        # 判断是否结束
        done = (self.current_step >= self.max_episode_steps) or \
               (np.all(self.RIScode == 0))
        
        info = {
            'current_step': self.current_step,
            'RIScode': self.RIScode.copy(),
            'current_reward': current_reward,
            'reward_history': self.reward_history.copy(),
            'window_size': len(window_rewards),
            'avg_power': np.mean(avg_power),
            'reward_mse': reward_mse
        }
        
        return self.state, avg_reward, done, info
    
    def _action_to_riscode(self, action):
        """
        将一维动作数组转换为二维RIScode矩阵
        
        参数:
            action: 一维数组，长度为num_time_slots * num_RIS
            
        返回:
            riscode: 二维矩阵，形状为(num_time_slots, num_RIS)
        """
        # 确保动作在有效范围内
        action = np.clip(action, 0, 2**self.bits - 1)
        
        # 将一维数组重塑为二维矩阵
        riscode = action.reshape(self.num_time_slots, self.num_RIS)
        
        return riscode
        
    def _compute_H_combined(self, code):
        """计算组合信道矩阵"""
        Phi = map_RIScode_to_Phi(code, self.bits)
        H_combined_train = multiple_RIS(self.H_BS2RIS_train, Phi, self.H_RIS2UE_train)
        return H_combined_train
    
    def _compute_state(self, code):
        """计算状态"""
        Hc_train = self._compute_H_combined(code)
        if self.use_cnn:
            # 将复数数据转换为两通道（实部和虚部）的实数数据  
            # 得到 shape: (2, num_time_slots, num_tx, num_rx)
            Hc_train_real = C2R(Hc_train)
            image = Hc_train_real.reshape(2, self.num_time_slots*self.num_tx, self.num_rx)
            state = image    
            
        else:
            # 直接使用RIScode作为状态
            state = code.flatten()
            
        return state.astype(np.float32)
        
    def _compute_RIScode_reward(self, riscode):
        """
        计算RIScode的复杂度奖励，重点关注时隙内/间差异性和随机性
        
        参数:
            riscode: 形状为(num_time_slots, num_RIS)的矩阵，
                    值范围为0到2^bits-1
        
        返回:
            complexity_reward: 复杂度奖励，范围0~20
        """
        # 获取矩阵维度
        num_time_slots, num_RIS = riscode.shape
        max_value = (2**self.bits) - 1
        
        # ==========================================
        # 1. 整体熵计算
        # ==========================================
        # 计算每个可能值的概率分布
        hist = np.zeros(max_value + 1)
        for i in range(max_value + 1):
            hist[i] = np.count_nonzero(riscode == i)
        prob = hist / riscode.size
        
        # 计算熵
        entropy = 0
        for p in prob:
            if p > 0:
                entropy -= p * np.log2(p)
        
        # 归一化熵（除以最大可能熵）
        max_entropy = np.log2(max_value + 1)
        normalized_entropy = entropy / max_entropy if max_entropy > 0 else 0
        
        # ==========================================
        # 2. 时隙间汉明距离
        # ==========================================
        avg_hamming_distance = 0
        if num_time_slots > 1:
            total_hamming = 0
            comparisons = 0
            for i in range(num_time_slots - 1):
                for j in range(i + 1, num_time_slots):
                    # 计算两个时隙之间的汉明距离（不同元素的比例）
                    hamming = np.count_nonzero(riscode[i] != riscode[j]) / num_RIS
                    total_hamming += hamming
                    comparisons += 1
            
            if comparisons > 0:
                avg_hamming_distance = total_hamming / comparisons
        
        # ==========================================
        # 3. 时隙内连续值惩罚
        # ==========================================
        # 初始化连续值惩罚计数器
        consecutive_penalty = 0
        
        # 对每个时隙检查连续相同值
        for t in range(num_time_slots):
            # 对于每个RIS单元（除了最后两个，因为我们要检查连续3个）
            for i in range(num_RIS - 2):
                # 如果连续3个值相同，增加惩罚
                if (riscode[t, i] == riscode[t, i+1] == riscode[t, i+2]):
                    consecutive_penalty += 1
        
        # 归一化连续值惩罚
        max_possible_penalties = num_time_slots * (num_RIS - 2)
        if max_possible_penalties > 0:
            normalized_consecutive_penalty = consecutive_penalty / max_possible_penalties
        else:
            normalized_consecutive_penalty = 0
        
        # ==========================================
        # 4. 计算总奖励
        # ==========================================
        # 权重设置
        entropy_weight = 12.0       # 熵的权重
        hamming_weight = 10.0       # 汉明距离的权重
        consecutive_penalty_weight = 5.0  # 连续值惩罚的权重
        
        # 计算各部分得分
        entropy_score = entropy_weight * normalized_entropy
        hamming_score = hamming_weight * avg_hamming_distance
        penalty_score = consecutive_penalty_weight * normalized_consecutive_penalty
        
        # 合并得分，并确保在0~20范围内
        reward = entropy_score + hamming_score - penalty_score
        reward = max(0, min(20, reward))
        
        return reward
    
    
    def _compute_conditional_entropy(self,H_combined):
        """
        计算信道条件熵度量，评估不同时隙信道的可预测性
        
        参数:
            H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
            
        返回:
            归一化的条件熵得分（较高值表示时隙间差异大）
        """
        num_time_slots = H_combined.shape[0]
        if num_time_slots <= 1:
            return 0
        
        # 将信道矩阵向量化
        H_vectors = []
        for t in range(num_time_slots):
            # 提取实部和虚部，并标准化
            h_real = np.real(H_combined[t]).flatten()
            h_imag = np.imag(H_combined[t]).flatten()
            h_vec = np.concatenate([h_real, h_imag])
            
            # 简单标准化
            if np.std(h_vec) > 0:
                h_vec = (h_vec - np.mean(h_vec)) / np.std(h_vec)
            
            H_vectors.append(h_vec)
        
        # 计算条件统计量
        total_unpredictability = 0
        for i in range(1, num_time_slots):
            # 计算当前向量与前一向量的相关性
            prev_vec = H_vectors[i-1]
            curr_vec = H_vectors[i]
            
            # 使用相关系数的补来估计条件熵
            corr = np.corrcoef(prev_vec, curr_vec)[0, 1]
            # 避免数值问题
            corr = np.clip(corr, -0.9999, 0.9999)
            
            # 低相关性 = 高不可预测性 = 高条件熵
            unpredictability = 1.0 - abs(corr)
            total_unpredictability += unpredictability
        
        avg_unpredictability = total_unpredictability / (num_time_slots - 1)
        
        return avg_unpredictability * 10  # 缩放到0-10范围   
             
class RISParams:
    """RIS环境的参数管理类"""
    def __init__(self):
        self.num_ris = 9           # RIS单元数量
        self.num_time_slots = 2    # 时隙数量
        self.bits = 1              # 量化位数
        self.snr = 25              # 信噪比(dB)
        self.seed = 42             # 随机种子
        self.max_episode_steps = 10  # 每个Episode的最大步数
        self.power_weight = 0.1     # 功率奖励权重   



    
if __name__ == '__main__':    
    import hdf5storage
    
    os.chdir('/new_disk/ting/RL/Mycode_2')  # 修改工作路径

    file_path_BS2RIS='../MyData/H_BS2RIS_3*3RIS_2*2_2*2_MIMO.mat'
    file_path_RIS2UE='../MyData/H_RIS2UE_3*3RIS_2*2_2*2_MIMO.mat'
    H_BS2RIS=hdf5storage.loadmat(file_path_BS2RIS)['H_BS2RIS']
    H_RIS2UE=hdf5storage.loadmat(file_path_RIS2UE)['H_RIS2UE']
    print(H_BS2RIS.shape,H_RIS2UE.shape)
    
    RISParams=RISParams()
    SNR=RISParams.snr
    num_RIS=RISParams.num_ris
    num_time_slots = RISParams.num_time_slots   # 时隙数量
    bits = RISParams.bits             # 量化位数
    seed = RISParams.seed
    max_episode_steps=3
    
    # 数据预处理
    H_BS2RIS = whitening(add_noise(H_BS2RIS, SNR))
    H_RIS2UE = whitening(add_noise(H_RIS2UE, SNR))
    print(H_BS2RIS.shape,H_RIS2UE.shape)
    H_BS2RIS_train=H_BS2RIS[0,0,0:2,0,:,:]  # 6D->3D，保留时间的以及空间的维度,上下行2个时隙，发射天线数*接收天线数
    H_RIS2UE_train=H_RIS2UE[0,0,0:2,0,:,:]
    print(H_BS2RIS_train.shape,H_RIS2UE_train.shape)
    
    # 创建环境
    env = RISEnv(
                H_BS2RIS_train=H_BS2RIS_train,
                H_RIS2UE_train=H_RIS2UE_train,
                num_time_slots=num_time_slots,
                num_RIS=num_RIS,
                bits=bits,  
                max_episode_steps=max_episode_steps,
                use_cnn=True, 
            )

    # 测试环境
    state = env.reset()
    print("初始状态形状:", state.shape)
    print("初始RIScode:\n", env.RIScode)
    
    for ep in range(3):
        print(f"\n测试 Episode {ep+1}")
        state = env.reset()
        
        for step in range(2):
            # 创建随机动作 - 直接指定完整的RIScode
            # 为每个元素随机生成[0, 2^bits - 1]范围内的值
            action = np.random.randint(0, 2**bits, size=num_time_slots * num_RIS)
            
            print(f"步骤 {step+1} 动作:\n", action.reshape(num_time_slots, num_RIS))
            
            next_state, reward, done, info = env.step(action)
            
            print(f"更新后的RIScode:\n{info['RIScode']}")
            print(f"奖励: {reward:.3f}, 当前奖励: {info['current_reward']:.3f}")
            print(f"完成: {done}")
            print(f"MSE奖励: {info['reward_mse']:.3f}, 平均功率: {info['avg_power']:.3f}")
            print('-' * 50)
            
            if done:
                break