import numpy as np

def compute_reward_mse(H_combined):
    """
    计算基于MSE的信道差异奖励，信道完全一致时奖励为0
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        
    返回:
        归一化的MSE奖励得分，范围0-10，完全相同为0
    """
    num_time_slots = H_combined.shape[0]
    if num_time_slots <= 1:
        return 0
    
    total_mse = 0
    comparisons = 0
    
    for i in range(num_time_slots - 1):
        for j in range(i + 1, num_time_slots):
            diff = H_combined[i] - H_combined[j]
            mse = np.mean(np.abs(diff) ** 2)
            total_mse += mse
            comparisons += 1
    
    avg_mse = total_mse / comparisons if comparisons > 0 else 0
    
    # 归一化MSE值，相同信道MSE为0
    # 避免数值误差导致的微小非零值
    if avg_mse < 1e-10:
        return 0
    
  #  normalized_mse = min(avg_mse / 10.0, 1.0)
    
    return avg_mse/(H_combined.shape[-1]*H_combined.shape[-2])  # 缩放到0-10范围

def compute_reward_norm(H_combined, epsilon=1e-10):
    """
    使用矩阵范数计算时隙间的信道差异奖励，信道完全一致时奖励为0
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        epsilon: 小值阈值，低于此值视为0
        
    返回:
        归一化的平均信道距离得分，范围0-10，完全相同为0
    """
    num_time_slots = H_combined.shape[0]
    if num_time_slots <= 1:
        return 0
    
    total_distance = 0
    comparisons = 0
    
    for i in range(num_time_slots - 1):
        for j in range(i + 1, num_time_slots):
            # 计算Frobenius范数（矩阵元素平方和的平方根）
            diff_matrix = H_combined[i] - H_combined[j]
            frob_norm = np.linalg.norm(diff_matrix, 'fro')
            
            # 归一化（除以矩阵规模）
            normalized_norm = frob_norm / (np.sqrt(diff_matrix.shape[0] * diff_matrix.shape[1]))
            total_distance += normalized_norm
            comparisons += 1
    
    # 返回平均距离
    avg_distance = total_distance / comparisons if comparisons > 0 else 0
    
    # 处理几乎相同的情况
    if avg_distance < epsilon:
        return 0
    
    # 将距离变换为奖励（距离越大，奖励越高）
    # 假设理想距离在0.5-2之间，进行归一化
    distance_score = min(avg_distance / 2.0, 1.0)
    
    return distance_score * 10  # 缩放到0-10范围

def compute_reward_chordal(H_combined, epsilon=1e-8):
    """
    计算信道矩阵之间的角度距离奖励，捕捉空间方向变化，信道完全一致时奖励为0
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        epsilon: 小值阈值，低于此值视为0
        
    返回:
        归一化的角度距离得分，范围0-10，完全相同为0
    """
    num_time_slots = H_combined.shape[0]
    if num_time_slots <= 1:
        return 0
    
    total_chordal_distance = 0
    comparisons = 0
    
    for i in range(num_time_slots - 1):
        for j in range(i + 1, num_time_slots):
            # 计算奇异值分解
            U_i, S_i, Vh_i = np.linalg.svd(H_combined[i], full_matrices=False)
            U_j, S_j, Vh_j = np.linalg.svd(H_combined[j], full_matrices=False)
            
            # 计算主导左奇异向量之间的角度距离
            r = min(U_i.shape[1], U_j.shape[1])
            chordal_dist = 0
            for k in range(r):
                cos_angle = np.abs(np.dot(U_i[:, k].conj(), U_j[:, k]))
                cos_angle = min(cos_angle, 1.0)  # 确保数值稳定性
                chordal_dist += np.sqrt(1 - cos_angle**2)
            
            # 归一化
            chordal_dist /= r
            total_chordal_distance += chordal_dist
            comparisons += 1
    
    avg_chordal_distance = total_chordal_distance / comparisons if comparisons > 0 else 0
    
    # 处理几乎相同的情况
    if avg_chordal_distance < epsilon:
        return 0
    
    # 将角度距离变换为奖励（距离越大，奖励越高）
    #distance_score = min(avg_chordal_distance / 0.8, 1.0)
    
    return avg_chordal_distance * 10  # 缩放到0-10范围

def compute_reward_mutual_information(H_combined, snr_linear=10, epsilon=1e-4):
    """
    计算基于互信息的信道差异奖励，信道完全一致时奖励为0
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        snr_linear: 线性SNR值（非dB）
        epsilon: 小值阈值，低于此值视为0
        
    返回:
        归一化的互信息差异得分，范围0-10，完全相同为0
    """
    num_time_slots = H_combined.shape[0]
    if num_time_slots <= 1:
        return 0
    
    # 计算每个时隙的信道容量/互信息
    capacities = []
    for t in range(num_time_slots):
        H = H_combined[t]
        # 计算HH†
        HH_dag = np.matmul(H, H.conj().T)
        
        # 计算特征值
        eigenvalues = np.linalg.eigvalsh(HH_dag)
        eigenvalues = np.maximum(eigenvalues, 1e-10)  # 避免数值问题
        
        # 计算容量 log(det(I + SNR/Nt * HH†))
        n_tx = H.shape[0]
        capacity = np.sum(np.log2(1 + snr_linear / n_tx * eigenvalues))
        capacities.append(capacity)
    
    # 计算容量/互信息的变化
    total_diff = 0
    comparisons = 0
    for i in range(num_time_slots - 1):
        for j in range(i + 1, num_time_slots):
            diff = abs(capacities[i] - capacities[j])
            total_diff += diff
            comparisons += 1
    
    avg_diff = total_diff / comparisons if comparisons > 0 else 0
    
    # 处理几乎相同的情况
    if avg_diff < epsilon:
        return 0
    
    # 归一化(通常MIMO容量在5-25 bits/s/Hz范围内，具体视天线数量和SNR而定)
    max_expected_diff = 10.0  # 根据系统参数调整
    diff_score = min(avg_diff / max_expected_diff, 1.0)
    
    return diff_score * 10  # 缩放到0-10范围

def compute_reward_conditional_entropy(H_combined, epsilon=1e-4):
    """
    计算信道条件熵度量奖励，评估不同时隙信道的可预测性，信道完全一致时奖励为0
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        epsilon: 小值阈值，低于此值视为0
        
    返回:
        归一化的条件熵得分（较高值表示时隙间差异大），范围0-10，完全相同为0
    """
    num_time_slots = H_combined.shape[0]
    if num_time_slots <= 1:
        return 0
    
    # 将信道矩阵向量化
    H_vectors = []
    for t in range(num_time_slots):
        # 提取实部和虚部，并标准化
        h_real = np.real(H_combined[t]).flatten()
        h_imag = np.imag(H_combined[t]).flatten()
        h_vec = np.concatenate([h_real, h_imag])
        
        # 简单标准化
        if np.std(h_vec) > 0:
            h_vec = (h_vec - np.mean(h_vec)) / np.std(h_vec)
        
        H_vectors.append(h_vec)
    
    # 计算条件统计量
    total_unpredictability = 0
    for i in range(1, num_time_slots):
        for j in range(i):
            # 计算向量之间的相关性
            vec_i = H_vectors[i]
            vec_j = H_vectors[j]
            
            # 使用相关系数的补来估计条件熵
            corr = np.corrcoef(vec_i, vec_j)[0, 1]
            # 避免数值问题
            corr = np.clip(corr, -0.9999, 0.9999)
            
            # 低相关性 = 高不可预测性 = 高条件熵
            unpredictability = 1.0 - abs(corr)
            total_unpredictability += unpredictability
    
    # 相关系数为1意味着完全可预测(相同)
    comparisons = num_time_slots * (num_time_slots - 1) // 2
    avg_unpredictability = total_unpredictability / comparisons if comparisons > 0 else 0
    
    # 处理几乎相同的情况
    if avg_unpredictability < epsilon:
        return 0
    
    return avg_unpredictability * 10  # 缩放到0-10范围

def compute_reward_rank(H_combined, threshold=0.01, epsilon=1e-6):#!这个是真不行
    """
    计算信道矩阵有效秩差异奖励，信道完全一致时奖励为0
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        threshold: 确定有效秩的奇异值阈值
        epsilon: 小值阈值，低于此值视为0
        
    返回:
        归一化的秩差异得分，范围0-10，完全相同为0
    """
    num_time_slots = H_combined.shape[0]
    if num_time_slots <= 1:
        return 0
    
    # 计算每个时隙信道的有效秩
    effective_ranks = []
    for t in range(num_time_slots):
        # 计算奇异值
        s = np.linalg.svd(H_combined[t], compute_uv=False)
        max_s = np.max(s)
        
        # 计算有效秩（大于阈值的奇异值数量）
        er = np.sum(s > threshold * max_s)
        effective_ranks.append(er)
    
    # 计算秩差异
    total_rank_diff = 0
    comparisons = 0
    for i in range(num_time_slots - 1):
        for j in range(i + 1, num_time_slots):
            diff = abs(effective_ranks[i] - effective_ranks[j])
            total_rank_diff += diff
            comparisons += 1
    
    avg_rank_diff = total_rank_diff / comparisons if comparisons > 0 else 0
    
    # 完全相同的信道将具有相同的有效秩
    if avg_rank_diff < epsilon:
        return 0
    
    # 归一化（除以最大可能秩，通常是min(num_tx, num_rx)）
    max_possible_rank = min(H_combined.shape[1], H_combined.shape[2])
    diff_score = min(avg_rank_diff / max_possible_rank, 1.0)
    
    return avg_rank_diff / max_possible_rank * 10  # 缩放到0-10范围

def compute_reward_condition_number(H_combined, epsilon=1e-4):
    """
    计算信道矩阵条件数差异奖励，信道完全一致时奖励为0
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        epsilon: 小值阈值，低于此值视为0
        
    返回:
        归一化的条件数差异得分，范围0-10，完全相同为0
    """
    num_time_slots = H_combined.shape[0]
    if num_time_slots <= 1:
        return 0
    
    # 计算每个时隙信道的条件数
    condition_numbers = []
    for t in range(num_time_slots):
        # 计算奇异值
        s = np.linalg.svd(H_combined[t], compute_uv=False)
        
        # 计算条件数 (最大奇异值/最小奇异值)
        # 避免除零问题
        min_s = max(np.min(s), 1e-10)
        max_s = max(np.max(s), 1e-10)
        cond = max_s / min_s
        
        # 对条件数取对数，使分布更均匀
        log_cond = np.log10(cond)
        condition_numbers.append(log_cond)
    
    # 计算条件数差异
    total_cond_diff = 0
    comparisons = 0
    for i in range(num_time_slots - 1):
        for j in range(i + 1, num_time_slots):
            diff = abs(condition_numbers[i] - condition_numbers[j])
            total_cond_diff += diff
            comparisons += 1
    
    avg_cond_diff = total_cond_diff / comparisons if comparisons > 0 else 0
    
    # 相同的信道将有相同的条件数
    if avg_cond_diff < epsilon:
        return 0
    
    # 归一化（通常log10(条件数)在0-6之间）
    max_expected_diff = 3.0  # 根据系统参数调整
    diff_score = min(avg_cond_diff / max_expected_diff, 1.0)
    
    return avg_cond_diff / max_expected_diff  # 缩放到0-10范围

def compute_reward_comprehensive(H_combined, snr_db=25):
    """
    综合多种度量方法评估信道差异奖励，信道完全一致时奖励为0
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        snr_db: 信噪比（dB）
        
    返回:
        综合归一化的信道差异得分，范围0-10，完全相同为0
    """
    # 转换dB到线性SNR
    snr_linear = 10**(snr_db/10)
    
    # 1. 矩阵范数差异
    norm_diff = compute_reward_norm(H_combined)
    
    # 2. 角度距离
    angle_diff = compute_reward_chordal(H_combined)
    
    # 3. 互信息差异
    mi_diff = compute_reward_mutual_information(H_combined, snr_linear)
    
    # 4. 秩差异
    rank_diff = compute_reward_rank(H_combined)
    
    # 5. 条件数差异
    cond_diff = compute_reward_condition_number(H_combined)
    
    # 综合评分（根据应用场景调整权重）
    weights = {
        'norm': 0.2,
        'angle': 0.25,
        'mi': 0.25,
        'rank': 0.15,
        'cond': 0.15
    }
    
    comprehensive_score = (
        weights['norm'] * norm_diff +
        weights['angle'] * angle_diff +
        weights['mi'] * mi_diff +
        weights['rank'] * rank_diff +
        weights['cond'] * cond_diff
    )
    
    # 如果所有度量都接近于0，那么总分也应该为0
    if comprehensive_score < 1e-6:
        return 0
    
    return comprehensive_score

def compute_reward_security(H_combined, snr_db=25, epsilon=1e-6):
    """
    为安全通信特别优化的信道差异奖励，信道完全一致时奖励为0
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        snr_db: 信噪比（dB）
        epsilon: 小值阈值，低于此值视为0
        
    返回:
        加权组合的信道差异安全得分，范围0-10，完全相同为0
    """
    # 转换dB到线性SNR
    snr_linear = 10**(snr_db/10)
    
    # 1. 角度距离（主要度量）
    angle_diff = compute_reward_chordal(H_combined)
    
    # 2. 互信息差异
    mi_diff = compute_reward_mutual_information(H_combined, snr_linear)
    
    # 3. 条件数差异
    cond_diff = compute_reward_condition_number(H_combined)
    
    # 安全通信优化的权重分配
    weights = {
        'angle': 0.3,    # 角度距离权重最高
        'mi': 0.6,       # 互信息次之
        'cond': 0.1      # 条件数辅助
    }
    
    security_score = (
        weights['angle'] * angle_diff +
        weights['mi'] * mi_diff +
        weights['cond'] * cond_diff
    )
    
    # 如果得分非常小，视为完全相同的信道，返回0
    if security_score < epsilon:
        return 0
    
    return security_score

# 显式检查信道是否相同的辅助函数
def is_channel_identical(H_combined, threshold=1e-6):
    """
    检查给定的信道矩阵在不同时隙是否几乎相同
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        threshold: 相似性阈值
        
    返回:
        如果所有信道几乎相同则返回True，否则返回False
    """
    num_time_slots = H_combined.shape[0]
    if num_time_slots <= 1:
        return True
    
    # 计算第一个时隙与其他所有时隙的差异
    for i in range(1, num_time_slots):
        diff = np.max(np.abs(H_combined[0] - H_combined[i]))
        if diff > threshold:
            return False
    
    return True

# 用于测试的函数
def test_rewards(H_combined, snr_db=25):
    """
    测试所有奖励计算函数并展示结果
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        snr_db: 信噪比（dB）
    
    返回:
        所有奖励函数的结果字典
    """
    results = {}
    
    # 检查信道是否相同
    identical = is_channel_identical(H_combined)
    results['identical_channels'] = identical
    
    # 基本MSE
    results['mse'] = compute_reward_mse(H_combined)
    
    # 矩阵范数
    results['norm'] = compute_reward_norm(H_combined)
    
    # 角度距离
    results['chordal'] = compute_reward_chordal(H_combined)
    
    # 互信息差异
    results['mutual_info'] = compute_reward_mutual_information(H_combined, 10**(snr_db/10))
    
    # 条件熵
    results['cond_entropy'] = compute_reward_conditional_entropy(H_combined)
    
    # 秩差异
    results['rank'] = compute_reward_rank(H_combined)
    
    # 条件数差异
    results['condition'] = compute_reward_condition_number(H_combined)
    
    # 综合评分
    results['comprehensive'] = compute_reward_comprehensive(H_combined, snr_db)
    
    # 安全通信优化评分
    results['security'] = compute_reward_security(H_combined, snr_db)
    
    return results

if __name__ == "__main__":
    # 生成测试数据
    np.random.seed(42)  # 固定随机种子以便复现
    
    # 创建两个时隙的随机信道矩阵
    num_time_slots = 2
    num_tx = 4
    num_rx = 4
    
    # 测试场景1: 完全相同的信道
    H1_identical = np.random.randn(1, num_tx, num_rx) + 1j*np.random.randn(1, num_tx, num_rx)
    H1_identical = np.repeat(H1_identical, num_time_slots, axis=0)
    
    # 测试场景2: 稍微不同的信道
    H2_slight_diff = np.random.randn(1, num_tx, num_rx) + 1j*np.random.randn(1, num_tx, num_rx)
    H2_slight_diff = np.repeat(H2_slight_diff, num_time_slots, axis=0)
    # 添加非常小的扰动
    H2_slight_diff[1] += 0.01 * (np.random.randn(num_tx, num_rx) + 1j*np.random.randn(num_tx, num_rx))
    
    # 测试场景3: 相似信道
    H3_similar = np.random.randn(num_time_slots, num_tx, num_rx) + 1j*np.random.randn(num_time_slots, num_tx, num_rx)
    H3_similar[1] = H3_similar[0] + 0.1 * (np.random.randn(num_tx, num_rx) + 1j*np.random.randn(num_tx, num_rx))
    
    # 测试场景4: 正交信道
    H4_orthogonal = np.random.randn(num_time_slots, num_tx, num_rx) + 1j*np.random.randn(num_time_slots, num_tx, num_rx)
    # 对第二个时隙使用近似正交的信道
    U, _, Vh = np.linalg.svd(H4_orthogonal[0], full_matrices=False)
    # 旋转奇异向量
    U_rotated = np.zeros_like(U, dtype=complex)
    for i in range(min(num_tx, num_rx)):
        angle = np.pi/2  # 90度旋转
        U_rotated[:, i] = U[:, i] * np.exp(1j * angle)
    H4_orthogonal[1] = U_rotated @ np.diag(np.linalg.svd(H4_orthogonal[0], compute_uv=False)) @ Vh
    
    # 运行测试
    print("========== 场景1: 完全相同的信道 ==========")
    results1 = test_rewards(H1_identical)
    for metric, value in results1.items():
        if isinstance(value, bool):
            print(f"{metric}: {value}")
        else:
            print(f"{metric}: {value:.4f}")
        
    print("\n========== 场景2: 稍微不同的信道 ==========")
    results2 = test_rewards(H2_slight_diff)
    for metric, value in results2.items():
        if isinstance(value, bool):
            print(f"{metric}: {value}")
        else:
            print(f"{metric}: {value:.4f}")
        
    print("\n========== 场景3: 相似信道 ==========")
    results3 = test_rewards(H3_similar)
    for metric, value in results3.items():
        if isinstance(value, bool):
            print(f"{metric}: {value}")
        else:
            print(f"{metric}: {value:.4f}")
        
    print("\n========== 场景4: 正交信道 ==========")
    results4 = test_rewards(H4_orthogonal)
    for metric, value in results4.items():
        if isinstance(value, bool):
            print(f"{metric}: {value}")
        else:
            print(f"{metric}: {value:.4f}")