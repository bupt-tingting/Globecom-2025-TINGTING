# 基础库
import torch
import torch.utils.data as data
import torch.nn.functional as F
from torch.distributions import Normal
import numpy as np
from numpy import random
import random
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

# 数据处理和分析
from sklearn.metrics import mutual_info_score
import hdf5storage
from einops import rearrange
import os

# 环境和训练
import gym
from gym import spaces
from tqdm import tqdm

from Data_Pro import *

# 可视化
import matplotlib.pyplot as plt


def generate_RIScode(num_RIS, num_time_slots, bits,full_radom=True,zeros_ratio=0.5, seed=None, resetRIS=0):
    # Generate a random RIS code matrix with shape (num_time_slots, num_RIS)
    if seed is not None:
        np.random.seed(seed)  
    num_levels = 2 ** bits  
    if resetRIS == 1:
        # Set all RIS codes to 0
        RIScode = np.zeros((num_time_slots, num_RIS), dtype=int)
    elif full_radom :
        # Generate random RIS codes
        RIScode = np.random.randint(0, num_levels, size=(num_time_slots, num_RIS))        
    else:
        # 按比例置零
        # 计算需要设置为0的元素数量
        total_elements = num_time_slots * num_RIS
        num_zeros = int(total_elements * zeros_ratio)
        
        # 首先生成1到num_levels-1的随机矩阵
        RIScode = np.random.randint(1, num_levels, size=total_elements)
        
        # 随机选择位置设置为0
        zero_indices = np.random.choice(total_elements, num_zeros, replace=False)
        RIScode[zero_indices] = 0
        
        # 重塑为所需形状
        RIScode = RIScode.reshape(num_time_slots, num_RIS)
    return RIScode

def create_phase_map(bits):
    # Create a phase map for a given number of bits
    num_levels = 2 ** bits
    phase_step = 360 / num_levels  # Changed from 2*pi to 360 degrees
    phase_map = phase_step * np.arange(num_levels)
    return phase_map

def d2r(angle_degrees):
    # Convert angle from degrees to radians
    angle_radians = (angle_degrees % 360) * (np.pi / 180.0)
    return angle_radians

def r2d(angle_radians): 
    # Convert angle from radians to degrees
    angle_degrees = (angle_radians % (2 * np.pi)) * (180.0 / np.pi)
    return angle_degrees


def map_RIScode_to_Phi(RIScode, bits):
    # Map RIScode to Phi,Phi.shape=(num_time_slots,num_RIS,num_RIS)
    phase_map = create_phase_map(bits)  # 量化值到相位的数组 
    num_time_slots, num_RIS = RIScode.shape  
    phases_matrix = d2r(phase_map[RIScode])  # Shape: (num_time_slots, num_RIS)
    phi_diag_matrix = np.exp(1j * phases_matrix)  # Shape: (num_time_slots, num_RIS)
    Phi = np.array([np.diag(phi_diag_matrix[t]) for t in range(num_time_slots)])   
    return clean_complex_data(Phi)

def map_Phi_to_RIScode(Phi, bits):
    #Map Phi matrix back to RIS code
    phi_diag_matrix = np.array([np.diag(Phi[t]) for t in range(Phi.shape[0])])  
    phases_matrix = np.angle(phi_diag_matrix)
    phases_degrees = r2d(phases_matrix)
    phase_map = create_phase_map(bits)
    RIScode = np.array([np.argmin(np.abs(phases_degrees[t].reshape(-1,1) - phase_map), axis=1) 
                       for t in range(phases_degrees.shape[0])])
    return RIScode

import numpy as np

import numpy as np

def update_RIScode(RIScode, Phi_add, bits, num_time_slots, num_RIS):
    """
    更新RIScode，对应位置加1个量化单位
    
    参数:
    RIScode: ndarray, 原始RIS码矩阵，形状为(num_time_slots, num_RIS)
    Phi_add: ndarray/list/tensor, 指示要更新的位置，形状为(num_time_slots * num_RIS)
    bits: int, 量化位数
    
    返回:
    RIScode_new: ndarray, 更新后的RIS码矩阵，形状为(num_time_slots, num_RIS)
    """
    # 如果输入是 PyTorch tensor，先转换到 CPU
    if hasattr(Phi_add, 'cpu'):
        Phi_add = Phi_add.cpu().numpy()
    if hasattr(RIScode, 'cpu'):
        RIScode = RIScode.cpu().numpy()
        
    if not isinstance(RIScode, np.ndarray):
        RIScode = np.array(RIScode, dtype=np.int32)
    if not isinstance(Phi_add, np.ndarray):
        Phi_add = np.array(Phi_add, dtype=np.int32)
        
    Phi_add = Phi_add.reshape(num_time_slots, num_RIS)
    RIScode_new = RIScode + Phi_add
    num_levels = 2 ** bits
    RIScode_new = np.remainder(RIScode_new, num_levels)
    RIScode_new = RIScode_new.astype(np.int32)  # 确保输出为整数类型
    return RIScode_new

def complex_pearson_correlation(x, y):
    """
    计算两个复数序列 x, y 的皮尔逊相关系数
    返回: 复相关系数
    """
    # 减去均值
    x_centered = x - np.mean(x)
    y_centered = y - np.mean(y)
    # 计算相关系数
    numerator = np.sum(x_centered * np.conj(y_centered))
    denominator = np.sqrt(np.sum(np.abs(x_centered)**2) * np.sum(np.abs(y_centered)**2))
    return numerator / denominator

def compute_reward_cor(x, y, alpha=0.5, theta_target=0.0):
    """
    根据复相关系数同时考虑幅度和相位设计综合 reward
    参数:
      x, y: 复数序列
      alpha: 幅度奖励的权重，取值在 [0,1]
      theta_target: 期望的相位差（单位: 弧度），例如选择 0 则相位达到 0 时奖励最高
    返回:
      综合 reward，当幅度和相位均无关（即 r 接近0）时，reward 最大为 1
    """
    # 计算复相关系数
    r_complex = complex_pearson_correlation(x, y)
    r_abs = np.abs(r_complex)
    # 幅度部分奖励：希望 |r| 越小越好
    amplitude_reward = 1 - r_abs

    # 相位部分奖励
    # np.angle 返回的角度范围为 (-pi, pi]
    r_phase = np.angle(r_complex)
    # 计算当前相位与目标相位之间的差
    phase_diff = np.abs(r_phase - theta_target)
    # 考虑周期性，将相位差限制在 [0, pi] 内
    phase_diff = np.minimum(phase_diff, np.pi - phase_diff)
    phase_reward = 1 - (phase_diff / np.pi)

    # 综合两部分奖励
    reward = alpha * amplitude_reward + (1 - alpha) * phase_reward

    return reward


def plot_and_save_returns(return_list, title,save=True, save_dir='./results', window_size=5, figsize=(10, 6)):
    """绘制训练回报曲线并保存"""
    # 创建保存目录
    os.makedirs(save_dir, exist_ok=True)
    
    # 计算滑动平均
    if window_size > 1:
        smoothed_returns = []
        for i in range(len(return_list)):
            start_idx = max(0, i - window_size + 1)
            smoothed_returns.append(np.mean(return_list[start_idx:i+1]))
    else:
        smoothed_returns = return_list
    
    plt.rcParams['font.family'] = 'serif' #*
    plt.rcParams['font.size'] = 20 #* 设置默认字体大小
    
    # 绘图
    plt.figure(figsize=figsize)
    # 设置线条颜色和粗细
    plt.plot(return_list, alpha=0.3, label='Raw Returns', 
             color='#1f77b4', linewidth=2.0) #* 设置原始回报线为蓝色，线宽1.0
    plt.plot(smoothed_returns, label=f'Smoothed Returns \n(window={window_size})', 
             color='#ff7f0e', linewidth=3) #* 设置平滑回报线为橙色，线宽2.5
    
    plt.xlabel('Episodes', fontsize=20) #* 设置x轴标签字体大小
    plt.ylabel('Rewards', fontsize=20) #* 设置y轴标签字体大小
    if title != None:
        plt.title(title, fontsize=20) #* 设置标题字体大小
    plt.legend(fontsize=20) #* 设置图例字体大小
    plt.xticks(fontsize=18) #* 设置x轴刻度字体大小
    plt.yticks(fontsize=18) #* 设置y轴刻度字体大小
    plt.grid(True, alpha=0.3)
    
    # 控制边框线宽
    ax = plt.gca()
    for spine in ax.spines.values():
        spine.set_linewidth(0.5) #* 设置坐标轴边框线宽
    
    # 保存图片
    if save:
        save_path = os.path.join(save_dir, f"{title.replace(' ', '_')}.png")
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    # 显示图片
    plt.show()


def RIScode2D3D(RIScode, num_RISm=None, num_RISn=None, visualize=False):
    """
    将RIScode从2D转换为3D
    
    参数:
    RIScode: 形状为 (num_time_slots, num_RIS) 的二维数组
    num_RISm: 输出3D数组的第二维大小，默认为sqrt(num_RIS)
    num_RISn: 输出3D数组的第三维大小，默认为sqrt(num_RIS)
    visualize: 是否可视化输出结果
    
    返回:
    三维数组，形状为 (num_time_slots, num_RISm, num_RISn)
    """
    # 获取原始形状
    num_time_slots, num_RIS = RIScode.shape
    
    # 原始3D转换模式
    if num_RISm is None or num_RISn is None:
        sqrt_num_RIS = int(np.sqrt(num_RIS))
        if sqrt_num_RIS ** 2 != num_RIS:
            raise ValueError(f"num_RIS ({num_RIS}) 不是平方数，请指定 num_RISm 和 num_RISn")
        num_RISm = num_RISn = sqrt_num_RIS
    
    # 验证 num_RISm * num_RISn 是否等于 num_RIS
    if num_RISm * num_RISn != num_RIS:
        raise ValueError(f"num_RISm ({num_RISm}) * num_RISn ({num_RISn}) 必须等于 num_RIS ({num_RIS})")
    
    # 重塑数组为3D
    result = RIScode.reshape(num_time_slots, num_RISm, num_RISn)
    
    # 如果需要可视化输出
    if visualize:
        print("RIScode 3D:")
        print(visualize_3D_RIScode(result))
    
    return result
def visualize_3D_RIScode(matrix_3d):
    """
    左右并排显示3D矩阵中的每个时间槽
    
    参数:
    matrix_3d: 形状为 (num_time_slots, height, width) 的3D数组
    """
    if len(matrix_3d.shape) != 3:
        raise ValueError(f"输入应为3D数组，当前形状: {matrix_3d.shape}")
    
    num_time_slots, height, width = matrix_3d.shape
    
    # 生成每个时间槽的字符串表示
    slot_strings = []
    for t in range(num_time_slots):
        lines = []
        lines.append(f"slot {t}:")
        for row in matrix_3d[t]:
            lines.append(" ".join(str(x) for x in row))
        slot_strings.append("\n".join(lines))
    
    # 计算每个时间槽字符串的最大行数
    max_lines = max(s.count('\n') + 1 for s in slot_strings)
    
    # 将每个时间槽的字符串按行拆分
    slot_lines = [s.split('\n') for s in slot_strings]
    
    # 用空白行填充使所有时间槽有相同的行数
    for lines in slot_lines:
        while len(lines) < max_lines:
            lines.append("")
    
    # 计算每列的最大宽度（为了美观排版）
    col_widths = [max(len(line) for line in col_lines) for col_lines in slot_lines]
    
    # 逐行组合所有时间槽
    result_lines = []
    for i in range(max_lines):
        line_parts = []
        for slot_idx, lines in enumerate(slot_lines):
            # 右对齐到该列的最大宽度
            line_parts.append(lines[i].ljust(col_widths[slot_idx]))
        result_lines.append("    ".join(line_parts))
    
    return "\n".join(result_lines)
def RIScode3D2D(RIScode_3D):
    """
    将RIScode从3D转换回2D
    
    参数:
    RIScode_3D: 3D RIScode数组，形状为 (num_time_slots, num_RISm, num_RISn)
    
    返回:
    二维数组，形状为 (num_time_slots, num_RISm * num_RISn)
    """
    # 获取形状
    num_time_slots, num_RISm, num_RISn = RIScode_3D.shape
    num_RIS = num_RISm * num_RISn
    
    # 重塑数组为2D
    return RIScode_3D.reshape(num_time_slots, num_RIS)


def receiver_merging(H_combined, method='MRC'):
    """
    对MIMO信道矩阵进行接收端合并，将(num_time_slots, num_tx, num_rx)的矩阵
    转换为(num_time_slots, num_rx)的矩阵
    
    参数:
        H_combined: 形状为(num_time_slots, num_tx, num_rx)的复数矩阵
        method: 合并方法，支持以下选项:
                'MRC' - 最大比合并 (Maximum Ratio Combining)
                'EGC' - 等增益合并 (Equal Gain Combining)
                'SC' - 选择性合并 (Selection Combining)
                'MEAN' - 均值合并
                'SUM' - 求和合并
    
    返回:
        H_Re: 形状为(num_time_slots, num_rx)的复数矩阵
    """
    num_time_slots, num_tx, num_rx = H_combined.shape
    H_Re = np.zeros((num_time_slots, num_rx), dtype=complex)
    
    if method.upper() == 'MRC':
        # 最大比合并：每个接收天线的信号按信道增益加权合并
        for t in range(num_time_slots):
            for rx in range(num_rx):
                # 提取当前接收天线的所有发射路径
                h_rx = H_combined[t, :, rx]
                # 计算信道增益（功率）
                channel_gains = np.abs(h_rx) ** 2
                # 归一化增益作为权重
                if np.sum(channel_gains) > 0:
                    weights = channel_gains / np.sum(channel_gains)
                else:
                    weights = np.ones_like(channel_gains) / len(channel_gains)
                # 加权合并
                H_Re[t, rx] = np.sum(h_rx * weights)
    
    elif method.upper() == 'EGC':
        # 等增益合并：保持相位信息，但所有路径使用相同增益
        for t in range(num_time_slots):
            for rx in range(num_rx):
                h_rx = H_combined[t, :, rx]
                # 提取相位信息
                phases = np.angle(h_rx)
                # 所有路径使用单位增益，但保持原始相位
                H_Re[t, rx] = np.sum(np.exp(1j * phases)) / num_tx
    
    elif method.upper() == 'SC':
        # 选择性合并：为每个接收天线选择信号最强的发射路径
        for t in range(num_time_slots):
            for rx in range(num_rx):
                h_rx = H_combined[t, :, rx]
                # 选择信道增益最大的路径
                max_gain_idx = np.argmax(np.abs(h_rx))
                H_Re[t, rx] = h_rx[max_gain_idx]
    
    elif method.upper() == 'MEAN':
        # 均值合并：简单地取所有路径的平均值
        for t in range(num_time_slots):
            H_Re[t] = np.mean(H_combined[t], axis=0)
    
    elif method.upper() == 'SUM':
        # 求和合并：对所有路径求和
        for t in range(num_time_slots):
            H_Re[t] = np.sum(H_combined[t], axis=0)
    
    else:
        raise ValueError(f"不支持的合并方法：{method}。请使用 'MRC', 'EGC', 'SC', 'MEAN', 或 'SUM'。")
    
    return H_Re  

def H_Re2D3D(H_Re, num_UEm=None, num_UEn=None):
    """
    将2D接收信道矩阵H_Re转换为3D形式
    
    参数:
        H_Re: 形状为(num_time_slots, num_rx)的2D复数矩阵，其中num_rx = num_UEm * num_UEn
        num_UEm: 接收端阵列的第一维度大小
        num_UEn: 接收端阵列的第二维度大小
        
    返回:
        H_Re3D: 形状为(num_time_slots, num_UEm, num_UEn)的3D复数矩阵
    """
    num_time_slots, num_rx = H_Re.shape
    
    # 如果未提供num_UEm和num_UEn，假设接收阵列是正方形
    if num_UEm is None or num_UEn is None:
        # 计算接近num_rx平方根的整数
        dim = int(np.sqrt(num_rx))
        
        # 检查是否可以整除
        if dim * dim != num_rx:
            # 寻找最接近的因数对
            factors = []
            for i in range(1, int(np.sqrt(num_rx)) + 1):
                if num_rx % i == 0:
                    factors.append((i, num_rx // i))
            
            # 选择最接近正方形的因数对
            min_diff = float('inf')
            for m, n in factors:
                if abs(m - n) < min_diff:
                    min_diff = abs(m - n)
                    num_UEm, num_UEn = m, n
        else:
            num_UEm = num_UEn = dim
    
    # 验证维度是否正确
    if num_UEm * num_UEn != num_rx:
        raise ValueError(f"无法将{num_rx}个接收天线重塑为{num_UEm}x{num_UEn}的网格")
    
    # 重塑为3D形式
    H_Re3D = np.zeros((num_time_slots, num_UEm, num_UEn), dtype=complex)
    
    for t in range(num_time_slots):
        # 将平坦的接收向量重塑为2D网格
        H_Re3D[t] = H_Re[t].reshape(num_UEm, num_UEn)
    
    return H_Re3D

def H_Re3D2D(H_Re3D):
    """
    将3D接收信道矩阵H_Re3D转换为2D形式
    
    参数:
        H_Re3D: 形状为(num_time_slots, num_UEm, num_UEn)的3D复数矩阵
        
    返回:
        H_Re: 形状为(num_time_slots, num_rx)的2D复数矩阵，其中num_rx = num_UEm * num_UEn
    """
    num_time_slots, num_UEm, num_UEn = H_Re3D.shape
    num_rx = num_UEm * num_UEn
    
    # 创建输出矩阵
    H_Re = np.zeros((num_time_slots, num_rx), dtype=complex)
    
    for t in range(num_time_slots):
        # 将2D网格展平为1D向量
        H_Re[t] = H_Re3D[t].flatten()
    
    return H_Re




if __name__ == '__main__':
    num_RIS = 4            # 每个时隙的RIS元件数量
    num_time_slots = 2     # 时隙数量
    bits = 2               # 量化位数
    seed = 42


    RIScode=generate_RIScode(num_RIS, num_time_slots, bits, seed=None)
    Phi=map_RIScode_to_Phi(RIScode, bits)
    RIScode_new=map_Phi_to_RIScode(Phi, bits)
    RIScode,Phi[0],RIScode_new
    RIScode_new=update_RIScode(RIScode, Phi_add, bits, num_time_slots, num_RIS)