import random
import numpy as np
import torch
import torch.nn.functional as F
import gym
from torch.distributions import Categorical
import matplotlib.pyplot as plt
from tqdm import tqdm
import os
import time
import math

# ---------------------------
# 1. 定义 Replay Buffer
# ---------------------------
class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.position = 0

    def push(self, state, action, reward, next_state, done):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (state, action, reward, next_state, done)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        transitions = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*transitions)
        return {
            "states": np.array(state),
            "actions": np.array(action),
            "rewards": np.array(reward),
            "next_states": np.array(next_state),
            "dones": np.array(done)
        }

    def __len__(self):
        return len(self.buffer)

# ---------------------------
# 2. 定义具有交互效应的多维离散动作环境
# ---------------------------
class InteractiveMultiDiscreteEnv(gym.Env):
    """具有强动作维度交互效应的环境"""
    def __init__(self, num_action_dims=3, num_choices=4):
        super(InteractiveMultiDiscreteEnv, self).__init__()
        self.num_action_dims = num_action_dims
        self.num_choices = num_choices
        self.observation_space = gym.spaces.Box(low=-1, high=1, shape=(num_action_dims * 2,), dtype=np.float32)
        self.action_space = gym.spaces.MultiDiscrete([num_choices] * num_action_dims)
        self.max_steps = 100
        self.current_step = 0
        self.state = None
        
        # 预计算奖励表
        self._precompute_reward_tables()
        
    def _precompute_reward_tables(self):
        """预计算常见的奖励模式，提高效率"""
        # 基本的维度对奖励
        self.pair_rewards = {}
        for i in range(self.num_choices):
            for j in range(self.num_choices):
                # 某些特定的动作组合会产生额外奖励
                # 例如：偶数+奇数组合
                self.pair_rewards[(i, j)] = 1.0 if i % 2 == 0 and j % 2 == 1 else 0.0
                
        # 预计算每个动作的奇偶性，以便快速检查
        self.parity = [i % 2 for i in range(self.num_choices)]

    def reset(self):
        self.current_step = 0
        self.state = np.random.uniform(-0.5, 0.5, size=(self.num_action_dims * 2,))
        return self.state.copy()

    def step(self, action):
        self.current_step += 1
        
        # 计算奖励
        reward = self._calculate_reward(action)
        
        # 更新状态
        self._update_state(action)
        
        done = self.current_step >= self.max_steps
        return self.state.copy(), reward, done, {}

    def _calculate_reward(self, action):
        """计算具有强交互效应的奖励"""
        reward = 0.0
        
        # 1. 基本的状态-动作匹配奖励
        for i in range(self.num_action_dims):
            state_indicator = self.state[i] + 0.5  # 转换到[0,1]范围
            optimal_action = int(state_indicator * (self.num_choices - 1) + 0.5)
            action_similarity = 1.0 - abs(action[i] - optimal_action) / (self.num_choices - 1)
            reward += 0.3 * action_similarity
        
        # 2. 动作维度对之间的交互奖励
        if self.num_action_dims >= 2:
            # 遍历所有可能的维度对
            for i in range(self.num_action_dims - 1):
                pair_key = (action[i], action[i+1])
                if pair_key in self.pair_rewards:
                    reward += self.pair_rewards[pair_key]
            
            # 特殊情况：所有动作相同时的惩罚
            if len(set(action)) == 1:
                reward -= 0.5
                
            # 特殊情况：所有动作交替奇偶性时的奖励
            alternating = True
            for i in range(self.num_action_dims - 1):
                if self.parity[action[i]] == self.parity[action[i+1]]:
                    alternating = False
                    break
            if alternating:
                reward += 0.8
        
        # 3. 三维或更高维度的交互
        if self.num_action_dims >= 3:
            # 例如：前三个动作的和符合特定条件时有奖励
            first_three_sum = sum(action[:3])
            target_sum = 3 * (self.num_choices - 1) / 2  # 目标值是动作范围的中间值
            if abs(first_three_sum - target_sum) <= 1:
                reward += 0.5
        
        return reward

    def _update_state(self, action):
        """更新状态，包含动作交互效应"""
        noise = np.random.normal(0, 0.1, size=self.state.shape)
        
        # 计算动作效应
        action_effects = np.zeros_like(self.state)
        
        # 单个动作的效应
        for i in range(self.num_action_dims):
            effect = (action[i] / (self.num_choices - 1) - 0.5) * 0.2
            action_effects[i] += effect
            
            # 动作间交互效应对状态的影响
            if i + 1 < self.num_action_dims:
                # 相邻动作的交互效应
                next_effect = (action[i+1] / (self.num_choices - 1) - 0.5) * 0.2
                # 如果两个相邻动作一奇一偶，产生更强的效应
                if self.parity[action[i]] != self.parity[action[i+1]]:
                    action_effects[i] += next_effect * 0.3
                    action_effects[i+1] += effect * 0.3
        
        # 应用动作效应和随机噪声
        self.state += action_effects + noise
        
        # 确保状态在有效范围内
        self.state = np.clip(self.state, -1.0, 1.0)


class LargeScaleInteractiveEnv(gym.Env):
    """大规模选择空间中有交互效应的环境"""
    def __init__(self, num_action_dims=3, num_choices=200):
        super(LargeScaleInteractiveEnv, self).__init__()
        self.num_action_dims = num_action_dims
        self.num_choices = num_choices
        self.observation_space = gym.spaces.Box(low=-1, high=1, shape=(num_action_dims * 3,), dtype=np.float32)
        self.action_space = gym.spaces.MultiDiscrete([num_choices] * num_action_dims)
        self.max_steps = 100
        self.current_step = 0
        self.state = None
        
        # 为提高效率，预计算一些值
        self._precompute_values()
        
    def _precompute_values(self):
        """预计算常见的模式和奖励系数"""
        # 将动作划分为区间段，减少计算复杂度
        self.segments = 10  # 将动作划分为10个区间
        self.segment_size = self.num_choices // self.segments
        
        # 区间对之间的兼容性矩阵 (10x10矩阵比num_choices x num_choices小得多)
        self.compatibility = np.zeros((self.segments, self.segments))
        for i in range(self.segments):
            for j in range(self.segments):
                # 某些区间组合会更好：互补区间的奖励更高
                self.compatibility[i, j] = 1.0 if abs(i - j) > self.segments // 2 else 0.2
                
        # 优化区间：某些特定区间内的动作会有额外奖励
        self.optimal_regions = [np.random.randint(0, self.segments) for _ in range(self.num_action_dims)]
        
    def reset(self):
        self.current_step = 0
        self.state = np.random.uniform(-0.8, 0.8, size=(self.num_action_dims * 3,))
        return self.state.copy()

    def step(self, action):
        self.current_step += 1
        
        # 计算奖励
        reward = self._calculate_reward(action)
        
        # 更新状态
        self._update_state(action)
        
        done = self.current_step >= self.max_steps
        return self.state.copy(), reward, done, {}

    def _calculate_reward(self, action):
        """计算具有复杂交互效应的奖励"""
        reward = 0.0
        
        # 1. 将动作映射到区间
        action_segments = [min(a // self.segment_size, self.segments - 1) for a in action]
        
        # 2. 状态-动作匹配奖励：基于状态的最优动作区间
        for i in range(self.num_action_dims):
            state_value = self.state[i * 3]  # 使用状态的主要部分
            # 计算这个状态下的最优区间
            optimal_segment = int((state_value + 1) / 2 * self.segments)
            optimal_segment = max(0, min(optimal_segment, self.segments - 1))
            
            # 比较动作区间与最优区间的接近程度
            segment_diff = abs(action_segments[i] - optimal_segment)
            segment_similarity = 1.0 - segment_diff / self.segments
            reward += 0.5 * segment_similarity
        
        # 3. 维度对之间的交互奖励
        if self.num_action_dims >= 2:
            for i in range(self.num_action_dims - 1):
                seg_i, seg_j = action_segments[i], action_segments[i+1]
                reward += self.compatibility[seg_i, seg_j]
            
            # 特殊奖励：所有动作都在不同区间
            if len(set(action_segments)) == len(action_segments):
                reward += 0.5
        
        # 4. 集体行为奖励：动作的整体分布与目标分布的接近程度
        action_mean = sum(action) / len(action)
        action_range = max(action) - min(action)
        
        # 奖励适度分散的动作选择 (既不全聚集也不全分散)
        target_range = self.num_choices * 0.6
        range_similarity = 1.0 - abs(action_range - target_range) / self.num_choices
        reward += 0.3 * range_similarity
        
        # 中位数奖励：整体选择在中间区域时额外奖励
        middle_bias = 1.0 - abs(action_mean - self.num_choices / 2) / (self.num_choices / 2)
        reward += 0.2 * middle_bias
        
        return reward

    def _update_state(self, action):
        """更新状态，体现复杂的动作交互效应"""
        noise = np.random.normal(0, 0.05, size=self.state.shape)
        
        # 每个动作对应状态的3个分量
        for i in range(self.num_action_dims):
            # 标准化动作到[-1,1]区间
            norm_action = action[i] / (self.num_choices - 1) * 2 - 1
            
            # 主要状态分量
            self.state[i * 3] = 0.9 * self.state[i * 3] + 0.1 * norm_action
            
            # 次要状态分量（受前后动作影响）
            if i > 0:  # 受前一个动作影响
                prev_norm_action = action[i-1] / (self.num_choices - 1) * 2 - 1
                self.state[i * 3 + 1] = 0.8 * self.state[i * 3 + 1] + 0.2 * (norm_action + prev_norm_action) / 2
            
            if i < self.num_action_dims - 1:  # 受后一个动作影响
                next_norm_action = action[i+1] / (self.num_choices - 1) * 2 - 1
                self.state[i * 3 + 2] = 0.8 * self.state[i * 3 + 2] + 0.2 * (norm_action + next_norm_action) / 2
        
        # 应用噪声并确保状态在有效范围内
        self.state += noise
        self.state = np.clip(self.state, -1.0, 1.0)

class PatternMatchingEnv(gym.Env):
    """需要发现特定动作模式的环境，模拟复杂配置优化问题"""
    def __init__(self, num_action_dims=4, num_choices=200):
        super(PatternMatchingEnv, self).__init__()
        self.num_action_dims = num_action_dims
        self.num_choices = num_choices
        self.observation_space = gym.spaces.Box(low=-1, high=1, shape=(num_action_dims + 2,), dtype=np.float32)
        self.action_space = gym.spaces.MultiDiscrete([num_choices] * num_action_dims)
        self.max_steps = 150
        self.current_step = 0
        self.state = None
        
        # 定义特定的动作模式，代表"最优配置"
        self._generate_optimal_patterns()
        
    def _generate_optimal_patterns(self):
        """生成最优动作模式和对应的奖励"""
        # 模式1：动作之间的比例关系
        # 例如：第一个动作是第二个动作的2倍，第三个动作是前两个的平均值等
        self.ratio_patterns = []
        for _ in range(3):  # 几种不同的比例模式
            pattern = []
            for i in range(self.num_action_dims):
                if i == 0:
                    # 第一个动作的基准值（随机）
                    base = np.random.randint(self.num_choices // 4, 3 * self.num_choices // 4)
                    pattern.append(base)
                else:
                    # 其他动作基于比例关系
                    ratio = np.random.choice([0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
                    val = int(pattern[0] * ratio)
                    val = max(0, min(val, self.num_choices - 1))
                    pattern.append(val)
            self.ratio_patterns.append((pattern, np.random.uniform(0.5, 1.5)))
            
        # 模式2：动作之间的差值关系
        self.diff_patterns = []
        for _ in range(2):
            pattern = []
            for i in range(self.num_action_dims):
                if i == 0:
                    # 第一个动作的基准值
                    base = np.random.randint(self.num_choices // 4, 3 * self.num_choices // 4)
                    pattern.append(base)
                else:
                    # 其他动作基于差值关系
                    diff = np.random.randint(-self.num_choices // 8, self.num_choices // 8)
                    val = pattern[i-1] + diff
                    val = max(0, min(val, self.num_choices - 1))
                    pattern.append(val)
            self.diff_patterns.append((pattern, np.random.uniform(0.5, 1.5)))
            
        # 模式3：特定区域模式
        num_regions = 5
        region_size = self.num_choices // num_regions
        self.region_patterns = []
        for _ in range(2):
            pattern = []
            regions = np.random.choice(range(num_regions), size=self.num_action_dims, replace=True)
            for i in range(self.num_action_dims):
                region = regions[i]
                min_val = region * region_size
                max_val = (region + 1) * region_size - 1
                pattern.append((min_val, max_val))
            self.region_patterns.append((pattern, np.random.uniform(0.5, 1.5)))

    def reset(self):
        self.current_step = 0
        self.state = np.random.uniform(-0.8, 0.8, size=(self.num_action_dims + 2,))
        # 更新状态，提示当前环境倾向的模式类型
        self.current_pattern_type = np.random.choice(['ratio', 'diff', 'region'])
        if self.current_pattern_type == 'ratio':
            self.state[-2] = 0.5  # 模式类型指示器
        elif self.current_pattern_type == 'diff':
            self.state[-2] = 0.0
        else:  # region
            self.state[-2] = -0.5
            
        # 随机选择一个具体模式
        if self.current_pattern_type == 'ratio':
            self.active_pattern = np.random.choice(len(self.ratio_patterns))
            self.state[-1] = self.active_pattern / len(self.ratio_patterns) * 2 - 1
        elif self.current_pattern_type == 'diff':
            self.active_pattern = np.random.choice(len(self.diff_patterns))
            self.state[-1] = self.active_pattern / len(self.diff_patterns) * 2 - 1
        else:  # region
            self.active_pattern = np.random.choice(len(self.region_patterns))
            self.state[-1] = self.active_pattern / len(self.region_patterns) * 2 - 1
            
        return self.state.copy()

    def step(self, action):
        self.current_step += 1
        
        # 计算奖励
        reward = self._calculate_reward(action)
        
        # 更新状态
        self._update_state(action)
        
        done = self.current_step >= self.max_steps
        return self.state.copy(), reward, done, {}

    def _calculate_reward(self, action):
        """计算奖励，取决于动作与当前活跃模式的匹配程度"""
        reward = 0.0
        
        # 基础奖励：基于各个维度状态和动作的匹配度
        for i in range(self.num_action_dims):
            state_factor = self.state[i] * 0.5 + 0.5  # 将[-1,1]映射到[0,1]
            optimal_raw = state_factor * (self.num_choices - 1)
            distance = abs(action[i] - optimal_raw) / (self.num_choices - 1)
            reward += 0.2 * (1 - distance)
        
        # 模式匹配奖励
        pattern_reward = 0.0
        
        if self.current_pattern_type == 'ratio':
            pattern, pattern_weight = self.ratio_patterns[self.active_pattern]
            # 计算动作比例与模式比例的匹配度
            match_score = 0.0
            for i in range(1, self.num_action_dims):
                if pattern[0] == 0:  # 避免除以零
                    continue
                expected_ratio = pattern[i] / pattern[0]
                if action[0] == 0:  # 避免除以零
                    actual_ratio = float('inf')
                else:
                    actual_ratio = action[i] / action[0]
                ratio_diff = abs(expected_ratio - actual_ratio) / max(expected_ratio, 1)
                match_score += (1 - min(ratio_diff, 1)) / (self.num_action_dims - 1)
            pattern_reward = match_score * pattern_weight

        elif self.current_pattern_type == 'diff':
            pattern, pattern_weight = self.diff_patterns[self.active_pattern]
            # 计算动作差值与模式差值的匹配度
            match_score = 0.0
            for i in range(1, self.num_action_dims):
                expected_diff = pattern[i] - pattern[i-1]
                actual_diff = action[i] - action[i-1]
                diff_match = 1.0 - min(abs(expected_diff - actual_diff) / self.num_choices, 1.0)
                match_score += diff_match / (self.num_action_dims - 1)
            pattern_reward = match_score * pattern_weight
            
        else:  # region pattern
            pattern, pattern_weight = self.region_patterns[self.active_pattern]
            # 计算动作是否落在期望区域内
            match_score = 0.0
            for i in range(self.num_action_dims):
                min_val, max_val = pattern[i]
                if min_val <= action[i] <= max_val:
                    match_score += 1.0
                else:
                    # 计算到最近区域边界的距离
                    dist = min(abs(action[i] - min_val), abs(action[i] - max_val))
                    dist_norm = dist / self.num_choices
                    match_score += max(0, 1 - 2 * dist_norm)  # 距离越小，分数越高
            match_score /= self.num_action_dims
            pattern_reward = match_score * pattern_weight
        
        # 综合奖励
        reward = 0.3 * reward + 0.7 * pattern_reward
        
        return reward

    def _update_state(self, action):
        """更新状态，反映动作的效果"""
        noise = np.random.normal(0, 0.05, size=(self.num_action_dims,))
        
        # 更新与动作维度相关的状态
        for i in range(self.num_action_dims):
            # 将动作标准化到[-1,1]
            norm_action = action[i] / (self.num_choices - 1) * 2 - 1
            
            # 状态更新公式：随机移动+微小动作偏好
            self.state[i] = 0.85 * self.state[i] + 0.15 * norm_action + noise[i]
        
        # 确保状态在有效范围内
        self.state[:self.num_action_dims] = np.clip(self.state[:self.num_action_dims], -1.0, 1.0)
        # 模式类型和具体模式索引保持不变
# ---------------------------
# 3. 高效的策略网络
# ---------------------------
class EfficientPolicyNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, num_action_dims, num_choices):
        super(EfficientPolicyNet, self).__init__()
        self.backbone = torch.nn.Sequential(
            torch.nn.Linear(state_dim, hidden_dim),
            torch.nn.ELU(),
            torch.nn.Linear(hidden_dim, hidden_dim),
            torch.nn.ELU()
        )
        
        # 为每个动作维度创建独立的输出头
        self.action_heads = torch.nn.ModuleList([
            torch.nn.Linear(hidden_dim, num_choices) for _ in range(num_action_dims)
        ])

    def forward(self, x):
        features = self.backbone(x)
        logits = [head(features).unsqueeze(1) for head in self.action_heads]
        logits = torch.cat(logits, dim=1)  # [batch, num_action_dims, num_choices]
        probs = F.softmax(logits, dim=-1)
        return probs

# ---------------------------
# 4. Transformer组件
# ---------------------------
class MultiHeadAttention(torch.nn.Module):
    def __init__(self, d_model, num_heads):
        super(MultiHeadAttention, self).__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads
        
        # 确保可以被头数整除
        assert self.head_dim * num_heads == d_model, "d_model must be divisible by num_heads"
        
        # Q, K, V 线性投影
        self.q_linear = torch.nn.Linear(d_model, d_model)
        self.k_linear = torch.nn.Linear(d_model, d_model)
        self.v_linear = torch.nn.Linear(d_model, d_model)
        
        # 输出投影
        self.out_linear = torch.nn.Linear(d_model, d_model)
        
    def forward(self, x):
        batch_size = x.size(0)
        seq_len = x.size(1)
        
        # 线性投影
        q = self.q_linear(x)  # [batch, seq_len, d_model]
        k = self.k_linear(x)  # [batch, seq_len, d_model]
        v = self.v_linear(x)  # [batch, seq_len, d_model]
        
        # 分割为多头
        q = q.view(batch_size, seq_len, self.num_heads, self.head_dim).permute(0, 2, 1, 3)  # [batch, num_heads, seq_len, head_dim]
        k = k.view(batch_size, seq_len, self.num_heads, self.head_dim).permute(0, 2, 1, 3)  # [batch, num_heads, seq_len, head_dim]
        v = v.view(batch_size, seq_len, self.num_heads, self.head_dim).permute(0, 2, 1, 3)  # [batch, num_heads, seq_len, head_dim]
        
        # 缩放点积注意力
        scores = torch.matmul(q, k.transpose(-1, -2)) / (self.head_dim ** 0.5)  # [batch, num_heads, seq_len, seq_len]
        attn = torch.nn.functional.softmax(scores, dim=-1)
        context = torch.matmul(attn, v)  # [batch, num_heads, seq_len, head_dim]
        
        # 拼接多头结果
        context = context.permute(0, 2, 1, 3).contiguous().view(batch_size, seq_len, self.d_model)  # [batch, seq_len, d_model]
        
        # 最终线性投影
        output = self.out_linear(context)  # [batch, seq_len, d_model]
        
        return output

class PositionwiseFeedForward(torch.nn.Module):
    def __init__(self, d_model, d_ff):
        super(PositionwiseFeedForward, self).__init__()
        self.linear1 = torch.nn.Linear(d_model, d_ff)
        self.linear2 = torch.nn.Linear(d_ff, d_model)
        
    def forward(self, x):
        return self.linear2(F.relu(self.linear1(x)))

class TransformerEncoderLayer(torch.nn.Module):
    def __init__(self, d_model, num_heads, d_ff, dropout=0.1):
        super(TransformerEncoderLayer, self).__init__()
        self.self_attn = MultiHeadAttention(d_model, num_heads)
        self.feed_forward = PositionwiseFeedForward(d_model, d_ff)
        self.norm1 = torch.nn.LayerNorm(d_model)
        self.norm2 = torch.nn.LayerNorm(d_model)
        self.dropout = torch.nn.Dropout(dropout)
        
    def forward(self, x):
        # 自注意力子层
        attn_output = self.self_attn(x)
        x = self.norm1(x + self.dropout(attn_output))
        
        # 前馈网络子层
        ff_output = self.feed_forward(x)
        x = self.norm2(x + self.dropout(ff_output))
        
        return x

def get_positional_encoding(seq_len, d_model):
    """标准的正弦余弦位置编码"""
    pe = torch.zeros(seq_len, d_model)
    position = torch.arange(0, seq_len, dtype=torch.float).unsqueeze(1)
    div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
    pe[:, 0::2] = torch.sin(position * div_term)
    pe[:, 1::2] = torch.cos(position * div_term)
    return pe.unsqueeze(0)  # [1, seq_len, d_model]

# ---------------------------
# 5. Transformer Q网络
# ---------------------------
class TransformerQNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, num_action_dims, num_choices, num_heads=4, num_layers=2, dropout=0.1):
        super(TransformerQNet, self).__init__()
        self.num_action_dims = num_action_dims
        self.d_model = hidden_dim
        
        # 状态编码器
        self.state_encoder = torch.nn.Sequential(
            torch.nn.Linear(state_dim, hidden_dim),
            torch.nn.LayerNorm(hidden_dim),
            torch.nn.ReLU()
        )
        
        # 动作维度的可学习嵌入
        self.dim_embeddings = torch.nn.Parameter(
            torch.randn(num_action_dims, hidden_dim)
        )
        
        # 位置编码
        self.register_buffer('pos_encoder', get_positional_encoding(num_action_dims, hidden_dim))
        
        # Transformer编码器层
        self.encoder_layers = torch.nn.ModuleList([
            TransformerEncoderLayer(hidden_dim, num_heads, hidden_dim * 4, dropout)
            for _ in range(num_layers)
        ])
        
        # 输出头 - 每个维度一个
        self.output_heads = torch.nn.ModuleList([
            torch.nn.Linear(hidden_dim, num_choices) for _ in range(num_action_dims)
        ])
        
    def forward(self, x):
        batch_size = x.size(0)
        
        # 状态编码
        state_features = self.state_encoder(x)  # [batch, hidden_dim]
        
        # 准备动作维度嵌入
        dim_embeds = self.dim_embeddings.unsqueeze(0).expand(batch_size, -1, -1)  # [batch, num_dims, hidden_dim]
        
        # 添加位置编码
        dim_embeds = dim_embeds + self.pos_encoder  # [batch, num_dims, hidden_dim]
        
        # 注入状态信息
        dim_features = dim_embeds + state_features.unsqueeze(1)  # [batch, num_dims, hidden_dim]
        
        # 通过Transformer编码器层
        for encoder_layer in self.encoder_layers:
            dim_features = encoder_layer(dim_features)  # [batch, num_dims, hidden_dim]
            
        # 计算每个维度的Q值
        q_values = []
        for i, head in enumerate(self.output_heads):
            dim_q = head(dim_features[:, i]).unsqueeze(1)  # [batch, 1, num_choices]
            q_values.append(dim_q)
            
        q_values = torch.cat(q_values, dim=1)  # [batch, num_action_dims, num_choices]
        
        return q_values

# ---------------------------
# 6. 完整的 SAC 算法实现
# ---------------------------
class TransformerSAC:
    def __init__(self, state_dim, hidden_dim, num_action_dims, num_choices,
                 actor_lr, critic_lr, alpha_lr, target_entropy, tau, gamma, device,
                 num_heads=4, num_layers=2, dropout=0.1, update_interval=1):
        self.device = device
        self.gamma = gamma
        self.tau = tau
        self.target_entropy = target_entropy
        self.num_action_dims = num_action_dims
        self.update_interval = update_interval
        self.update_counter = 0
        
        # 策略网络
        self.actor = EfficientPolicyNet(state_dim, hidden_dim, num_action_dims, num_choices).to(device)
        
        # Transformer Q 网络
        self.critic_1 = TransformerQNet(
            state_dim, hidden_dim, num_action_dims, num_choices, 
            num_heads, num_layers, dropout
        ).to(device)
        
        self.critic_2 = TransformerQNet(
            state_dim, hidden_dim, num_action_dims, num_choices, 
            num_heads, num_layers, dropout
        ).to(device)
        
        self.target_critic_1 = TransformerQNet(
            state_dim, hidden_dim, num_action_dims, num_choices,
            num_heads, num_layers, dropout
        ).to(device)
        
        self.target_critic_2 = TransformerQNet(
            state_dim, hidden_dim, num_action_dims, num_choices,
            num_heads, num_layers, dropout
        ).to(device)
        
        # 复制初始权重到目标网络
        self.target_critic_1.load_state_dict(self.critic_1.state_dict())
        self.target_critic_2.load_state_dict(self.critic_2.state_dict())
        
        # 优化器
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_1_optimizer = torch.optim.Adam(self.critic_1.parameters(), lr=critic_lr)
        self.critic_2_optimizer = torch.optim.Adam(self.critic_2.parameters(), lr=critic_lr)
        
        # 熵系数
        self.log_alpha = torch.tensor(np.log(0.01), dtype=torch.float).to(device)
        self.log_alpha.requires_grad = True
        self.log_alpha_optimizer = torch.optim.Adam([self.log_alpha], lr=alpha_lr)

    def take_action(self, state):
        """根据当前策略选择动作"""
        state = np.array([state])
        state = torch.from_numpy(state).float().to(self.device)
        
        with torch.no_grad():
            probs = self.actor(state)  # [1, num_action_dims, num_choices]
        
        actions = []
        for i in range(probs.size(1)):
            distribution = Categorical(probs[:, i, :])
            actions.append(distribution.sample().item())
        
        return np.array(actions)

    def calc_target(self, rewards, next_states, dones):
        """计算目标 Q 值，使用蒙特卡洛采样"""
        with torch.no_grad():
            next_probs = self.actor(next_states)  # [B, K, N]
            next_log_probs = torch.log(next_probs + 1e-8)
            entropy = -torch.sum(next_probs * next_log_probs, dim=2)  # [B, K]
            joint_entropy = torch.sum(entropy, dim=1, keepdim=True)  # [B, 1]
            
            # 使用采样估计联合期望 Q 值
            num_samples = max(1, min(3, self.num_action_dims - 1))  # 动态调整采样数量
            
            sampled_q_values = []
            for _ in range(num_samples):
                # 采样完整的动作组合
                actions = []
                for i in range(self.num_action_dims):
                    distrib = Categorical(next_probs[:, i, :])
                    actions.append(distrib.sample().unsqueeze(1))
                actions = torch.cat(actions, dim=1)  # [B, K]
                
                # 获取采样动作的 Q 值
                q1 = self.target_critic_1(next_states)  # [B, K, N]
                q2 = self.target_critic_2(next_states)  # [B, K, N]
                min_q = torch.min(q1, q2)
                
                # 提取这些动作的 Q 值
                indices = actions.unsqueeze(-1)  # [B, K, 1]
                selected_q = min_q.gather(2, indices).squeeze(-1)  # [B, K]
                joint_q = torch.sum(selected_q, dim=1, keepdim=True)  # [B, 1]
                sampled_q_values.append(joint_q)
            
            # 平均所有采样的 Q 值
            expected_q = torch.mean(torch.cat(sampled_q_values, dim=1), dim=1, keepdim=True)
            
            # 计算目标值
            td_target = rewards + self.gamma * (1 - dones) * (expected_q + self.log_alpha.exp() * joint_entropy)
            
            return td_target

    def soft_update(self, net, target_net):
        """软更新目标网络"""
        for param_target, param in zip(target_net.parameters(), net.parameters()):
            param_target.data.copy_(param_target.data * (1.0 - self.tau) + param.data * self.tau)

    def update(self, transition_dict):
        """更新网络参数"""
        self.update_counter += 1
        if self.update_counter % self.update_interval != 0:
            return  # 控制更新频率
            
        states = torch.tensor(transition_dict['states'], dtype=torch.float).to(self.device)
        actions = torch.tensor(transition_dict['actions'], dtype=torch.long).to(self.device)
        rewards = torch.tensor(transition_dict['rewards'], dtype=torch.float).view(-1, 1).to(self.device)
        next_states = torch.tensor(transition_dict['next_states'], dtype=torch.float).to(self.device)
        dones = torch.tensor(transition_dict['dones'], dtype=torch.float).view(-1, 1).to(self.device)

        # 计算目标 Q 值
        td_target = self.calc_target(rewards, next_states, dones)

        # 更新 critic 1
        current_q1 = self.critic_1(states)
        selected_q1 = current_q1.gather(dim=2, index=actions.unsqueeze(-1)).squeeze(-1)
        q1_value = torch.sum(selected_q1, dim=1, keepdim=True)
        critic_1_loss = F.mse_loss(q1_value, td_target)

        self.critic_1_optimizer.zero_grad()
        critic_1_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic_1.parameters(), max_norm=1.0)
        self.critic_1_optimizer.step()

        # 更新 critic 2
        current_q2 = self.critic_2(states)
        selected_q2 = current_q2.gather(dim=2, index=actions.unsqueeze(-1)).squeeze(-1)
        q2_value = torch.sum(selected_q2, dim=1, keepdim=True)
        critic_2_loss = F.mse_loss(q2_value, td_target)

        self.critic_2_optimizer.zero_grad()
        critic_2_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic_2.parameters(), max_norm=1.0)
        self.critic_2_optimizer.step()

        # 更新策略网络
        probs = self.actor(states)
        log_probs = torch.log(probs + 1e-8)
        entropy = -torch.sum(probs * log_probs, dim=2)
        joint_entropy = torch.sum(entropy, dim=1, keepdim=True)

        # 计算当前策略下的 Q 值期望
        with torch.no_grad():
            q1 = self.critic_1(states)
            q2 = self.critic_2(states)
            min_q = torch.min(q1, q2)
            
        expected_q = torch.sum(probs * min_q, dim=2)
        joint_expected_q = torch.sum(expected_q, dim=1, keepdim=True)

        actor_loss = torch.mean(-self.log_alpha.exp() * joint_entropy - joint_expected_q)
        
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=1.0)
        self.actor_optimizer.step()

        # 更新熵系数 alpha
        alpha_loss = torch.mean((joint_entropy - self.target_entropy).detach() * self.log_alpha.exp())
        
        self.log_alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.log_alpha_optimizer.step()

        # 软更新目标网络
        self.soft_update(self.critic_1, self.target_critic_1)
        self.soft_update(self.critic_2, self.target_critic_2)

# ---------------------------
# 7. 训练函数
# ---------------------------
def train_agent(env, agent, num_episodes, replay_buffer, minimal_size, batch_size, eval_interval=50):
    return_list = []
    eval_returns = []
    
    start_time = time.time()
    
    for i_episode in tqdm(range(num_episodes)):
        episode_return = 0
        state = env.reset()
        done = False
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            replay_buffer.push(state, action, reward, next_state, done)
            state = next_state
            episode_return += reward

            if len(replay_buffer) > minimal_size:
                transition = replay_buffer.sample(batch_size)
                agent.update(transition)
                
        return_list.append(episode_return)
        
        # 定期记录和评估
        if (i_episode + 1) % (num_episodes//5) == 0:
            avg_return = np.mean(return_list[-10:])
            elapsed_time = time.time() - start_time
            print(f"Episode: {i_episode+1}, Avg Return: {avg_return:.2f}")

            mean_return, _ = evaluate_agent(env, agent, num_episodes=5, verbose=False) #*
            eval_returns.append((i_episode + 1, mean_return))
            #print(f"Evaluation at episode {i_episode+1}: Mean Return = {mean_return:.2f}") #*
            
    return return_list, eval_returns

# ---------------------------
# 8. 评估函数
# ---------------------------
def evaluate_agent(env, agent, num_episodes=50, verbose=True): #*
    """
    评估智能体在环境中的表现
    
    Args:
        env: 环境
        agent: 智能体
        num_episodes: 评估的回合数
        verbose: 是否打印评估结果 #*
        
    Returns:
        mean_return: 平均回报
        std_return: 回报标准差
    """
    returns = []
    
    for _ in range(num_episodes):
        episode_return = 0
        state = env.reset()
        done = False
        
        while not done:
            action = agent.take_action(state)
            next_state, reward, done, _ = env.step(action)
            episode_return += reward
            state = next_state
            
        returns.append(episode_return)
        
    mean_return = np.mean(returns)
    std_return = np.std(returns)
    
    # 只有在verbose=True时才打印结果 #*
    if verbose: #*
        print(f"Evaluation over {num_episodes} episodes: Mean Return = {mean_return:.2f}, Std = {std_return:.2f}") #*
    
    return mean_return, std_return

# ---------------------------
# 9. 可视化和分析功能
# ---------------------------
def plot_results(return_list, eval_returns, title, save_dir='./results', window_size=10, figsize=(12, 8)):
    """绘制训练回报曲线和评估结果"""
    os.makedirs(save_dir, exist_ok=True)
    
    # 计算滑动平均
    if window_size > 1:
        smoothed_returns = []
        for i in range(len(return_list)):
            start_idx = max(0, i - window_size + 1)
            smoothed_returns.append(np.mean(return_list[start_idx:i+1]))
    else:
        smoothed_returns = return_list
    
    plt.figure(figsize=figsize)
    
    # 主图: 训练回报
    plt.subplot(2, 1, 1)
    plt.plot(return_list, alpha=0.3, label='Training Returns')
    plt.plot(smoothed_returns, label=f'Smoothed Returns (window={window_size})')
    plt.xlabel('Episode')
    plt.ylabel('Return')
    plt.title(f'{title} - Training Progress')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 第二个子图: 评估回报
    if eval_returns:
        plt.subplot(2, 1, 2)
        episodes, returns = zip(*eval_returns)
        plt.plot(episodes, returns, 'o-', label='Evaluation Returns')
        plt.xlabel('Episode')
        plt.ylabel('Evaluation Return')
        plt.title('Periodic Evaluation Performance')
        plt.legend()
        plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    # 保存图片
    save_path = os.path.join(save_dir, f"{title.replace(' ', '_')}.png")
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"Plot saved to {save_path}")
    
    plt.show()

def analyze_attention_patterns(agent, env, num_samples=3):
    """分析Transformer模型中的注意力模式"""
    print("\n=== Analyzing Attention Patterns ===")
    
    # 获取注意力权重
    def get_attention_weights(state):
        state_tensor = torch.tensor([state], dtype=torch.float).to(agent.device)
        
        # 获取第一个注意力层的权重
        with torch.no_grad():
            # 提取状态特征
            state_features = agent.critic_1.state_encoder(state_tensor)
            
            # 准备维度嵌入
            dim_embeds = agent.critic_1.dim_embeddings.unsqueeze(0)
            
            # 添加位置编码
            dim_embeds = dim_embeds + agent.critic_1.pos_encoder
            
            # 注入状态信息
            dim_features = dim_embeds + state_features.unsqueeze(1)
            
            # 获取第一层自注意力的权重
            encoder_layer = agent.critic_1.encoder_layers[0]
            q = encoder_layer.self_attn.q_linear(dim_features)
            k = encoder_layer.self_attn.k_linear(dim_features)
            
            # 多头注意力的第一个头
            q_head = q.view(1, -1, encoder_layer.self_attn.num_heads, encoder_layer.self_attn.head_dim)[:, :, 0, :]
            k_head = k.view(1, -1, encoder_layer.self_attn.num_heads, encoder_layer.self_attn.head_dim)[:, :, 0, :]
            
            # 计算注意力分数
            scores = torch.matmul(q_head, k_head.transpose(-1, -2)) / (encoder_layer.self_attn.head_dim ** 0.5)
            weights = F.softmax(scores, dim=-1)
            
            return weights.squeeze(0).cpu().numpy()
    
    # 分析多个样本
    for i in range(num_samples):
        state = env.reset()
        action = agent.take_action(state)
        _, reward, _, _ = env.step(action)
        
        # 获取注意力权重
        attn_weights = get_attention_weights(state)
        
        print(f"\nSample {i+1}:")
        print(f"State: {state[:env.num_action_dims]}")
        print(f"Action: {action}, Reward: {reward:.2f}")
        print("Attention Matrix:")
        for row in attn_weights:
            print(" ".join([f"{w:.2f}" for w in row]))
            
        # 分析互相关注的动作维度
        strongly_related = []
        for dim_i in range(env.num_action_dims):
            for dim_j in range(env.num_action_dims):
                if dim_i != dim_j and attn_weights[dim_i, dim_j] > 0.25:  # 阈值可调
                    strongly_related.append((dim_i, dim_j, attn_weights[dim_i, dim_j]))
        
        if strongly_related:
            print("Strongly related action dimensions:")
            for dim_i, dim_j, weight in sorted(strongly_related, key=lambda x: -x[2]):
                print(f"  Dim {dim_i} -> Dim {dim_j}: {weight:.2f}")
        else:
            print("No strongly related action dimensions found.")
    
    return True

# ---------------------------
# 10. 主函数
# ---------------------------
def main():
    import json
    import os
    from datetime import datetime
    
    # 创建特定的输出文件夹
    output_dir = os.path.join("./results", "Transformer_SAC")
    os.makedirs(output_dir, exist_ok=True)
    
    # 创建带时间戳的子文件夹
    timestamp = datetime.now().strftime("%m%d_%H%M")
    run_dir = os.path.join(output_dir, f"run_{timestamp}")
    os.makedirs(run_dir, exist_ok=True)
    
    # 配置参数
    params = {
        "actor_lr": 1e-4,
        "critic_lr": 1e-4,
        "alpha_lr": 1e-4,
        "num_episodes": 100,
        "hidden_dim": 128,
        "gamma": 0.98,
        "tau": 0.005,
        "buffer_size": 10000,
        "minimal_size": 500,
        "batch_size": 64,
        "update_interval": 1,
        "eval_interval": 50,
        
        # Transformer参数
        "num_heads": 4,
        "num_layers": 2,
        "dropout": 0.1,
        
        "num_action_dims": 3,
        "num_choices": 20,
        "env_name": "PatternMatchingEnv",
        "device": "cuda" if torch.cuda.is_available() else "cpu"
    }
    
    # 将参数保存为JSON文件
    params_file = os.path.join(run_dir, "parameters.json")
    with open(params_file, "w") as f:
        json.dump(params, f, indent=4)
    
    print(f"Parameters saved to {params_file}")
    print(f"Using device: {params['device']}")
    
    # 目标熵与动作维度相关
    target_entropy = -params["num_action_dims"]
    
    print(f"num_action_dims: {params['num_action_dims']}")
    print(f"num_choices: {params['num_choices']}")
    
    # 初始化环境
    if params["env_name"] == "InteractiveMultiDiscreteEnv":
        env = InteractiveMultiDiscreteEnv(params["num_action_dims"], params["num_choices"])
    elif params["env_name"] == "LargeScaleInteractiveEnv":
        env = LargeScaleInteractiveEnv(params["num_action_dims"], params["num_choices"])
    elif params["env_name"] == "PatternMatchingEnv":
        env = PatternMatchingEnv(params["num_action_dims"], params["num_choices"])
    else:
        raise ValueError(f"Unknown environment: {params['env_name']}")
    
    print(f"Environment: {params['env_name']}, hidden_dim: {params['hidden_dim']}")
    
    state_dim = env.observation_space.shape[0]
    
    # 初始化 replay buffer 和 agent
    replay_buffer = ReplayBuffer(params["buffer_size"])
    agent = TransformerSAC(
        state_dim, params["hidden_dim"], params["num_action_dims"], params["num_choices"],
        params["actor_lr"], params["critic_lr"], params["alpha_lr"], target_entropy, 
        params["tau"], params["gamma"], torch.device(params["device"]),
        params["num_heads"], params["num_layers"], params["dropout"], params["update_interval"]
    )
    
    # 训练开始时间
    start_time = time.time()
    
    # 训练
    print("\nStarting training...")
    return_list, eval_returns = train_agent(
        env, agent, params["num_episodes"], replay_buffer, 
        params["minimal_size"], params["batch_size"], params["eval_interval"]
    )
    
    # 记录训练时间
    training_time = time.time() - start_time
    
    # 最终评估
    print("\nFinal evaluation...")
    num_eval_episodes = 50
    mean_return, std_return = evaluate_agent(env, agent, num_episodes=num_eval_episodes)
    
    # 保存模型（如果TransformerSAC类实现了save方法）
    try:
        model_path = os.path.join(run_dir, "transformer_sac_model.pt")
        torch.save({
            'actor': agent.actor.state_dict(),
            'critic_1': agent.critic_1.state_dict(),
            'critic_2': agent.critic_2.state_dict(),
            'target_critic_1': agent.target_critic_1.state_dict(),
            'target_critic_2': agent.target_critic_2.state_dict(),
            'log_alpha': agent.log_alpha.item(),
        }, model_path)
        print(f"Model saved to {model_path}")
    except Exception as e:
        print(f"Warning: Could not save model. Error: {e}")
    
    # 保存注意力分析结果
    attention_analysis_file = os.path.join(run_dir, "attention_analysis.txt")
    with open(attention_analysis_file, "w") as f:
        # 重定向标准输出
        import sys
        original_stdout = sys.stdout
        sys.stdout = f
        
        # 执行注意力分析
        analyze_attention_patterns(agent, env)
        
        # 恢复标准输出
        sys.stdout = original_stdout
    
    print(f"Attention analysis saved to {attention_analysis_file}")
    
    # 保存评估结果到txt文件
    results_file = os.path.join(run_dir, "evaluation_results.txt")
    with open(results_file, "w") as f:
        f.write("=== Transformer SAC Evaluation Results ===\n\n")
        f.write(f"Mean Return: {mean_return:.4f}\n")
        f.write(f"Standard Deviation: {std_return:.4f}\n")
        f.write(f"Number of Evaluation Episodes: {num_eval_episodes}\n")
        f.write(f"Training Time: {training_time:.2f} seconds\n")
        f.write(f"Average Return (last 10 episodes): {np.mean(return_list[-10:]):.4f}\n")
        
        # 记录评估指标变化
        if eval_returns:
            f.write("\n=== Periodic Evaluation Performance ===\n")
            for episode, eval_return in eval_returns:
                f.write(f"Episode {episode}: {eval_return:.4f}\n")
        
        # 添加训练参数摘要
        f.write("\n=== Training Parameters ===\n")
        f.write(f"Environment: {params['env_name']}\n")
        f.write(f"Action Dimensions: {params['num_action_dims']}\n")
        f.write(f"Choices per Dimension: {params['num_choices']}\n")
        f.write(f"Episodes: {params['num_episodes']}\n")
        f.write(f"Learning Rates - Actor: {params['actor_lr']}, Critic: {params['critic_lr']}, Alpha: {params['alpha_lr']}\n")
        f.write(f"Hidden Dimensions: {params['hidden_dim']}\n")
        
        # Transformer特有参数
        f.write("\n=== Transformer Parameters ===\n")
        f.write(f"Number of Heads: {params['num_heads']}\n")
        f.write(f"Number of Layers: {params['num_layers']}\n")
        f.write(f"Dropout Rate: {params['dropout']}\n")
    
    print(f"Evaluation results saved to {results_file}")
    
    # 绘制结果
    plot_title = f"Transformer_SAC_Return{mean_return:.2f}_Choices{params['num_choices']}_Dims{params['num_action_dims']}"
    plot_results(
        return_list, 
        eval_returns,
        plot_title,
        save_dir=run_dir,  # 保存到子文件夹
        window_size=10
    )
    
    print(f"\nAll results saved to {run_dir}")
    return agent

# 直接运行
if __name__ == "__main__":
    main()