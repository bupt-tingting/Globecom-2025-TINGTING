import json
import os
os.chdir('/new_disk/ting/RL')



# MATLAB 系统参数
matlab_params = {
    "CenterFre": 28e9,          # 中心频率
    "NumSubCar": 2,             # 子载波数 (FDD 的总数，TDD 为一半)
    
    "N_BSm": 4,                 # 垂直天线的数量（基站）
    "N_BSn": 4,                 # 水平天线的数量（基站）   
    "N_RISm": 5,                # RIS 垂直数量
    "N_RISn": 5,                # RIS 水平数量
    "N_UEm": 4,                 # UE 垂直天线数量
    "N_UEn": 4,                 # UE 水平天线数量   
    
    "UENum": 1,                 # 用户数量
    "num_time_slots": 2, #! 时隙数量
    "BSlocation": [0, 2, 0],      # 基站位置（三维坐标）
    "RISlocation": [0.01, 0.01, 0],   # RIS位置（三维坐标）
    "UEcenter": [1.7, 1, 0],      # UE中心位置（三维坐标）
    # MATLAB 中定义的 UESpeedList 使用 colon 操作符: 0.01:2:10
    # MATLAB 的 0.01:2:10 返回的序列为：[0.01, 2.01, 4.01, 6.01, 8.01]
    #"UESpeedList": [0.01, 2.01, 4.01, 6.01, 8.01]
    "UESpeedList": [20]
}

# Python 端的参数
python_params = {
    "snr": 25,
    "use_cnn":0,
    "bits": 1,
    "seed": 42,
    "power_weight":0.8
    
}

# 合并两个参数字典。如果存在相同的 key，可以决定使用哪个，也可以改名后合并
config = {**python_params, **matlab_params}

# 保存为 JSON 文件
with open("ChannelGen//RISconfig.json", "w") as f:
    json.dump(config, f, indent=4)

print("配置已保存到ChannelGen//RISconfig.json文件中！")